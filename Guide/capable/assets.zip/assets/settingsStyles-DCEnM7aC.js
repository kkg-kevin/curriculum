import{i as e,n as t}from"./chunk-CacB07dV.js";import{b as n,r,t as i,x as a}from"./api-BwUREcHg.js";import{a as o,f as s,s as c,t as l}from"./modern-BUWoT6BY.js";import{At as u,jt as d}from"./index-BHGkzxoL.js";var f,p,m=t((()=>{r(),f=`/api/admin-tools/users`,p={list:()=>i.get(f).then(e=>e.data.data),setActive:(e,t)=>i.patch(`${f}/${e}`,{active:t}).then(e=>e.data.data)}}));function h(){return c({queryKey:_,queryFn:p.list})}function g(){let e=s();return o({mutationFn:({id:e,active:t})=>p.setActive(e,t),onSuccess:(t,{active:n})=>{e.invalidateQueries({queryKey:_}),d.success(n?`${t.name||`Account`} can sign in again`:`${t.name||`Account`} deactivated`)},onError:e=>d.error(e.response?.data?.message||e.message||`Failed to update the account`)})}var _,v=t((()=>{l(),u(),m(),_=[`workspace-users`]}));function y({title:e,description:t,children:n}){return(0,D.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:18},children:[(0,D.jsxs)(`header`,{children:[(0,D.jsx)(`h2`,{style:{margin:0,fontSize:18,fontWeight:800,color:O.ink},children:e}),t&&(0,D.jsx)(`p`,{style:{margin:`4px 0 0`,fontSize:13,color:O.muted,lineHeight:1.55},children:t})]}),n]})}function b({title:e,description:t,aside:n,footer:r,children:i,as:a=`section`,onSubmit:o}){return(0,D.jsxs)(a,{onSubmit:o,style:{border:`1px solid ${O.border}`,borderRadius:14,background:`#fff`,overflow:`hidden`},children:[(0,D.jsxs)(`div`,{style:{padding:`16px 20px`,display:`flex`,alignItems:`flex-start`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`,borderBottom:i?`1px solid #F3F4F6`:`none`},children:[(0,D.jsxs)(`div`,{style:{minWidth:0,flex:`1 1 280px`},children:[(0,D.jsx)(`h3`,{style:{margin:0,fontSize:14.5,fontWeight:800,color:O.ink},children:e}),t&&(0,D.jsx)(`p`,{style:{margin:`3px 0 0`,fontSize:12.5,color:O.muted,lineHeight:1.5},children:t})]}),n&&(0,D.jsx)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,flexWrap:`wrap`},children:n})]}),i&&(0,D.jsx)(`div`,{style:{padding:`16px 20px`,display:`flex`,flexDirection:`column`,gap:16},children:i}),r&&(0,D.jsx)(`div`,{style:{padding:`12px 20px`,background:`#F9FAFB`,borderTop:`1px solid #F3F4F6`,display:`flex`,alignItems:`center`,gap:10,flexWrap:`wrap`},children:r})]})}function x({children:e,min:t=200}){return(0,D.jsx)(`div`,{style:{display:`grid`,gap:14,gridTemplateColumns:`repeat(auto-fit, minmax(min(100%, ${t}px), 1fr))`},children:e})}function S({label:e,htmlFor:t,note:n,warning:r,children:i}){return(0,D.jsxs)(`div`,{style:{minWidth:0},children:[e&&(0,D.jsx)(`label`,{htmlFor:t,style:{display:`block`,fontSize:12.5,fontWeight:700,color:`#374151`,marginBottom:5},children:e}),i,(r||n)&&(0,D.jsx)(`p`,{style:{margin:`5px 0 0`,fontSize:11.5,lineHeight:1.45,color:r?O.warn:O.muted},children:r||n})]})}function C({children:e,note:t}){return(0,D.jsxs)(`div`,{children:[(0,D.jsx)(`p`,{style:{margin:0,fontSize:11,fontWeight:800,color:`#38aae1`,textTransform:`uppercase`,letterSpacing:`0.07em`},children:e}),t&&(0,D.jsx)(`p`,{style:{margin:`3px 0 0`,fontSize:12,color:O.muted,lineHeight:1.45},children:t})]})}function w({ok:e,children:t}){return(0,D.jsxs)(`span`,{style:{display:`inline-flex`,alignItems:`center`,gap:6,padding:`3px 10px`,borderRadius:999,fontSize:11.5,fontWeight:700,color:e?`#047857`:O.muted,background:e?`#ECFDF5`:`#F3F4F6`},children:[(0,D.jsx)(`span`,{style:{width:7,height:7,borderRadius:999,background:e?`#10B981`:`#D1D5DB`}}),t]})}function T({children:e}){return(0,D.jsx)(`span`,{style:{fontSize:12,color:O.muted},children:e})}function E({isLoading:e,isError:t,what:n}){return e?(0,D.jsx)(`p`,{style:{margin:0,fontSize:13,color:O.muted},children:`Loading…`}):t?(0,D.jsxs)(`p`,{style:{margin:0,fontSize:13,color:O.error},children:[n,` could not be loaded.`]}):null}var D,O,k=t((()=>{D=n(),O={ink:`#111827`,muted:`#6B7280`,faint:`#9CA3AF`,border:`#E5E7EB`,warn:`#B45309`,error:`#B91C1C`}}));function A(){(0,j.useEffect)(()=>{let e=document.createElement(`style`);return e.id=`settings-styles`,e.textContent=M,document.head.appendChild(e),()=>{e.remove()}},[])}var j,M,N=t((()=>{j=e(a()),M=`
  @keyframes stg-fadein { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
  @keyframes stg-spin    { to { transform:rotate(360deg); } }

  .stg-card {
    background:#fff; border-radius:16px; padding:22px 24px;
    box-shadow:0 1px 4px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.04);
  }

  .stg-btn-primary {
    padding:10px 20px; background:#feb139; color:#25476a; border:none; border-radius:10px;
    font-size:13px; font-weight:700; font-family:Inter,sans-serif; cursor:pointer;
    display:inline-flex; align-items:center; gap:7px; transition:background 0.15s, transform 0.1s; white-space:nowrap;
  }
  .stg-btn-primary:hover:not(:disabled) { background:#f5a827; }
  .stg-btn-primary:active:not(:disabled) { transform:scale(0.98); }
  .stg-btn-primary:disabled { background:#fde3b0; cursor:not-allowed; }

  .stg-btn-secondary {
    padding:9px 16px; background:#fff; color:#374151; border:1.5px solid #E5E7EB;
    border-radius:9px; font-size:13px; font-weight:600; font-family:Inter,sans-serif;
    cursor:pointer; transition:all 0.15s; white-space:nowrap;
  }
  .stg-btn-secondary:hover { background:#F3F4F6; }

  .stg-input, .stg-textarea {
    padding:10px 12px; border-radius:10px; border:1.5px solid #E5E7EB;
    font-size:14px; font-family:Inter,sans-serif; background:#F9FAFB;
    color:#374151; outline:none; width:100%; box-sizing:border-box;
    transition:border-color 0.15s, box-shadow 0.15s, background 0.15s;
  }
  .stg-input:focus, .stg-textarea:focus {
    border-color:#38aae1; background:#fff; box-shadow:0 0 0 3px rgba(56,170,225,0.12);
  }
  .stg-textarea { resize:vertical; }

  .stg-spinner {
    width:22px; height:22px; border:2.5px solid #E5E7EB; border-top-color:#25476a;
    border-radius:50%; animation:stg-spin 0.7s linear infinite; margin:60px auto;
  }

  .stg-empty {
    text-align:center; padding:56px 24px; background:#fff;
    border:2px dashed #E5E7EB; border-radius:16px; animation:stg-fadein 0.2s ease;
  }

  .stg-grid {
    display:grid; grid-template-columns:repeat(auto-fill, minmax(272px,1fr));
    gap:16px; align-items:start;
  }
  @media(max-width:560px){ .stg-grid { grid-template-columns:1fr; } }

  .stg-comp-card {
    position:relative; background:#fff; border:1.5px solid #E5E7EB; border-radius:16px;
    padding:18px 20px; display:flex; flex-direction:column;
    transition:border-color 0.15s, box-shadow 0.15s, transform 0.15s;
    animation:stg-fadein 0.18s ease;
  }
  .stg-comp-card:hover {
    border-color:#b8d9ee; box-shadow:0 6px 20px rgba(37,71,106,0.1); transform:translateY(-2px);
  }
  .stg-comp-card-top { display:flex; align-items:flex-start; gap:12px; margin-bottom:10px; }
  .stg-avatar {
    width:44px; height:44px; border-radius:12px; flex-shrink:0;
    display:flex; align-items:center; justify-content:center;
    font-size:18px; font-weight:800;
  }
  .stg-code-pill {
    display:inline-flex; align-items:center; justify-content:center;
    padding:4px 8px; border-radius:999px;
    background:#E8F5FB; border:1px solid #B8D9EE;
    color:#25476a; font-size:11px; font-weight:800;
    line-height:1; letter-spacing:0.04em;
  }
  .stg-code-pill--small { padding:3px 7px; font-size:10px; }
  .stg-code-preview-row {
    display:flex; align-items:center; gap:10px; flex-wrap:wrap;
    padding:10px 12px; border:1px solid #E5E7EB; border-radius:10px; background:#F9FAFB;
  }
  .stg-comp-desc {
    margin:0; font-size:12.5px; color:#6B7280; line-height:1.6;
    display:-webkit-box; -webkit-line-clamp:4; -webkit-box-orient:vertical; overflow:hidden;
    flex:1;
  }

  .stg-comp-ind-toggle {
    display:flex; align-items:center; justify-content:space-between; width:100%;
    margin-top:10px; padding-top:10px; border-top:1px solid #F3F4F6; background:none;
    border-left:none; border-right:none; border-bottom-width:0; cursor:pointer;
    font-family:Inter,sans-serif; font-size:11px; font-weight:700; color:#25476a;
  }
  .stg-comp-ind-chevron { transition:transform 0.15s; color:#9CA3AF; }
  .stg-comp-ind-chevron.open { transform:rotate(180deg); }
  .stg-comp-ind-list { margin-top:8px; }
  .stg-comp-ind-item {
    padding:7px 9px; background:#F9FAFB; border:1px solid #F3F4F6; border-radius:8px;
    margin-bottom:5px;
  }
  .stg-comp-ind-item:last-child { margin-bottom:0; }

  .stg-ind-row {
    display:flex; align-items:flex-start; gap:10px; padding:8px 10px;
    background:#F9FAFB; border:1px solid #F3F4F6; border-radius:9px; margin-bottom:6px;
  }
  .stg-ind-x {
    background:none; border:none; color:#9CA3AF; cursor:pointer; font-size:16px;
    line-height:1; padding:0; transition:color 0.1s; flex-shrink:0;
  }
  .stg-ind-x:hover { color:#DC2626; }
  .stg-ind-add-card {
    display:flex; flex-direction:column; gap:8px; padding:12px;
    background:#F9FAFB; border:1.5px dashed #E5E7EB; border-radius:12px;
  }
  .stg-ind-add-input { background:#fff; }

  .stg-kebab-btn {
    width:28px; height:28px; border-radius:8px; border:none; background:transparent;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    color:#D1D5DB; transition:background 0.12s, color 0.12s; flex-shrink:0;
  }
  .stg-kebab-btn:hover { background:#F3F4F6; color:#374151; }
  .stg-menu {
    position:absolute; top:calc(100% + 4px); right:0; z-index:200;
    background:#fff; border:1px solid #E5E7EB; border-radius:10px;
    box-shadow:0 4px 16px rgba(0,0,0,0.1), 0 1px 4px rgba(0,0,0,0.06);
    min-width:140px; padding:4px; animation:stg-fadein 0.12s ease;
  }
  .stg-menu-item {
    display:flex; align-items:center; gap:8px; width:100%;
    padding:8px 10px; border:none; border-radius:7px; background:transparent;
    font-size:12px; font-weight:600; font-family:Inter,sans-serif; color:#374151;
    cursor:pointer; text-align:left; transition:background 0.1s, color 0.1s;
  }
  .stg-menu-item:hover { background:#F3F4F6; color:#111827; }
  .stg-menu-item--danger { color:#DC2626; }
  .stg-menu-item--danger:hover { background:#FEF2F2; }

  .stg-modal-overlay {
    position:fixed; inset:0; z-index:1000; background:rgba(15,38,69,0.45);
    display:flex; align-items:flex-start; justify-content:center;
    padding:40px 16px; overflow-y:auto; animation:stg-fadein 0.15s ease;
  }
  .stg-modal {
    background:#fff; border-radius:18px; width:100%; max-width:480px;
    box-shadow:0 24px 64px rgba(0,0,0,0.25); overflow:hidden;
  }
  .stg-modal-header {
    padding:20px 24px; background:linear-gradient(135deg,#1a3550 0%,#25476a 60%,#2e7db5 100%);
  }
  .stg-modal-close {
    background:rgba(255,255,255,0.12); border:none; color:#fff; cursor:pointer;
    font-size:16px; line-height:1; width:26px; height:26px; border-radius:8px;
    display:flex; align-items:center; justify-content:center; transition:background 0.12s;
  }
  .stg-modal-close:hover { background:rgba(255,255,255,0.22); }
  .stg-field-label {
    font-size:12px; font-weight:700; color:#374151; display:block; margin-bottom:5px;
  }

  /* The underline is an inset shadow, not a border, so the row can scroll sideways on a phone
     (a scrolling box clips anything drawn over its own border). */
  .stg-tabs { display:flex; gap:6px; margin-bottom:20px; box-shadow:inset 0 -2px 0 #F3F4F6; overflow-x:auto; scrollbar-width:none; }
  .stg-tabs::-webkit-scrollbar { display:none; }
  .stg-tab-btn {
    padding:9px 16px; background:none; border:none; border-bottom:2.5px solid transparent;
    font-size:13px; font-weight:600; font-family:Inter,sans-serif; color:#6B7280;
    cursor:pointer; white-space:nowrap; flex-shrink:0; transition:color 0.15s, border-color 0.15s;
  }
  .stg-tab-btn:hover { color:#25476a; }
  .stg-tab-btn.active { color:#25476a; border-bottom-color:#25476a; }

  .stg-swatch {
    width:26px; height:26px; border-radius:50%; border:2px solid #fff; cursor:pointer; padding:0;
    box-shadow:0 0 0 1.5px #E5E7EB; transition:box-shadow 0.15s, transform 0.1s;
  }
  .stg-swatch:hover { transform:scale(1.08); }
  .stg-swatch.active { box-shadow:0 0 0 2px #111827; }

  .stg-chip {
    display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius:20px;
    border:1px solid; font-size:12px; font-weight:600; font-family:Inter,sans-serif;
  }
  .stg-chip-x {
    background:none; border:none; cursor:pointer; font-size:14px; line-height:1; padding:0; color:inherit;
  }

  .stg-list { display:flex; flex-direction:column; gap:8px; }

  .stg-item {
    display:flex; flex-direction:column; align-items:stretch; gap:0;
    padding:16px 18px; border-radius:12px; border:1.5px solid #E5E7EB;
    background:#FAFAFA; transition:border-color 0.15s, background 0.15s;
    animation:stg-fadein 0.18s ease;
  }
  .stg-item:hover { border-color:#b8d9ee; background:#F8FBFF; }
  .stg-item-top { display:flex; align-items:center; gap:12px; }
  .stg-item-dot { width:10px; height:10px; border-radius:50%; flex-shrink:0; }
  .stg-item-name { flex:1; min-width:0; font-size:14px; font-weight:700; color:#111827; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .stg-item-sub  { font-size:12.5px; color:#9CA3AF; font-weight:400; margin-top:4px; line-height:1.6; }

  .stg-icon-btn {
    width:30px; height:30px; border-radius:8px; border:none; background:transparent;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    color:#9CA3AF; transition:background 0.12s, color 0.12s; flex-shrink:0;
  }
  .stg-icon-btn:hover        { background:#F3F4F6; color:#374151; }
  .stg-icon-btn.danger:hover { background:#FEF2F2; color:#DC2626; }

  /* System levels: a grid of small tiles, read left to right. A tile's buttons show on hover or
     keyboard focus, and always on a touch screen. */
  .stg-level-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(150px, 1fr)); gap:8px; }
  .stg-level {
    position:relative; display:flex; align-items:center; gap:8px; min-width:0; height:42px;
    padding:0 10px; border-radius:10px; border:1.5px solid #E5E7EB; background:#FAFAFA;
    transition:border-color 0.15s, background 0.15s; animation:stg-fadein 0.18s ease;
  }
  .stg-level:hover, .stg-level:focus-within { border-color:#b8d9ee; background:#F8FBFF; }
  .stg-level-num {
    min-width:24px; height:24px; padding:0 4px; box-sizing:border-box; border-radius:7px; flex-shrink:0;
    background:#e8f5fb; border:1px solid #a8d5ee; color:#25476a; font-size:11.5px; font-weight:800;
    display:flex; align-items:center; justify-content:center;
  }
  .stg-level-name {
    flex:1; min-width:0; padding:0; border:none; background:none; text-align:left; cursor:text;
    font:700 13px Inter,sans-serif; color:#111827; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
  }
  .stg-level-name:focus-visible { outline:2px solid #2e7db5; outline-offset:2px; border-radius:4px; }
  .stg-level-input { flex:1; min-width:0; height:28px; padding:0 8px !important; font-size:13px !important; }
  .stg-level-actions {
    position:absolute; right:4px; top:50%; transform:translateY(-50%); display:flex; gap:1px;
    padding-left:14px; background:linear-gradient(to right, rgba(248,251,255,0), #F8FBFF 14px);
    opacity:0; pointer-events:none; transition:opacity 0.12s;
  }
  .stg-level:hover .stg-level-actions, .stg-level:focus-within .stg-level-actions { opacity:1; pointer-events:auto; }
  .stg-level-actions .stg-icon-btn { width:24px; height:24px; border-radius:6px; }
  .stg-level-actions .stg-icon-btn:disabled { opacity:0.35; cursor:default; }
  /* A touch screen has no hover: the buttons sit on their own line under the name. */
  @media (hover: none) {
    .stg-level { height:auto; min-height:42px; flex-wrap:wrap; row-gap:2px; padding:7px 8px 4px; }
    .stg-level-actions {
      position:static; transform:none; opacity:1; pointer-events:auto; padding-left:0; background:none;
      flex-basis:100%; justify-content:flex-end; gap:4px; border-top:1px solid #EEF2F6; padding-top:3px;
    }
    .stg-level-actions .stg-icon-btn { width:30px; height:30px; }
  }

  .stg-course-section { margin-top:12px; padding-top:12px; border-top:1px dashed #E5E7EB; }
  .stg-course-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:9px; }
  .stg-course-header-left { display:flex; align-items:center; gap:6px; }
  .stg-course-title { font-size:12px; font-weight:700; color:#374151; font-family:Inter,sans-serif; }
  .stg-course-count-badge {
    padding:1px 8px; border-radius:20px; font-size:10.5px; font-weight:700; border:1px solid;
  }
  .stg-course-list { display:flex; flex-direction:column; gap:5px; }
  .stg-course-row {
    display:flex; align-items:center; gap:8px;
    padding:6px 10px; border-radius:8px; background:#fff;
    border:1px solid #EEF0F2; transition:border-color 0.12s, background 0.12s;
  }
  .stg-course-row:hover { background:#FAFCFF; }
  .stg-course-dot { width:6px; height:6px; border-radius:50%; flex-shrink:0; }
  .stg-course-name { flex:1; min-width:0; font-size:12.5px; font-weight:600; color:#1F2937; word-break:break-word; }

  .stg-search-wrap { position:relative; margin-bottom:14px; max-width:280px; }
  .stg-search-icon { position:absolute; left:13px; top:50%; transform:translateY(-50%); color:#9CA3AF; pointer-events:none; }
  .stg-search-input {
    width:100%; box-sizing:border-box; padding:10px 12px 10px 36px; border-radius:10px;
    border:1.5px solid #E5E7EB; font-size:13.5px; font-family:Inter,sans-serif;
    background:#F9FAFB; color:#374151; outline:none;
    transition:border-color 0.15s, box-shadow 0.15s, background 0.15s;
  }
  .stg-search-input:focus {
    border-color:#38aae1; background:#fff; box-shadow:0 0 0 3px rgba(56,170,225,0.12);
  }
`}));export{T as a,b as c,k as d,v as f,x as i,w as l,h as m,A as n,E as o,g as p,S as r,y as s,N as t,C as u};