const crypto = require("crypto");
const db = require("../../config/db");
const passwords = require("../../shared/utils/password");
const jwt = require("jsonwebtoken");
const UserModel = require("./user.model");
const LearnerModel = require("../learners/learner.model");
const TeacherModel = require("../teachers/teacher.model");
const LearningHubModel = require("../learning-hubs/learning-hub.model");
const LeadModel = require("../leads/lead.model");
const BootcampModel = require("../bootcamps/bootcamp.model");
const RevokedTokenModel = require("./revoked-token.model");
const UserSessionModel = require("./user-session.model");
const PasswordResetTokenModel = require("./password-reset-token.model");
const { sendPasswordResetEmail, sendPasswordChangedEmail } = require("./auth.emails");
const AccessService = require("../access/access.service");
const { releaseIfLeftover, isLeftoverLogin } = require("./leftover-login");
const LearnerPasswordVault = require("./learner-password-vault");
const { LINKABLE_ROLES, WORKSPACE_ROLES, OWN_ONLY_ROLES, HUB_LEAD_ROLE, TOT_LEARNER_ROLE, extraRolesOf, rolesOf, sessionRolesOf, availableRoles, totTraineeOf, withoutRole } = require("./account-roles");
const { resolveEffectiveBootcampPrice } = require("../../shared/utils/bootcamp-pricing");
const { JWT_SECRET, JWT_EXPIRES_IN, SESSION_IDLE_MINUTES, PASSWORD_RESET_MINUTES } = require("../../config/env");

// At most this many reset emails per account per hour — further requests are quietly ignored, so
// the forgot-password form can't be used to flood someone's inbox.
const RESET_REQUESTS_PER_HOUR = 3;

const hashResetToken = (token) => crypto.createHash("sha256").update(String(token)).digest("hex");

function invalidResetLink() {
  const err = new Error("This password reset link is invalid or has expired. Please request a new one.");
  err.statusCode = 400;
  err.code = "RESET_LINK_INVALID";
  return err;
}

// Where an account's own emails go. Most accounts have an email. A child's own login has only a
// username, so its emails go to the parent/guardian on the learner record (and say whose login
// they're about). Returns null when there's no address to reach the account at.
async function accountEmailTarget(user) {
  if (user.email) return { user, to: user.email, recipientName: user.name };
  if (!user.username) return null;
  const learner = await LearnerModel.findByUsername(user.username);
  if (!learner?.guardianEmail) return null;
  return { user, to: learner.guardianEmail, recipientName: learner.guardianName || "", childName: user.name };
}

// Which account a forgot-password request is about, following the same three ways `login` accepts
// an identifier: an account's email, a child's own username login, or a child's username that
// still signs in with the parent's password (no login of its own yet) — in which case the
// password to reset is the parent's.
async function resolveResetTarget(identifier) {
  let user = await UserModel.findByEmail(identifier);
  if (!user) user = await UserModel.findByUsername(identifier);
  if (!user) {
    const learner = await LearnerModel.findByUsername(identifier);
    const guardian = learner?.guardianEmail ? await UserModel.findByEmail(learner.guardianEmail) : null;
    if (guardian?.role === "learner") user = guardian;
  }
  return user ? accountEmailTarget(user) : null;
}

// Idle timeout (see user-session.model.js). The client reports activity at most about every 30s,
// so the server allows one extra minute on top of the limit: the client's own countdown — which
// sees every click — is what signs a user out on time, and the server only has to guarantee an
// abandoned session can't outlive it.
const SESSION_IDLE_MS = SESSION_IDLE_MINUTES * 60 * 1000;
const SESSION_IDLE_GRACE_MS = 60 * 1000;

const SALT_ROUNDS = 10;

// Strips the password hash before a user record ever leaves the service layer.
// A staff (collaborator) account's permissions and role name, sent with the user so the client
// can shape its sidebar and actions; nothing for any other role.
async function staffAccess(user) {
  if (user.role !== "collaborator") return {};
  return { permissions: await AccessService.permissionsFor(user), accessRole: await AccessService.roleSummaryFor(user) };
}

function sanitize(user) {
  const { passwordHash, ...safe } = user;
  return safe;
}

// Resolves whether a user's account is suspended (deactivated), and why. A suspended user is
// still allowed a session — they can log in and load /api/auth/me — but the client locks them
// to an in-app "Account Suspended" page, and every write is refused server-side by the
// blockIfSuspended middleware. Returns null (not suspended) or a reason string:
//   "hub"     — the school-role account's own learning hub is inactive
//   "teacher" — the teacher record is inactive ("on_leave" is NOT a suspension, just a hint)
//   "learner" — the learner account (or every sibling under a guardian login) is inactive
//   "payment" — the learner account (or every sibling) is "pending_payment" — auto-provisioned
//               from a public bootcamp enrollment (see bootcamp-enrollment.service.js) and not
//               yet marked paid. Kept distinct from "learner" so the client can show "please
//               complete payment" instead of "contact your school administrator", which would
//               be actively wrong for this case.
// A user with no matching record at all (e.g. a teacher login with no teacher row yet) is not
// suspended — that's handled by the portals' own "no profile linked" states.
function learnerSuspensionReason(learners) {
  if (learners.some((l) => (l.accountStatus || "active") === "active")) return null;
  // None are active — "payment" takes priority over the generic "learner" reason whenever at
  // least one sibling is pending_payment rather than a hard "inactive", since that's the more
  // actionable, specific thing to tell them.
  return learners.some((l) => l.accountStatus === "pending_payment") ? "payment" : "learner";
}

async function resolveSuspension(user) {
  if (!user) return null;

  if (user.role === "school") {
    const hubs = await LearningHubModel.findAll({ email: user.email, includeDrafts: true });
    const ownHub = hubs.find((h) => !h.parentHubId) || hubs[0] || null;
    if (ownHub && ownHub.status === "inactive") return "hub";
  }

  if (user.role === "teacher") {
    const teachers = await TeacherModel.findAll({ email: user.email });
    if (teachers.length > 0 && !teachers.some((t) => (t.status || "active") !== "inactive")) return "teacher";
  }

  if (user.role === "learner") {
    if (user.username) {
      const learner = await LearnerModel.findByUsername(user.username);
      if (!learner) return "learner";
      return learnerSuspensionReason([learner]);
    }
    const learners = await LearnerModel.findAll({ guardianEmail: user.email });
    if (learners.length === 0) return "learner";
    return learnerSuspensionReason(learners);
  }

  return null;
}

// Kept for the one caller that must still hard-fail on a missing user (protect's getById path).
async function assertUserExists(user) {
  if (!user) {
    const err = new Error("User not found");
    err.statusCode = 404;
    throw err;
  }
  return user;
}

// jti gives each issued token a unique identity to revoke by (see logout below) — without it,
// the denylist would have nothing to key a single token's revocation on short of storing the
// whole raw token string. `role` is the role this session runs as — the account's own, or one
// of its extra roles (account-roles.js) chosen at sign-in or switched to.
function signToken(user, role = user.role) {
  return jwt.sign(
    { sub: user.id, role, email: user.email, username: user.username, jti: crypto.randomUUID() },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

const AuthService = {
  // `organisationId` (admins only) puts the new admin in an existing organisation — see
  // auth.controller.js's createAdmin.
  async createUser({ name, email, password, role, organisationId }) {
    if (await UserModel.findByEmail(email)) {
      const err = new Error("A user with this email already exists");
      err.statusCode = 409;
      throw err;
    }
    const passwordHash = await passwords.hash(password, SALT_ROUNDS);
    const user = await UserModel.create({ name, email, passwordHash, role, ...(organisationId ? { organisationId } : {}) });
    return sanitize(user);
  },

  // Public self-signup — role is already restricted to non-admin values by signupSchema,
  // but createUser is the single write path either way. Does not sign a token: the account
  // is created but the user still has to log in separately, same as any other account.
  async signup({ name, email, password, role }) {
    return this.createUser({ name, email, password, role });
  },

  // Sets the password of the login with this email for `role` — an educator, hub, parent (or
  // curriculum admin, supervisor) form — creating the login when there's none. A leftover login of
  // another kind (see leftover-login.js — its record was deleted) gives its email up first.
  //
  // One person, one login, one password (account-roles.js): an existing login of another role
  // takes an educator, hub or parent role as an extra role, and the password typed here becomes
  // that login's password for every role it holds. The one exception is an admin's or curriculum
  // admin's own login — someone else's form never changes their password (they do it in My
  // profile); it still gains the role, and the result says `passwordKept`. `linked` is true
  // whenever the login already existed with another role of its own.
  async setOrCreatePassword({ name, email, password, role }) {
    const existing = await UserModel.findByEmail(email);
    if (!existing) return this.createUser({ name, email, password, role });
    const holdsRole = rolesOf(existing).includes(role);
    if (!holdsRole && await releaseIfLeftover(existing)) {
      return this.createUser({ name, email, password, role });
    }
    if (!holdsRole && !(LINKABLE_ROLES.includes(role) && existing.email)) {
      const err = new Error(`This email is already registered as a ${existing.role} account`);
      err.statusCode = 409;
      throw err;
    }
    const linked = existing.role !== role;
    const passwordKept = linked && OWN_ONLY_ROLES.includes(existing.role);
    const patch = holdsRole ? {} : { extraRoles: [...extraRolesOf(existing), role] };
    if (password && !passwordKept) patch.passwordHash = await passwords.hash(password, SALT_ROUNDS);
    const updated = Object.keys(patch).length ? await UserModel.update(existing.id, patch) : existing;
    return { ...sanitize(updated), ...(linked ? { linked: true } : {}), ...(passwordKept ? { passwordKept: true } : {}) };
  },

  // Makes the login with this email staff or a claims supervisor (account-roles.js's
  // WORKSPACE_ROLES) of `ownerAdminId`'s workspace. A login that already exists — an educator, a
  // parent, the workspace's own supervisor — simply takes the role and keeps its password, unless
  // a new one is given (then it's that login's password for every role). Without a login, one is
  // created and a password is required. Refused: an admin's / curriculum admin's login, and a
  // login that is still staff or a supervisor of another workspace (the workspace sits on the
  // login). `created` is true for a brand-new login.
  async addWorkspaceRole({ name, email, password, role, ownerAdminId }) {
    const fail = (message, statusCode = 409) => { throw Object.assign(new Error(message), { statusCode }); };
    let existing = await UserModel.findByEmail(email);
    const alreadyHere = existing && rolesOf(existing).includes(role) && existing.invitedByAdminId === ownerAdminId;
    if (existing && !alreadyHere && await releaseIfLeftover(existing)) existing = null;

    if (!existing) {
      if (!password) fail("This email has no login yet — set a password for it", 400);
      const user = await this.createUser({ name, email, password, role });
      return { ...sanitize(await UserModel.update(user.id, { invitedByAdminId: ownerAdminId })), created: true };
    }
    if (OWN_ONLY_ROLES.includes(existing.role)) {
      fail(`This email is ${existing.role === "admin" ? "an admin" : "a curriculum admin"} login — they already run a workspace, so they can't also be ${role === "supervisor" ? "a supervisor" : "staff"}`);
    }

    // Staff / supervisor of another workspace: refused while that workspace still exists, cleared
    // first when it's gone (its roles are leftovers).
    let user = existing;
    const elsewhere = user.invitedByAdminId && user.invitedByAdminId !== ownerAdminId
      ? WORKSPACE_ROLES.filter((r) => rolesOf(user).includes(r))
      : [];
    for (const r of elsewhere) {
      if (!(await isLeftoverLogin({ ...user, role: r }))) fail("This email is already staff or a claims supervisor in another workspace");
    }
    for (const r of elsewhere) user = await UserModel.update(user.id, withoutRole(user, r));

    const patch = { invitedByAdminId: ownerAdminId };
    if (!rolesOf(user).includes(role)) patch.extraRoles = [...extraRolesOf(user), role];
    if (password) patch.passwordHash = await passwords.hash(password, SALT_ROUNDS);
    return { ...sanitize(await UserModel.update(user.id, patch)), created: false };
  },

  // Takes `role` off a login (removing a staff member or supervisor): the login stays for the
  // other roles it holds, its own role passing on when that's the one going (withoutRole). With no
  // role left, the login and its sessions go. Returns the updated login, or null when deleted.
  async dropRole(user, role) {
    const patch = withoutRole(user, role);
    if (!patch) {
      await UserSessionModel.deleteByUserId(user.id);
      await UserModel.delete(user.id);
      return null;
    }
    return sanitize(await UserModel.update(user.id, patch));
  },

  // Mints/resets a learner's OWN dedicated portal login — distinct from setOrCreatePassword
  // above, which is always the GUARDIAN's account. Keyed by username instead of email, and the
  // resulting User row never has an email at all. Same existing-row conflict shape as
  // setOrCreatePassword: reset in place if the role matches, otherwise 409.
  async setOrCreatePasswordByUsername({ name, username, password, role }) {
    const existing = await UserModel.findByUsername(username);
    if (existing) {
      if (existing.role !== role) {
        const err = new Error(`This username is already registered as a ${existing.role} account`);
        err.statusCode = 409;
        throw err;
      }
      const passwordHash = await passwords.hash(password, SALT_ROUNDS);
      const updated = await UserModel.update(existing.id, { passwordHash });
      // A child's login: kept so staff can show it again (learner-password-vault.js).
      await LearnerPasswordVault.remember(updated, password);
      return sanitize(updated);
    }
    const passwordHash = await passwords.hash(password, SALT_ROUNDS);
    const created = await UserModel.create({ name, username, passwordHash, role });
    await LearnerPasswordVault.remember(created, password);
    return sanitize(created);
  },

  // Keeps a learner's own dedicated login attached to their current username when it's renamed
  // elsewhere (see learner.controller.js's updateLearner) — without this the login would still
  // work but silently become unreachable under the old username. No-ops if there's no dedicated
  // login to move (most learners don't have one) or no new username to move it to.
  async renameUsernameAccount(oldUsername, newUsername) {
    if (!oldUsername || oldUsername === newUsername) return;
    const existing = await UserModel.findByUsername(oldUsername);
    if (!existing || !newUsername) return;
    await UserModel.update(existing.id, { username: newUsername });
  },

  // `identifier` may be: an account's own email (admin/school/teacher/curriculumAdmin,
  // or a guardian logging in directly); a learner's own dedicated username (a genuinely separate
  // account/password from the guardian's — see setOrCreatePasswordByUsername); or, for a learner
  // who has a username but no dedicated login yet, that same username checked against their
  // guardian's password — which then creates the learner's own login (see below) rather than
  // signing in as the guardian. `Learner.username` is regex-restricted to exclude "@", so it can never
  // collide with an email-shaped identifier — these three branches are mutually exclusive.
  async login(identifier, password) {
    let user = await UserModel.findByEmail(identifier);
    if (!user) user = await UserModel.findByUsername(identifier);
    // A learner's username with no dedicated login yet. It has always been accepted with the
    // parent's password, but it used to sign in AS the parent — so the child saw the parent's
    // view, siblings included. Now the child gets their own login instead: created here on first
    // use with the password they just used, and signed in as that, so the session is scoped to
    // this one child. The credentials that worked before keep working; the parent's own email
    // login is untouched.
    let learnerNeedingOwnLogin = null;
    if (!user) {
      const learner = await LearnerModel.findByUsername(identifier);
      const guardian = learner?.guardianEmail ? await UserModel.findByEmail(learner.guardianEmail) : null;
      if (guardian?.role === "learner") {
        user = guardian;
        learnerNeedingOwnLogin = learner;
      }
    }
    if (!user) {
      const err = new Error("Invalid email/username or password");
      err.statusCode = 401;
      throw err;
    }
    const valid = await passwords.compare(password, user.passwordHash);
    if (!valid) {
      const err = new Error("Invalid email/username or password");
      err.statusCode = 401;
      throw err;
    }
    // Switched off by the workspace's owner (Settings → People & sharing → Users). Checked only
    // after the password matched, so it never tells a stranger that the account exists.
    if (user.deactivatedAt) {
      const err = new Error("This account has been deactivated. Please contact your administrator.");
      err.statusCode = 403;
      err.code = "ACCOUNT_DEACTIVATED";
      throw err;
    }
    if (learnerNeedingOwnLogin) {
      user = await UserModel.create({
        name: `${learnerNeedingOwnLogin.firstName} ${learnerNeedingOwnLogin.lastName}`.trim(),
        username: learnerNeedingOwnLogin.username,
        passwordHash: user.passwordHash,
        role: "learner",
      });
    }
    // A suspended account is still allowed to log in — the client shows an in-app "Account
    // Suspended" page and every write is refused server-side. `suspended` rides along on the
    // returned user so the client knows immediately, without a second round trip.
    // Signed in as the account's own role (or its first live one); with more than one
    // (`roles`), the client asks which to use and switches to it (switchRole below).
    const role = (await availableRoles(user))[0] || user.role;
    const token = await this.startSession(user, role);
    return { user: await this.sessionUser(user, role), token };
  },

  // An educator, hub or parent saved WITHOUT a password whose email already has a login of
  // another role: that login takes the role too (account-roles.js), so the person can sign in
  // as it with their own password. Nothing happens when there's no such login, it already holds
  // the role, or it's a leftover (setOrCreatePassword deals with those when a password is set).
  async linkExistingLogin(email, role) {
    if (!email || !LINKABLE_ROLES.includes(role)) return null;
    const existing = await UserModel.findByEmail(email);
    if (!existing?.email || existing.role === role || rolesOf(existing).includes(role)) return null;
    if (await isLeftoverLogin(existing)) return null;
    return sanitize(await UserModel.update(existing.id, { extraRoles: [...extraRolesOf(existing), role] }));
  },

  // A new session for `user` running as `role`; returns its token.
  async startSession(user, role) {
    const token = signToken(user, role);
    const { jti, exp } = jwt.decode(token);
    await UserSessionModel.create({ jti, userId: user.id, expiresAt: new Date(exp * 1000) });
    await UserSessionModel.pruneStale(SESSION_IDLE_MINUTES + 1);
    return token;
  },

  // What the client gets about the signed-in user: the account, shown as the session's role, with
  // every role it can sign in as (`roles`), and that role's suspension / staff access.
  //
  // An Account Manager / Training Lead session (account-roles.js's HUB_LEAD_ROLE) runs in the hub
  // portal, so it is shown as a "school" session with `hubLead: true` — every check of "is this the
  // hub portal" keeps working — and `sessionRole` says which role it really is.
  async sessionUser(user, role, { withRoles = true } = {}) {
    if (role === TOT_LEARNER_ROLE) return this.totLearnerSessionUser(user, { withRoles });
    const hubLead = role === HUB_LEAD_ROLE;
    const asRole = { ...user, role };
    const suspended = await resolveSuspension(asRole);
    const pendingPayment = suspended === "payment" ? await this.getPendingPayment(asRole) : null;
    return {
      ...sanitize(asRole),
      ...(hubLead ? { role: "school", hubLead: true, sessionRole: HUB_LEAD_ROLE } : {}),
      ...(withRoles ? { roles: await availableRoles(user) } : {}),
      suspended,
      pendingPayment,
      ...(await staffAccess(asRole)),
    };
  },

  // A TOT learner session (account-roles.js's TOT_LEARNER_ROLE): the educator learning, shown as a
  // "learner" session — the learner portal, on their own learner record — with `totLearner` and
  // `learningAsEducator` (never taken for a parent: `username` is their record's, else a marker),
  // and `sessionRole` saying which role it really is. Suspended when the educator is deactivated,
  // or the learner record is (an unpaid sign-up stays view-only instead — scope.middleware.js —
  // so they can still reach their invoice). No learner record (removed since): "learner".
  async totLearnerSessionUser(user, { withRoles = true } = {}) {
    const { trainee } = await totTraineeOf(user);
    let suspended = await resolveSuspension({ ...user, role: "teacher" });
    if (!trainee) suspended = suspended || "learner";
    else if (!suspended && trainee.accountStatus !== "pending_payment") suspended = learnerSuspensionReason([trainee]);
    return {
      ...sanitize({ ...user, role: "learner" }),
      username: trainee?.username || `educator:${trainee?.id || user.id}`,
      totLearner: true,
      learningAsEducator: true,
      sessionRole: TOT_LEARNER_ROLE,
      learnerId: trainee?.id || null,
      ...(withRoles ? { roles: await availableRoles(user) } : {}),
      suspended: suspended || null,
      pendingPayment: null,
    };
  },

  // Moves the current session to another of the account's roles: the old session ends and a new
  // one starts as `role` (no password needed — it is the same person, already signed in).
  async switchRole(token, role) {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await UserModel.findById(payload.sub);
    await assertUserExists(user);
    if (!(await availableRoles(user)).includes(role)) {
      const err = new Error("You can't sign in with that role");
      err.statusCode = 403;
      throw err;
    }
    await this.endSession(payload);
    const next = await this.startSession(user, role);
    return { user: await this.sessionUser(user, role), token: next };
  },

  // Confirms the CURRENTLY logged-in user really knows their own password, without touching
  // their session (no new token/cookie) — used by the learner-portal's sibling switcher to
  // re-gate a guardian-mediated session before it flips to a different linked learner, since
  // the switch itself is invisible to the server (same JWT either way).
  async verifyPassword(id, password) {
    const user = await UserModel.findById(id);
    if (!user) {
      const err = new Error("User not found");
      err.statusCode = 404;
      throw err;
    }
    const valid = await passwords.compare(password, user.passwordHash);
    if (!valid) {
      const err = new Error("Incorrect password");
      err.statusCode = 401;
      throw err;
    }
    return true;
  },

  // Self-service password change — any authenticated role. Routed through auth.routes.js, which
  // (like every route in that file) uses the bare `protect` exported by auth.middleware.js, not
  // app.js's own protect = [protectBase, blockIfSuspended] — so this is reachable even for a
  // suspended/pending-payment account, same as /me and /verify-password already are. That's the
  // right behavior here: being able to set a real password for yourself shouldn't require your
  // account to be unsuspended first.
  async changePassword(id, { currentPassword, newPassword }) {
    const user = await UserModel.findById(id);
    if (!user) {
      const err = new Error("User not found");
      err.statusCode = 404;
      throw err;
    }
    const valid = await passwords.compare(currentPassword, user.passwordHash);
    if (!valid) {
      const err = new Error("Current password is incorrect");
      err.statusCode = 401;
      throw err;
    }
    const passwordHash = await passwords.hash(newPassword, SALT_ROUNDS);
    await UserModel.update(id, { passwordHash });
    await LearnerPasswordVault.remember(user, newPassword);
    // Fire-and-forget — the change itself is done; this just tells the account's owner it happened.
    accountEmailTarget(user).then((target) => target && sendPasswordChangedEmail(target)).catch(() => {});
    return { message: "Password changed successfully" };
  },

  // "Forgot password" — emails a one-time link to the account's address (see resolveResetTarget
  // for which account and which address). Resolves quietly whatever happens: the caller answers
  // the same way whether or not the identifier matched anything, so this can't be used to find
  // out which emails/usernames have accounts.
  async requestPasswordReset(identifier) {
    const target = await resolveResetTarget(String(identifier || "").trim());
    if (!target) return;
    const since = new Date(Date.now() - 60 * 60 * 1000);
    if ((await PasswordResetTokenModel.countRecentForUser(target.user.id, since)) >= RESET_REQUESTS_PER_HOUR) return;
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + PASSWORD_RESET_MINUTES * 60 * 1000);
    await PasswordResetTokenModel.create({ userId: target.user.id, tokenHash: hashResetToken(token), expiresAt });
    await sendPasswordResetEmail(target, token, expiresAt);
    await PasswordResetTokenModel.pruneExpired();
  },

  // The usable token row behind an emailed link, or a 400 if the link is unknown, used or expired.
  async findUsableResetToken(token) {
    const record = token ? await PasswordResetTokenModel.findByHash(hashResetToken(token)) : null;
    if (!record || record.usedAt || new Date(record.expiresAt).getTime() < Date.now()) throw invalidResetLink();
    return record;
  },

  // Lets the reset page say "this link has expired" up front instead of after the form is filled in.
  async checkResetToken(token) {
    await this.findUsableResetToken(token);
    return { valid: true };
  },

  // Sets a new password from an emailed link. The link (and any other outstanding one for the
  // account) stops working, and the account is signed out everywhere — whoever knew the old
  // password, or was already signed in with it, is out.
  async resetPassword(token, newPassword) {
    const record = await this.findUsableResetToken(token);
    const user = await UserModel.findById(record.userId);
    if (!user) throw invalidResetLink();
    const passwordHash = await passwords.hash(newPassword, SALT_ROUNDS);
    await UserModel.update(user.id, { passwordHash });
    await LearnerPasswordVault.remember(user, newPassword);
    await PasswordResetTokenModel.markAllUsedForUser(user.id);
    await UserSessionModel.deleteByUserId(user.id);
    accountEmailTarget(user).then((target) => target && sendPasswordChangedEmail(target)).catch(() => {});
    return { message: "Your password has been reset. You can now sign in.", userId: user.id };
  },

  // The JWT design has no server-side session to invalidate on its own — jwt.verify() alone
  // considers any correctly-signed, unexpired token valid regardless of whether its owner has
  // since logged out. This records the current token's jti in the denylist protect() checks on
  // every request, so a copied/stolen cookie stops working immediately at logout instead of
  // silently remaining valid until its natural expiry. Verifies the signature (ignoring
  // expiration, since revoking an already-expired token is a harmless no-op) rather than just
  // decoding it, so a malformed or forged token can't be used to plant an arbitrary jti here.
  async logout(token) {
    if (!token) return;
    try {
      const payload = jwt.verify(token, JWT_SECRET, { ignoreExpiration: true });
      if (payload?.jti && payload?.exp) {
        await this.endSession(payload);
      }
    } catch {
      // Not a token we issued — nothing valid to revoke.
    }
    await RevokedTokenModel.pruneExpired();
    await UserSessionModel.pruneStale(SESSION_IDLE_MINUTES + 1);
  },

  // Revokes a verified token's session: denylisted (so the cookie is dead even if the session
  // row were somehow recreated) and its session row removed. Used by logout and by `protect`
  // when a session has gone idle.
  async endSession({ jti, sub, exp }) {
    if (!(await RevokedTokenModel.isRevoked(jti))) {
      await RevokedTokenModel.create({ jti, userId: sub, expiresAt: new Date(exp * 1000) });
    }
    await UserSessionModel.delete(jti);
  },

  // Whether a verified token's session is still live: it must have a session row (tokens from
  // before sessions were tracked don't), and that session must not have gone idle. An idle
  // session is ended on the spot. Returns false for anything that should sign the user out.
  async isSessionActive(payload) {
    if (!payload?.jti) return false;
    const session = await UserSessionModel.findByJti(payload.jti);
    if (!session) return false;
    const idleMs = Date.now() - new Date(session.lastActivityAt).getTime();
    if (idleMs > SESSION_IDLE_MS + SESSION_IDLE_GRACE_MS) {
      await this.endSession(payload);
      // Required here, not at the top: the audit module is only needed for this one event.
      require("../audit/audit.service").recordAuth(null, "session_expired", { user: { id: payload.sub } });
      return false;
    }
    return true;
  },

  // The client's "the user is active" signal (clicks, typing, scrolling, an open assessment) —
  // the only thing that moves lastActivityAt. `protect` has already confirmed the session is live.
  async recordActivity(jti) {
    await UserSessionModel.touch(jti);
  },

  sessionSettings() {
    return { idleTimeoutMs: SESSION_IDLE_MS };
  },

  // `role` is the session's role (from its token); one the account no longer holds falls back to
  // the account's own. A suspended user still gets a valid /me response — the client uses
  // `suspended` to lock them to the in-app "Account Suspended" page. `withRoles` adds the list of
  // roles it can switch to (a lookup per extra role — /me wants it, `protect` doesn't).
  async getById(id, role = null, { withRoles = false } = {}) {
    const user = await UserModel.findById(id);
    await assertUserExists(user);
    const active = role && sessionRolesOf(user).includes(role) ? role : user.role;
    return this.sessionUser(user, active, { withRoles });
  },

  // "What do I owe" for the "payment pending" screen — a learner auto-provisioned from a public
  // bootcamp enrollment (see bootcamp-enrollment.service.js) has a `leads` row linking them to
  // the bootcamp + hub they signed up for; this resolves that lead's bootcamp price and hub name
  // so the price shown at signup is still visible on every later login, not just the one-time
  // confirmation screen. Returns null (not an error) whenever there's nothing to show — a
  // non-learner account, a learner with no such lead (e.g. enrolled the normal admin way), or
  // one that's already fully paid — the client only renders this on the "payment" suspension
  // screen, where a null just means "no price on file, ask the hub."
  async getPendingPayment(user) {
    const pending = await this.pendingPaymentDetails(user);
    if (!pending?.invoiceId) return pending;
    // How to pay it by M-Pesa — the Paybill of the invoice's workspace (null when that's off).
    const { paymentInstructions } = require("../payments/mpesa/mpesa.instructions");
    const invoice = await db("billing_invoices").where({ id: pending.invoiceId }).first();
    return { ...pending, payBy: invoice ? await paymentInstructions(invoice).catch(() => null) : null };
  },

  async pendingPaymentDetails(user) {
    if (!user || user.role !== "learner") return null;
    // Same learner-resolution as resolveSuspension: a dedicated login resolves directly, a
    // guardian-mediated login resolves to whichever child that account's own email currently
    // scopes to (checked by resolveSuspension before this is ever reached, so a mixed-sibling
    // guardian account only gets here for the specific reason: "payment").
    let learnerId = null;
    if (user.username) {
      const learner = await LearnerModel.findByUsername(user.username);
      learnerId = learner?.id || null;
    } else {
      const learners = await LearnerModel.findAll({ guardianEmail: user.email });
      const pending = learners.find((l) => l.accountStatus === "pending_payment");
      learnerId = (pending || learners[0])?.id || null;
    }
    if (!learnerId) return null;

    // Paused because a payment is overdue (billing.access.js): what's overdue on that invoice.
    // Required lazily: billing requires this module.
    const pausedInvoiceId = await require("../billing/billing.access").pausedInvoiceId(learnerId);
    if (pausedInvoiceId) {
      const doc = await require("../billing/billing.service").getInvoiceDocument(pausedInvoiceId);
      if (doc && doc.paymentPlan?.overdueAmount > 0) {
        return {
          kind: "overdue",
          amount: doc.paymentPlan.overdueAmount,
          currency: doc.currency || "KES",
          overdueSince: doc.paymentPlan.overdueSince,
          invoiceId: doc.id,
          invoiceNumber: doc.invoiceNumber,
        };
      }
    }

    const lead = await LeadModel.findByLearnerId(learnerId);
    if (!lead || lead.paidAt || !lead.bootcampId) {
      // Not an unpaid bootcamp — maybe a Home Learning or Tech Club website sign-up awaiting
      // payment. Required lazily: those modules require this one.
      return (await require("../home-learning/home-learning-signup.service").pendingPaymentForLearner(learnerId))
        || require("../tech-clubs/club-signup.service").pendingPaymentForLearner(learnerId);
    }

    const bootcamp = await BootcampModel.findById(lead.bootcampId);
    if (!bootcamp) return null;

    let hubName = null;
    if (lead.hubId) {
      const hub = await LearningHubModel.findById(lead.hubId);
      hubName = hub?.name || null;
    }

    const price = resolveEffectiveBootcampPrice(bootcamp);
    // Enrolments since invoices are raised at sign-up owe what's left on that invoice (and can pay
    // it by M-Pesa); older ones only have the bootcamp's price to show.
    const invoice = lead.invoiceId ? await db("billing_invoices").where({ id: lead.invoiceId }).first() : null;
    if (invoice && ["issued", "partially_paid", "overdue"].includes(invoice.status)) {
      return {
        bootcampName: bootcamp.name,
        amount: Math.max(0, Number(invoice.total) - Number(invoice.amountPaid || 0)),
        currency: invoice.currency || price.currency,
        mode: price.mode,
        hubName,
        invoiceId: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
      };
    }
    return {
      bootcampName: bootcamp.name,
      amount: price.amount,
      currency: price.currency,
      mode: price.mode,
      hubName,
    };
  },

  // `role` is the session's role: only an admin edits their own name, phone and job title here
  // (My profile). Everyone else's details live on their educator/hub/learner record.
  async updateMe(id, data, role = null) {
    const current = await UserModel.findById(id);
    await assertUserExists(current);
    // A parent (a learner-role login with an email, no username) may keep their own name and
    // phone up to date; job title stays admin-only.
    const parent = role === "learner" && !!current.email && !current.username;
    const editable = role === "admin" ? ["name", "phone", "jobTitle"] : parent ? ["name", "phone"] : [];
    if (["name", "phone", "jobTitle"].some((field) => field in data && !editable.includes(field))) {
      const err = new Error("Only an admin can change these details here.");
      err.statusCode = 403;
      throw err;
    }
    // A suspended user can't edit their own profile either — this is a write.
    if (await resolveSuspension(current)) {
      const err = new Error("Your account is suspended.");
      err.statusCode = 403;
      err.code = "ACCOUNT_SUSPENDED";
      throw err;
    }
    const user = await UserModel.update(id, data);
    if (!user) {
      const err = new Error("User not found");
      err.statusCode = 404;
      throw err;
    }
    return sanitize(user);
  },

  // Exposed so middleware (blockIfSuspended) can reuse the exact same resolution.
  resolveSuspension,
};

module.exports = AuthService;
