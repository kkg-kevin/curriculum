const db = require("../../config/db");
const { createRecord, firstOrNull, updateRecord, generateId, stringifyJsonFields } = require("../../shared/utils/model.utils");

const INVOICES = "billing_invoices";
const ITEMS = "billing_invoice_items";
const PAYMENTS = "billing_payments";
const BATCHES = "billing_invoice_batches";
const AUDIT = "billing_audit_events";
const SEQUENCES = "billing_number_sequences";
const INSTALMENTS = "billing_invoice_instalments";

const BillingModel = {
  createInvoice(data, connection = db) { return createRecord(connection, INVOICES, data); },
  // Atomic sequential counter for INV-YYYY-000001 / RCT-YYYY-000001 numbering. LAST_INSERT_ID(expr)
  // is a MySQL idiom for counters on non-AUTO_INCREMENT tables: it sets an arbitrary computed value
  // as the statement's own insertId, safely under concurrent callers because the whole
  // INSERT ... ON DUPLICATE KEY UPDATE runs as one atomic statement (a SELECT...FOR UPDATE here
  // would instead take a gap lock on a not-yet-existing row, and two such locks are mutually
  // compatible — a real deadlock risk on the very first invoice of a year).
  async nextNumber(scope, year, connection = db) {
    // LAST_INSERT_ID(expr) must appear on BOTH branches — a plain INSERT with no AUTO_INCREMENT
    // column reports insertId 0 by default, so wrapping only the ON DUPLICATE KEY UPDATE branch
    // (as MySQL's own docs example does, for tables that also have a real AUTO_INCREMENT id)
    // silently returns 0 for the first-ever call on a fresh (scope, year) row.
    const [result] = await connection.raw(
      `INSERT INTO ${SEQUENCES} (id, scope, year, lastNumber, createdAt, updatedAt)
       VALUES (?, ?, ?, LAST_INSERT_ID(1), NOW(), NOW())
       ON DUPLICATE KEY UPDATE lastNumber = LAST_INSERT_ID(lastNumber + 1), updatedAt = NOW()`,
      [generateId(), scope, year]
    );
    return result.insertId;
  },
  createBatch(data, connection = db) { return createRecord(connection, BATCHES, data); },
  createItem(data, connection = db) { return createRecord(connection, ITEMS, stringifyJsonFields(data, ["metadata"]), { updatedAt: false }); },
  createPayment(data, connection = db) { return createRecord(connection, PAYMENTS, stringifyJsonFields(data, ["metadata"])); },
  // An M-Pesa payment credited before its receipt number was known gets it once it arrives.
  async updatePaymentReference(id, providerReference, connection = db) {
    await connection(PAYMENTS).where({ id }).whereNull("providerReference").update({ providerReference, updatedAt: new Date() });
  },
  findPaymentByIdempotencyKey(idempotencyKey, connection = db) { return idempotencyKey ? firstOrNull(connection(PAYMENTS).where({ idempotencyKey })) : null; },
  createAuditEvent(data, connection = db) { return createRecord(connection, AUDIT, stringifyJsonFields(data, ["metadata"]), { updatedAt: false }); },
  findInvoiceById(id, connection = db, forUpdate = false) {
    let query = connection(INVOICES).where({ id });
    if (forUpdate) query = query.forUpdate();
    return firstOrNull(query);
  },
  findBatchById(id) { return firstOrNull(db(BATCHES).where({ id })); },
  findBatches(filters = {}) {
    let query = db(BATCHES).orderBy("createdAt", "desc");
    for (const [key, value] of Object.entries(filters)) {
      if (value !== undefined && value !== "") query = query.where(key, value);
    }
    return query;
  },
  findInvoicesByBatchId(batchId) { return db(INVOICES).where({ batchId }).orderBy("createdAt", "asc"); },
  findExistingLearnerInvoice({ hubId, learnerId, invoiceType, periodLabel }) {
    return firstOrNull(db(INVOICES).where({ hubId, learnerId, invoiceType, periodLabel: periodLabel || null }).whereNotIn("status", ["cancelled", "void"]));
  },
  findInvoices(filters = {}) {
    let query = db(INVOICES).select("billing_invoices.*").orderBy("createdAt", "desc");
    for (const [key, value] of Object.entries(filters)) {
      if (value !== undefined && value !== "") query = query.where(key, value);
    }
    return query;
  },
  findItems(invoiceId) { return db(ITEMS).where({ invoiceId }).orderBy("createdAt", "asc"); },
  // The reverse lookup of findItems - given item ids (e.g. hub_visits.invoiceItemId), resolve
  // which invoice each belongs to. Used to link a visit back to its invoice's detail page without
  // storing invoiceId redundantly on hub_visits itself (the item already carries it).
  findItemsByIds(ids) { return ids.length ? db(ITEMS).whereIn("id", ids) : []; },
  findPayments(invoiceId) { return db(PAYMENTS).where({ invoiceId }).orderBy("createdAt", "asc"); },
  findPaymentById(id) { return firstOrNull(db(PAYMENTS).where({ id })); },
  findPaymentsByInvoiceIds(invoiceIds) { return invoiceIds.length ? db(PAYMENTS).whereIn("invoiceId", invoiceIds).orderBy("paidAt", "desc") : []; },
  findAuditEvents(invoiceId) { return db(AUDIT).where({ invoiceId }).orderBy("createdAt", "asc"); },
  updateInvoice(id, data, connection = db) { return updateRecord(connection, INVOICES, id, data); },
  updateBatch(id, data, connection = db) { return updateRecord(connection, BATCHES, id, data); },
  // An invoice's payment schedule (billing.instalments.js), in order.
  async findInstalments(invoiceId, connection = db) {
    const rows = await connection(INSTALMENTS).where({ invoiceId }).orderBy("sequence", "asc");
    return rows.map((r) => ({ ...r, amount: Number(r.amount), dueDate: String(r.dueDate).slice(0, 10) }));
  },
  // Replaces it (an empty list removes it).
  async replaceInstalments(invoiceId, rows, connection = db) {
    await connection(INSTALMENTS).where({ invoiceId }).del();
    if (!rows.length) return;
    const now = new Date();
    await connection(INSTALMENTS).insert(rows.map((r, i) => ({
      id: generateId(), invoiceId, sequence: i + 1, label: String(r.label || `Payment ${i + 1}`).slice(0, 80), amount: r.amount, dueDate: r.dueDate, createdAt: now, updatedAt: now,
    })));
  },
  sumSuccessfulPayments(invoiceId, connection = db) {
    return connection(PAYMENTS).where({ invoiceId, status: "successful" }).sum({ total: "amount" }).first();
  },
  transaction(callback) { return db.transaction(callback); },
  generateId,
};

module.exports = BillingModel;
