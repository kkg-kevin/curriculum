const db = require("../../../config/db");
const {
  createRecord,
  updateRecord,
  deleteRecord,
  firstOrNull,
  stringifyJsonFields,
} = require("../../../shared/utils/model.utils");

const TABLE = "pathway_templates";
const JSON_FIELDS = ["courses"];

const PathwayModel = {
  findAll({ ownerAdminId } = {}) {
    let query = db(TABLE);
    if (ownerAdminId) query = query.where({ ownerAdminId });
    return query;
  },

  findById(id) {
    return firstOrNull(db(TABLE).where({ id }));
  },

  findByIds(ids) {
    return db(TABLE).whereIn("id", ids);
  },

  create(data) {
    return createRecord(db, TABLE, stringifyJsonFields(data, JSON_FIELDS));
  },

  update(id, data) {
    return updateRecord(db, TABLE, id, stringifyJsonFields(data, JSON_FIELDS));
  },

  delete(id) {
    return deleteRecord(db, TABLE, id);
  },
};

module.exports = PathwayModel;
