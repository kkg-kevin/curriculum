const { z } = require("zod");

const householdSchema = z.object({
  guardianName: z.string().trim().min(1).max(150),
  guardianEmail: z.string().trim().email().optional().or(z.literal("")),
  guardianPhone: z.string().trim().min(1).max(30),
  county: z.string().trim().max(100).optional().or(z.literal("")),
  subCounty: z.string().trim().max(100).optional().or(z.literal("")),
  town: z.string().trim().max(100).optional().or(z.literal("")),
  addressLine: z.string().trim().max(255).optional().or(z.literal("")),
  landmark: z.string().trim().max(255).optional().or(z.literal("")),
  childCount: z.coerce.number().int().min(1).max(20),
  status: z.enum(["pending", "active", "paused", "cancelled"]).optional(),
  startDate: z.string().optional().or(z.literal("")),
  notes: z.string().max(5000).optional().or(z.literal("")),
});

const enrollmentSchema = z.object({
  learnerId: z.string().min(1),
  curriculumId: z.string().min(1),
  educatorId: z.string().optional().or(z.literal("")),
  status: z.enum(["active", "paused", "completed"]).default("active"),
});

module.exports = { householdSchema, enrollmentSchema };
