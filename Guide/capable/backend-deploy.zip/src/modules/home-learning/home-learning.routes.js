const express = require("express");
const { authorize } = require("../../shared/middleware/auth.middleware");
const controller = require("./home-learning.controller");

const router = express.Router();
router.get("/", authorize("admin"), controller.list);
router.get("/educator", authorize("teacher"), controller.getForEducator);
router.post("/", authorize("admin"), controller.create);
router.put("/:id", authorize("admin"), controller.update);
router.post("/:id/learners", authorize("admin"), controller.setEnrollment);
router.post("/:id/learners/new", authorize("admin"), controller.createLearner);
router.delete("/:id/learners/:learnerId", authorize("admin"), controller.removeEnrollment);
router.get("/learner/:learnerId", authorize("learner"), controller.getForLearner);

module.exports = router;
