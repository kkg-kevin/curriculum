const db = require("../../config/db");
const HouseholdModel = require("./home-learning.model");
const LearnerModel = require("../learners/learner.model");
const LearnerHubLinkModel = require("../learners/learner-hub-link.model");
const CurriculumModel = require("../curriculum/curriculum.model");
const TeacherModel = require("../teachers/teacher.model");
const TeacherHubLinkModel = require("../teachers/teacher-hub-link.model");
const LearningHubModel = require("../learning-hubs/learning-hub.model");
const LearnerService = require("../learners/learner.service");
const AuthService = require("../auth/auth.service");
const { createLearnerSchema } = require("../learners/learner.validation");
const { householdSchema, enrollmentSchema } = require("./home-learning.validation");

function fail(message, statusCode = 400) {
  throw Object.assign(new Error(message), { statusCode });
}

function priceFor(childCount) {
  if (childCount === 1) return { planCode: "one_child", monthlyAmount: 8000 };
  if (childCount === 3) return { planCode: "three_children", monthlyAmount: 15000 };
  if (childCount >= 5) return { planCode: "five_plus", monthlyAmount: 24000 + (childCount - 5) * 7000 };
  fail("Home Learning packages are available for 1, 3, or 5+ children. Contact the team for 2 or 4 children.");
}

const HomeLearningService = {
  list(ownerAdminId) {
    return HouseholdModel.findAll(ownerAdminId);
  },

  getHousehold(ownerAdminId, id) {
    return HouseholdModel.findById(id, ownerAdminId);
  },

  async create(ownerAdminId, input) {
    const parsed = householdSchema.safeParse(input);
    if (!parsed.success) fail(parsed.error.issues[0]?.message || "Invalid household details");
    const price = priceFor(parsed.data.childCount);
    return HouseholdModel.createHousehold({
      ...parsed.data,
      ownerAdminId,
      ...price,
      status: parsed.data.status || "pending",
      guardianEmail: parsed.data.guardianEmail || null,
      startDate: parsed.data.startDate || null,
      notes: parsed.data.notes || null,
    });
  },

  async update(ownerAdminId, id, input) {
    const parsed = householdSchema.partial().safeParse(input);
    if (!parsed.success) fail(parsed.error.issues[0]?.message || "Invalid household details");
    const existing = await HouseholdModel.findById(id, ownerAdminId);
    if (!existing) fail("Household not found", 404);
    const updates = { ...parsed.data };
    if (updates.childCount !== undefined) {
      const active = await db("home_learning_enrollments").where({ householdId: id, ownerAdminId, status: "active" }).count({ count: "*" }).first();
      if (Number(active?.count || 0) > updates.childCount) fail("Remove child enrollments before reducing the package size");
      Object.assign(updates, priceFor(updates.childCount));
    }
    if (updates.guardianEmail === "") updates.guardianEmail = null;
    if (updates.startDate === "") updates.startDate = null;
    return HouseholdModel.updateHousehold(id, ownerAdminId, updates);
  },

  async setEnrollment(ownerAdminId, householdId, input) {
    const parsed = enrollmentSchema.safeParse(input);
    if (!parsed.success) fail(parsed.error.issues[0]?.message || "Invalid learner enrollment");
    const household = await HouseholdModel.findById(householdId, ownerAdminId);
    if (!household) fail("Household not found", 404);
    const learner = await LearnerModel.findById(parsed.data.learnerId);
    if (!learner) fail("Learner not found", 404);
    const existingHomeIds = await HouseholdModel.findLearnerIds(ownerAdminId);
    const ownHubs = await LearningHubModel.findAll({ ownerAdminId, includeDrafts: true });
    const ownHubIds = new Set(ownHubs.map((hub) => hub.id));
    const learnerHubLinks = await LearnerHubLinkModel.findByLearnerId(learner.id);
    if (!existingHomeIds.includes(learner.id) && !learnerHubLinks.some((link) => ownHubIds.has(link.hubId))) {
      fail("This learner is not available in your workspace", 404);
    }
    const curriculum = await CurriculumModel.findById(parsed.data.curriculumId);
    if (!curriculum || curriculum.ownerAdminId !== ownerAdminId) fail("Curriculum not found", 404);
    let educatorId = parsed.data.educatorId || null;
    if (educatorId) {
      const educator = await TeacherModel.findById(educatorId);
      if (!educator) fail("Educator not found", 404);
      const ownHubIds = new Set((await LearningHubModel.findAll({ ownerAdminId, includeDrafts: true })).map((hub) => hub.id));
      const educatorLinks = await TeacherHubLinkModel.findByTeacherId(educatorId);
      if (!educatorLinks.some((link) => ownHubIds.has(link.hubId))) fail("This educator is not available in your workspace", 404);
    }
    const count = await db("home_learning_enrollments").where({ householdId, ownerAdminId, status: "active" }).count({ count: "*" }).first();
    const existing = await db("home_learning_enrollments").where({ householdId, ownerAdminId, learnerId: learner.id }).first();
    const otherHousehold = await db("home_learning_enrollments")
      .where({ learnerId: learner.id })
      .whereNot({ householdId })
      .first();
    if (otherHousehold) fail("This learner is already linked to a Home Learning household");
    const alreadyActive = existing?.status === "active";
    if (parsed.data.status === "active" && !alreadyActive && Number(count?.count || 0) >= household.childCount) {
      fail("This household package has no available child places");
    }
    return HouseholdModel.upsertEnrollment({
      ownerAdminId,
      householdId,
      learnerId: learner.id,
      curriculumId: curriculum.id,
      educatorId,
      status: parsed.data.status,
    });
  },

  async createLearner(ownerAdminId, householdId, input) {
    const household = await HouseholdModel.findById(householdId, ownerAdminId);
    if (!household) fail("Household not found", 404);
    const count = await db("home_learning_enrollments").where({ householdId, ownerAdminId, status: "active" }).count({ count: "*" }).first();
    if (Number(count?.count || 0) >= household.childCount) fail("This household package has no available child places");
    const enrollment = enrollmentSchema.safeParse({
      learnerId: "pending",
      curriculumId: input.curriculumId,
      educatorId: input.educatorId,
      status: input.status || "active",
    });
    if (!enrollment.success) fail(enrollment.error.issues[0]?.message || "Invalid learner enrollment");
    const curriculum = await CurriculumModel.findById(enrollment.data.curriculumId);
    if (!curriculum || curriculum.ownerAdminId !== ownerAdminId) fail("Curriculum not found", 404);
    if (enrollment.data.educatorId) {
      const educator = await TeacherModel.findById(enrollment.data.educatorId);
      if (!educator) fail("Educator not found", 404);
      const ownHubIds = new Set((await LearningHubModel.findAll({ ownerAdminId, includeDrafts: true })).map((hub) => hub.id));
      const educatorLinks = await TeacherHubLinkModel.findByTeacherId(enrollment.data.educatorId);
      if (!educatorLinks.some((link) => ownHubIds.has(link.hubId))) fail("This educator is not available in your workspace", 404);
    }

    const parsed = createLearnerSchema.safeParse({
      ...input.learner,
      guardianName: household.guardianName,
      guardianPhone: household.guardianPhone,
      guardianEmail: household.guardianEmail || "",
    });
    if (!parsed.success) fail(parsed.error.issues[0]?.message || "Invalid learner details");
    const { password, learnerPassword, ...learnerData } = parsed.data;
    if (password) await AuthService.setOrCreatePassword({ name: household.guardianName, email: learnerData.guardianEmail, password, role: "learner" });
    const learner = await LearnerService.createLearner(learnerData);
    if (learnerPassword) {
      await AuthService.setOrCreatePasswordByUsername({
        name: `${learner.firstName} ${learner.lastName}`.trim(),
        username: learner.username,
        password: learnerPassword,
        role: "learner",
      });
    }
    await HouseholdModel.createEnrollment({
      ownerAdminId,
      householdId,
      learnerId: learner.id,
      curriculumId: curriculum.id,
      educatorId: enrollment.data.educatorId || null,
      status: enrollment.data.status,
    });
    return learner;
  },

  async removeEnrollment(ownerAdminId, householdId, learnerId) {
    const household = await HouseholdModel.findById(householdId, ownerAdminId);
    if (!household) fail("Household not found", 404);
    await HouseholdModel.removeEnrollment(householdId, learnerId, ownerAdminId);
    return { removed: true };
  },

  getForLearner(learnerId) {
    return HouseholdModel.findForLearner(learnerId);
  },

  getForEducator(educatorId) {
    return HouseholdModel.findAssignmentsForEducator(educatorId);
  },

  priceFor,
};

module.exports = HomeLearningService;
