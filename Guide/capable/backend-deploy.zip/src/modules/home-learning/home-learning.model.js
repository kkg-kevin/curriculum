const db = require("../../config/db");
const { createRecord, updateRecord, firstOrNull } = require("../../shared/utils/model.utils");

const HouseholdModel = {
  async findAll(ownerAdminId) {
    const households = await db("home_learning_households")
      .where({ ownerAdminId })
      .orderBy("createdAt", "desc");
    if (!households.length) return [];
    const links = await db("home_learning_enrollments")
      .where({ ownerAdminId })
      .whereIn("householdId", households.map((h) => h.id));
    const learnerIds = [...new Set(links.map((l) => l.learnerId))];
    const learners = learnerIds.length ? await db("learners").whereIn("id", learnerIds) : [];
    const curricula = [...new Set(links.map((l) => l.curriculumId))];
    const curriculumRows = curricula.length ? await db("curricula").whereIn("id", curricula) : [];
    const educatorIds = [...new Set(links.map((l) => l.educatorId).filter(Boolean))];
    const educators = educatorIds.length ? await db("teachers").whereIn("id", educatorIds) : [];
    return households.map((household) => ({
      ...household,
      learners: links.filter((l) => l.householdId === household.id).map((link) => ({
        ...link,
        learner: (() => {
          const learner = learners.find((l) => l.id === link.learnerId);
          return learner ? { id: learner.id, firstName: learner.firstName, lastName: learner.lastName, gender: learner.gender, photo: learner.photo, registrationNumber: learner.registrationNumber } : null;
        })(),
        curriculum: (() => {
          const curriculum = curriculumRows.find((c) => c.id === link.curriculumId);
          return curriculum ? { id: curriculum.id, name: curriculum.name } : null;
        })(),
        educator: (() => {
          const educator = educators.find((e) => e.id === link.educatorId);
          return educator ? { id: educator.id, firstName: educator.firstName, lastName: educator.lastName, photo: educator.photo } : null;
        })(),
      })),
    }));
  },

  findById(id, ownerAdminId) {
    return firstOrNull(db("home_learning_households").where({ id, ownerAdminId }));
  },

  async findForLearner(learnerId) {
    const links = await db("home_learning_enrollments")
      .where({ learnerId, status: "active" })
      .orderBy("createdAt", "desc");
    const result = [];
    for (const link of links) {
      const household = await firstOrNull(db("home_learning_households")
        .where({ id: link.householdId, ownerAdminId: link.ownerAdminId, status: "active" }));
      if (!household) continue;
      const curriculum = await firstOrNull(db("curricula").where({ id: link.curriculumId }));
      const educatorRow = link.educatorId ? await firstOrNull(db("teachers").where({ id: link.educatorId })) : null;
      const educator = educatorRow ? { id: educatorRow.id, firstName: educatorRow.firstName, lastName: educatorRow.lastName, photo: educatorRow.photo } : null;
      result.push({ ...link, household: { id: household.id, guardianName: household.guardianName }, curriculum, educator });
    }
    return result;
  },

  async findCurriculaForEducator(educatorId) {
    if (!educatorId) return [];
    const links = await db("home_learning_enrollments").where({ educatorId, status: "active" });
    const ids = [];
    for (const link of links) {
      const household = await firstOrNull(db("home_learning_households").where({ id: link.householdId, ownerAdminId: link.ownerAdminId, status: "active" }));
      if (household) ids.push(link.curriculumId);
    }
    return [...new Set(ids)];
  },

  async findLearnerIds(ownerAdminId) {
    const rows = await db("home_learning_enrollments").where({ ownerAdminId });
    return [...new Set(rows.map((row) => row.learnerId))];
  },

  async findAssignmentsForEducator(educatorId) {
    if (!educatorId) return [];
    const links = await db("home_learning_enrollments").where({ educatorId, status: "active" }).orderBy("createdAt", "desc");
    const result = [];
    for (const link of links) {
      const household = await firstOrNull(db("home_learning_households").where({ id: link.householdId, ownerAdminId: link.ownerAdminId, status: "active" }));
      if (!household) continue;
      const [learner, curriculum] = await Promise.all([
        firstOrNull(db("learners").where({ id: link.learnerId })),
        firstOrNull(db("curricula").where({ id: link.curriculumId })),
      ]);
      result.push({
        id: link.id,
        learner: learner ? { id: learner.id, firstName: learner.firstName, lastName: learner.lastName, photo: learner.photo } : null,
        curriculum: curriculum ? { id: curriculum.id, name: curriculum.name } : null,
        household: {
          guardianName: household.guardianName,
          guardianPhone: household.guardianPhone,
          guardianEmail: household.guardianEmail,
          county: household.county,
          subCounty: household.subCounty,
          town: household.town,
          addressLine: household.addressLine,
          landmark: household.landmark,
        },
      });
    }
    return result;
  },

  createHousehold(data) {
    return createRecord(db, "home_learning_households", data);
  },

  async createEnrollment(data) {
    return createRecord(db, "home_learning_enrollments", data);
  },

  async removeEnrollment(householdId, learnerId, ownerAdminId) {
    return db("home_learning_enrollments").where({ householdId, learnerId, ownerAdminId }).del();
  },

  async updateHousehold(id, ownerAdminId, data) {
    const existing = await firstOrNull(db("home_learning_households").where({ id, ownerAdminId }));
    if (!existing) return null;
    await updateRecord(db, "home_learning_households", id, data);
    return firstOrNull(db("home_learning_households").where({ id, ownerAdminId }));
  },

  async upsertEnrollment(data) {
    const existing = await firstOrNull(db("home_learning_enrollments").where({
      householdId: data.householdId,
      learnerId: data.learnerId,
      ownerAdminId: data.ownerAdminId,
    }));
    if (existing) {
      await updateRecord(db, "home_learning_enrollments", existing.id, {
        curriculumId: data.curriculumId,
        educatorId: data.educatorId,
        status: data.status,
      });
      return firstOrNull(db("home_learning_enrollments").where({ id: existing.id }));
    }
    return createRecord(db, "home_learning_enrollments", data);
  },
};

module.exports = HouseholdModel;
