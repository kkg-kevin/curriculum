const asyncHandler = require("express-async-handler");
const HomeLearningService = require("./home-learning.service");

const list = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await HomeLearningService.list(req.ownerAdminId) });
});

const create = asyncHandler(async (req, res) => {
  const household = await HomeLearningService.create(req.ownerAdminId, req.body);
  res.status(201).json({ success: true, data: household });
});

const update = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await HomeLearningService.update(req.ownerAdminId, req.params.id, req.body) });
});

const setEnrollment = asyncHandler(async (req, res) => {
  res.status(201).json({ success: true, data: await HomeLearningService.setEnrollment(req.ownerAdminId, req.params.id, req.body) });
});

const createLearner = asyncHandler(async (req, res) => {
  const learner = await HomeLearningService.createLearner(req.ownerAdminId, req.params.id, req.body);
  res.status(201).json({ success: true, data: learner });
});

const removeEnrollment = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await HomeLearningService.removeEnrollment(req.ownerAdminId, req.params.id, req.params.learnerId) });
});

const getForLearner = asyncHandler(async (req, res) => {
  if (req.ownLearner?.id !== req.params.learnerId) {
    return res.status(403).json({ success: false, message: "You do not have permission to access this learner" });
  }
  res.json({ success: true, data: await HomeLearningService.getForLearner(req.params.learnerId) });
});

const getForEducator = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await HomeLearningService.getForEducator(req.ownTeacher?.id) });
});

module.exports = { list, create, update, setEnrollment, createLearner, removeEnrollment, getForLearner, getForEducator };
