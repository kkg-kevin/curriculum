const path = require("path");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const env = require("./config/env");
const authRoutes = require("./modules/auth/auth.routes");
const curriculumRoutes = require("./modules/curriculum/curriculum.routes");
const competencyRoutes = require("./modules/settings/competencies/competency.routes");
const pathwayTemplateRoutes = require("./modules/settings/pathways/pathway-template.routes");
const systemLevelRoutes = require("./modules/settings/system-levels/system-level.routes");
// Settings → Items: one catalog of Goods (formerly Inventory) and Services (formerly billing items).
const { itemsRouter, goodsRouter } = require("./modules/settings/items/items.routes");
const learningHubRoutes = require("./modules/learning-hubs/learning-hub.routes");
const teacherRoutes = require("./modules/teachers/teacher.routes");
const classRoutes = require("./modules/classes/class.routes");
const classGroupRoutes = require("./modules/classes/groups/class-group.routes");
const roomRoutes = require("./modules/rooms/room.routes");
const learnerRoutes = require("./modules/learners/learner.routes");
const parentRoutes = require("./modules/parent/parent.routes");
const { parentOnly } = require("./modules/parent/parent.access");
const publicLearnerProfileRoutes = require("./modules/learners/public-profile.routes");
const courseRoutes = require("./modules/courses/course.routes");
const attendanceRoutes = require("./modules/attendance/attendance.routes");
const timetableRoutes = require("./modules/timetable/timetable.routes");
const assessmentRoutes = require("./modules/assessments/assessment.routes");
const { draftRouter } = require("./modules/drafts/draft.routes");
const assessmentSubmissionRoutes = require("./modules/assessments/submissions/assessment-submission.routes");
const reportRoutes = require("./modules/reports/report.routes");
const analyticsRoutes = require("./modules/analytics/analytics.routes");
const certificateRoutes = require("./modules/certificates/certificate.routes");
const { settingsRouter: certificateSettingsRoutes } = certificateRoutes;
const publicCertificateRoutes = require("./modules/certificates/public-certificate.routes");
const uploadRoutes = require("./modules/uploads/upload.routes");
const competitionRoutes = require("./modules/competitions/competition.routes");
const bootcampRoutes = require("./modules/bootcamps/bootcamp.routes");
const notificationRoutes = require("./modules/notifications/notification.routes");
const billingRoutes = require("./modules/billing/billing.routes");
const mpesaRoutes = require("./modules/payments/mpesa/mpesa.routes");
const { publicRouter: publicPaymentRoutes, settingsRouter: paymentSettingsRoutes } = mpesaRoutes;
const mpesaCallbackRoutes = require("./modules/payments/mpesa/mpesa-callback.routes");
const paymentNoticeRoutes = require("./modules/payments/payment-notices.routes");
const orderRoutes = require("./modules/orders/orders.routes");
const hubVisitRoutes = require("./modules/hub-visits/hub-visit.routes");
const publicLeadRoutes = require("./modules/leads/public-lead.routes");
const publicBootcampEnrollmentRoutes = require("./modules/bootcamp-enrollment/bootcamp-enrollment.routes");
const publicParentSignupRoutes = require("./modules/auth/parent-signup.routes");
const publicPathwayEnrollmentRoutes = require("./modules/pathway-enrollment/pathway-enrollment.routes");
const leadRoutes = require("./modules/leads/lead.routes");
const publicSiteRoutes = require("./modules/public-site/public-site.routes");
const publicDiagnosticRoutes = require("./modules/public-site/public-diagnostic.routes");
const { workspaceRouter: emailSettingsRoutes, publicRouter: publicEmailPreferenceRoutes } = require("./modules/notifications/email-settings.routes");
const homeLearningRoutes = require("./modules/home-learning/home-learning.routes");
const techClubRoutes = require("./modules/tech-clubs/club.routes");
const pathwaySubscriptionRoutes = require("./modules/pathway-subscriptions/pathway-subscription.routes");
const accessRoutes = require("./modules/access/access.routes");
const sharingRoutes = require("./modules/sharing/sharing.routes");
const auditRoutes = require("./modules/audit/audit.routes");
const claimRoutes = require("./modules/claims/claim.routes");
const checkinRoutes = require("./modules/checkins/checkin.routes");
const totRoutes = require("./modules/tot/tot.routes");
const qaRoutes = require("./modules/qa/qa.routes");
const mentorCheckinRoutes = require("./modules/mentor-checkins/mentor-checkin.routes");
const mentorStandardRoutes = require("./modules/mentor-standards/mentor-standards.routes");
const { router: mentorReviewRoutes, publicRouter: publicMentorReviewRoutes } = require("./modules/mentor-reviews/mentor-review.routes");
const { router: educatorProfileRoutes, publicRouter: publicEducatorProfileRoutes } = require("./modules/educator-profiles/educator-profile.routes");
const { router: affiliateRoutes, publicRouter: publicAffiliateRoutes } = require("./modules/affiliates/affiliate.routes");
const reassignOwnerRoutes = require("./modules/admin-tools/reassign-owner.routes");
const collaboratorRoutes = require("./modules/admin-tools/collaborator.routes");
const { errorHandler, notFound } = require("./shared/middleware/error.middleware");
const { protect: protectBase, authorize, blockIfSuspended, blockHubLeadWrites, blockIfCollaboratorRestricted } = require("./shared/middleware/auth.middleware");
const { attachOwnRecords } = require("./shared/middleware/scope.middleware");
const { auditTrail } = require("./shared/middleware/audit.middleware");
const { apiRateLimitKey } = require("./shared/middleware/rate-limit.middleware");
const { setUploadHeaders } = require("./modules/uploads/upload.static");
const db = require("./config/db");

// Every authenticated route already mounts `protect`; pairing it here with `blockIfSuspended`
// means a suspended account keeps a read-only session everywhere but is refused every write in
// one place, without touching each route file. `protect` is exported as `protectBase` and
// re-exposed as this array so the existing `protect, ...` mount calls below need no change.
// blockHubLeadWrites does the same for an Account Manager / Training Lead's view-only hub portal.
const protect = [protectBase, blockIfSuspended, blockHubLeadWrites];

const app = express();

// Behind the hosting's own web server every request arrives from that server, so without this
// the per-address limits below see all users as one address. TRUST_PROXY says how many proxies
// sit in front (usually 1) so the real address is read from X-Forwarded-For. Unset, nothing
// changes. Set it only after checking on the host — see env.js.
if (env.TRUST_PROXY !== undefined) app.set("trust proxy", env.TRUST_PROXY);

app.use(
  helmet({
    // This is a JSON API — the only HTML-adjacent response is the "/" health check, which
    // returns JSON too, so there's no page for a CSP to protect and the default policy only
    // risks conflicting with the client's own. Static /uploads files (photos, assessment
    // media) are fetched cross-origin by the client's <img>/<video> tags, so the default
    // same-origin resource policy would silently block them from loading.
    contentSecurityPolicy: false,
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);
// The admin client (CLIENT_URL) sends cookies and needs credentials: true. The public
// digifunzi-landing site (PUBLIC_SITE_URL) never sends a JWT/cookie (see its src/services/api.js)
// and only ever reaches the /api/public/* routes below, but still needs its origin allowed or the
// browser blocks the request before it reaches Express at all.
//
// PUBLIC_SITE_URL is comma-separated: the landing site is served from more than one origin
// (apex + www + staging) and its build-time prerender step runs from yet another origin
// (http://localhost:4199) — see Guide/WEBSITE_INTEGRATION_CONTRACT.md §5. A request with no
// Origin header at all (server-to-server curl, same-origin) is always allowed.
const allowedOrigins = [
  env.CLIENT_URL,
  ...String(env.PUBLIC_SITE_URL || "")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean),
].filter(Boolean);
app.use(cors({
  // A disallowed origin gets `false` (no CORS headers set → the browser blocks it), not a
  // thrown Error — throwing would surface as a confusing 500 in our logs for what is really
  // just an un-whitelisted caller. A request with no Origin header (server-to-server curl,
  // the prerender step in some modes) is always allowed.
  origin(origin, cb) {
    cb(null, !origin || allowedOrigins.includes(origin));
  },
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  credentials: true,
}));
app.use(express.json());
app.use(cookieParser());
app.use(morgan("dev"));
app.use("/uploads", express.static(path.join(__dirname, "../uploads"), { setHeaders: setUploadHeaders }));
// The brand logo in every email's header — mail apps fetch it from here (see mail.layout.js).
app.use("/email-assets", express.static(path.join(__dirname, "shared/mail/assets"), { maxAge: "30d" }));

app.get("/", (req, res) => {
  res.json({ message: "API is running" });
});

// For an uptime monitor: 200 when the API can reach its database, 503 when it can't. Outside
// /api, so it is neither rate limited nor written to the activity log.
app.get("/health", async (req, res) => {
  try {
    await db.raw("select 1").timeout(5000);
    res.json({ status: "ok" });
  } catch {
    res.status(503).json({ status: "unavailable" });
  }
});

// General abuse/runaway-loop backstop for everything under /api — login already has its own
// stricter limiter layered on top of this one. Deliberately generous (same reasoning as
// loginLimiter in auth.routes.js: a school/office network puts many real concurrent users
// behind one shared IP, and this app's own polling — notifications every 60s, a teacher's
// per-class dashboard queries — can legitimately add up to a lot of requests from one IP over
// 15 minutes). This isn't meant to shape normal traffic, just cap the pathological case (a
// broken client retry loop, a scraper) before it can degrade the shared connection pool for
// everyone else.
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 3000,
  // Signed-in requests are counted per account, the rest per address — see apiRateLimitKey.
  keyGenerator: apiRateLimitKey,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests. Please try again later." },
});
app.use("/api", apiLimiter);
// The activity log: every change-making request under /api is recorded (who, what, when, what
// changed) — once, here, so no route can be left out. See shared/middleware/audit.middleware.js.
app.use("/api", auditTrail);

app.use("/api/auth", authRoutes);
// Unauthenticated by design — the "share via QR" destination for a learner's public profile
// link. Deliberately its own router (not a route inside learnerRoutes) so it can never end up
// behind the `protect` chain every other /api/learners route is mounted with below. Read-only,
// and scoped by learner.service.js's getPublicProfile to a hand-picked, deliberately narrow
// field set — see that function's comment for exactly what it excludes.
app.use("/api/public/learners", publicLearnerProfileRoutes);
// Unauthenticated by design — checking a course certificate from the QR / link printed on it.
// The token in the URL is the only access control; see certificate.service.js's verify.
app.use("/api/public/certificates", publicCertificateRoutes);
// Unauthenticated by design — the digifunzi-landing site's Enroll/Contact forms (see
// public-lead.routes.js). Mounted at /api/public rather than /api/public/leads since it
// serves both /api/public/leads and /api/public/contact.
app.use("/api/public", publicLeadRoutes);
// Unauthenticated by design — the digifunzi-landing site's Pathways listing and detail pages
// (see public-site.routes.js).
app.use("/api/public", publicSiteRoutes);
// Unauthenticated by design — the website's "What parents say": parent comments the parent agreed to
// share and an admin featured (modules/mentor-reviews/).
app.use("/api/public", publicMentorReviewRoutes);
// Unauthenticated by design — a PUBLISHED educator profile, read by the portal's own share page
// (/public/educators/:slug). Only what educator-profile.service.js's publicView allows; nothing is
// collected from anyone.
app.use("/api/public", publicEducatorProfileRoutes);
// Unauthenticated by design — the website checks a typed referral code (only valid / not, never
// whose it is). See modules/affiliates/.
app.use("/api/public", publicAffiliateRoutes);
// Unauthenticated by design — the anonymous public diagnostic feature (pick a pathway, take a
// diagnostic, see a graded report on the spot). Reads/grades against the ONE admin tenant
// PUBLIC_CONTENT_ADMIN_ID designates (see env.js) — never the caller's own tenant, since there
// is no caller identity here at all. Own rate limiters, see public-diagnostic.routes.js.
app.use("/api/public", publicDiagnosticRoutes);
// Unauthenticated by design — a bootcamp's public enrollment flow. Auto-provisions a real learner
// account (see bootcamp-enrollment.service.js) instead of just sending a lead for a human to
// follow up on. The admin-only "mark paid" counterpart lives on the existing protected
// /api/leads router instead (see lead.routes.js).
app.use("/api/public", publicBootcampEnrollmentRoutes);
// Unauthenticated by design — "Already have an account? Sign in" on a website sign-up: a parent's
// email + password give back a short-lived parent token for the form, never a portal session.
app.use("/api/public", publicParentSignupRoutes);
// Unauthenticated by design — a priced pathway's website enrolment: logins, the hub, one invoice.
app.use("/api/public", publicPathwayEnrollmentRoutes);
// Unauthenticated by design — the "choose which emails you get" link in an email's footer. The
// token in the link opens one account's email preferences and nothing else.
app.use("/api/public", publicEmailPreferenceRoutes);
// Unauthenticated by design — Safaricom telling us about M-Pesa payments. The secret token in the
// path is the access control; see mpesa-callback.routes.js.
app.use("/api/public/pay-hooks", mpesaCallbackRoutes);
// Unauthenticated by design — paying one invoice from a link, without signing in (the website's
// "Pay now" after a sign-up). The token in the path opens that one invoice's amount; see
// payments/payment-links.js.
app.use("/api/public/payments", publicPaymentRoutes);
// The same link's "I've paid" (an M-Pesa code, bank reference, cheque number or cash to come) for
// staff to confirm — see payments/payment-notices.service.js.
app.use("/api/public/payments", paymentNoticeRoutes.publicRouter);
// Unauthenticated by design — the website's cart checkout (Store goods and Projects); see
// modules/orders/orders.service.js.
app.use("/api/public", orderRoutes.publicRouter);

// Everything below requires a logged-in session. Curriculum authoring, settings, assessments
// (builder) and uploads are admin-only in full; curriculum.routes.js carves out the two
// non-admin reads a school inherits (its curriculum, and that curriculum's current courses)
// before the router-wide admin gate — attachOwnRecords is mounted here too so those routes can
// verify the requested curriculum is actually the caller's own. Learning hubs/teachers/classes/
// learners are read (and, for "school"-type hubs, written) by more than one role, so their
// own routes files apply per-method role checks plus attachOwnRecords-based ownership scoping —
// a school/teacher/learner account can only ever touch its own school's data, never another's.
app.use("/api/curricula", protect, attachOwnRecords, curriculumRoutes);
app.use("/api/competencies", protect, attachOwnRecords, authorize("admin"), competencyRoutes);
app.use("/api/pathway-templates", protect, attachOwnRecords, authorize("admin"), pathwayTemplateRoutes);
app.use("/api/system-levels", protect, attachOwnRecords, authorize("admin"), systemLevelRoutes);
app.use("/api/inventory", protect, attachOwnRecords, authorize("admin"), goodsRouter);
app.use("/api/items", protect, attachOwnRecords, authorize("admin"), itemsRouter);
app.use("/api/learning-hubs", protect, attachOwnRecords, learningHubRoutes);
app.use("/api/teachers", protect, attachOwnRecords, teacherRoutes);
app.use("/api/classes", protect, attachOwnRecords, classRoutes);
// Reusable class-level learner groups, for group-based assessments — see class-group.routes.js.
app.use("/api/class-groups", protect, attachOwnRecords, classGroupRoutes);
app.use("/api/rooms", protect, attachOwnRecords, roomRoutes);
app.use("/api/learners", protect, attachOwnRecords, learnerRoutes);
// The parent portal — a parent login's family view across all their children (parent.service.js).
app.use("/api/parent", protect, attachOwnRecords, parentOnly, parentRoutes);
app.use("/api/home-learning", protect, attachOwnRecords, homeLearningRoutes);
// Estate Tech Club memberships (website sign-ups, placement, monthly invoices) — see modules/tech-clubs/.
app.use("/api/tech-clubs", protect, attachOwnRecords, techClubRoutes);
// Website pathways sold by subscription — plans, subscriptions, a learner's pathway access (modules/pathway-subscriptions/).
app.use("/api/pathway-subscriptions", protect, attachOwnRecords, pathwaySubscriptionRoutes);
// Add/Edit Course's and the session editor's unsaved work (see draft.routes.js) — mounted first, so
// "drafts" never reaches the courses router below as a course id.
app.use("/api/courses/drafts", protect, attachOwnRecords, authorize("admin"), draftRouter(["course", "course-session"]));
app.use("/api/courses", protect, attachOwnRecords, courseRoutes);
app.use("/api/attendance", protect, attachOwnRecords, attendanceRoutes);
// Same shape as attendance — a timetable slot belongs to a Class, ownership resolved through it.
app.use("/api/timetable", protect, attachOwnRecords, timetableRoutes);
// The assessment builder's unsaved work (see draft.routes.js) — mounted first, so "drafts" never
// reaches the assessments router below as an assessment id.
app.use("/api/assessments/drafts", protect, attachOwnRecords, authorize("admin"), draftRouter(["assessment"]));
// Authoring stays admin-only, but one read (an assessment's linked competencies) is needed by
// teacher/school too, when grading — see assessment.routes.js for the per-route split.
app.use("/api/assessments", protect, attachOwnRecords, assessmentRoutes);
// Issuing/taking/grading is not authoring — teacher/school/learner reach it here, scoped by
// attachOwnRecords, while the assessment *builder* above stays admin-only.
app.use("/api/assessment-submissions", protect, attachOwnRecords, assessmentSubmissionRoutes);
// Course reports read off graded submissions above — same not-authoring, multi-role,
// attachOwnRecords-scoped shape.
app.use("/api/reports", protect, attachOwnRecords, reportRoutes);
// Reports & Analytics tabs (logins, time to task, assessments, competencies, at risk).
app.use("/api/analytics", protect, attachOwnRecords, analyticsRoutes);
// Course certificates follow final reports (issued on publish) — read-only here, same roles.
app.use("/api/certificates", protect, attachOwnRecords, certificateRoutes);
// Learner access is scoped to assessment-submission file uploads (documentUpload/imageUpload/
// videoUpload/audioUpload/codeUpload items and project deliverables) — see AssessmentTaker.jsx.
// teacher/school need this too, for their own profile-photo uploads (teacher-portal/
// school-portal profile pages, and the admin-side Teacher/LearningHub forms). A supervisor may
// only upload an image — their own profile photo (supervisor-portal My Profile).
const supervisorPhotoOnly = (req, res, next) => (
  req.user.role !== "supervisor" || (req.method === "POST" && req.path === "/image")
    ? next()
    : res.status(403).json({ success: false, message: "You do not have permission to perform this action" })
);
app.use("/api/uploads", protect, authorize("admin", "teacher", "school", "learner", "supervisor"), supervisorPhotoOnly, uploadRoutes);
// Competitions — an independent module (a sibling of curriculum), admin-only. A competition can
// optionally link to a curriculum via curriculumId.
app.use("/api/competitions", protect, attachOwnRecords, authorize("admin"), competitionRoutes);
// Bootcamps — an independent module (a sibling of curriculum/competitions), admin-only. A
// bootcamp can optionally link to a curriculum via curriculumId.
app.use("/api/bootcamps", protect, attachOwnRecords, authorize("admin"), bootcampRoutes);
// Scoped entirely by req.user.id (see notification.routes.js) — every role shares this one
// router, no attachOwnRecords/authorize needed.
app.use("/api/notifications", protect, notificationRoutes);
// Which emails the whole workspace sends (Settings → Emails). Owner-only, same guards as
// /api/access: what a workspace emails its parents and educators is not a staff decision.
app.use("/api/email-settings", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, emailSettingsRoutes);
// Who signs the workspace's certificates (Settings → Certificates) — owner only, like the above.
app.use("/api/certificate-settings", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, certificateSettingsRoutes);
// The workspace's own M-Pesa Paybill (Settings → Payments) — owner only, like the above: where a
// workspace's money goes is not a staff decision.
// How families can pay (Paybill, Send Money, bank, cheque, cash) — the website's Payment step.
app.use("/api/payment-settings/options", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, paymentNoticeRoutes.optionsRouter);
app.use("/api/payment-settings", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, paymentSettingsRoutes);
// M-Pesa: whether it's on, a prompt's progress, and Billing → M-Pesa (payments to match).
// Mounted before billing's "/:id" routes so "mpesa" is never read as an invoice id.
app.use("/api/billing/mpesa", protect, attachOwnRecords, mpesaRoutes);
// Billing → To confirm: families' "I've paid" notices. Before "/:id" for the same reason.
app.use("/api/billing/payment-notices", protect, attachOwnRecords, paymentNoticeRoutes.staffRouter);
// Billing → Orders: website Store and Project orders. Before "/:id" for the same reason.
app.use("/api/billing/orders", protect, attachOwnRecords, orderRoutes.staffRouter);
app.use("/api/billing", protect, attachOwnRecords, billingRoutes);
// Hub Visits — a non-school hub logging learner space-usage visits and turning them into
// hub_usage invoices through the Billing module above (see hub-visit.service.js's header
// comment). Admin/school only, same posture as billing — a learner's own charges surface
// exclusively through /api/billing, never this route.
app.use("/api/hub-visits", protect, attachOwnRecords, hubVisitRoutes);
// Enquiries page — the staff-facing read/triage side of the public leads above.
app.use("/api/leads", protect, authorize("admin"), leadRoutes);
// One-time operational tool: move a hub/curriculum/course/assessment the calling admin owns to
// a different admin, by email. See reassign-owner.service.js's header comment for why this
// exists — the 2026-09-07 tenant-isolation backfill had no per-row creator to recover ownership
// from, so pre-existing Live data landed on one admin and needs manual redistribution.
//
// blockIfCollaboratorRestricted is mounted here specifically (rather than tenant-wide) because
// this is the one place authorize("admin") alone isn't enough: attachOwnRecords aliases a
// collaborator's role to "admin" for non-DELETE requests (see its own comment), which would
// otherwise let a collaborator reach reassign-owner and, worse, invite/revoke OTHER
// collaborators on their inviting admin's behalf — both are real-admin-only tenant management,
// not "content creation".
app.use("/api/admin-tools", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, reassignOwnerRoutes, collaboratorRoutes);
// Staff roles & permissions (Settings → Roles & access) — owner-only, same guards as admin-tools:
// a staff account is never role-aliased here (see access.registry.js's OWNER_ONLY_PREFIXES), so
// authorize("admin") refuses it, and blockIfCollaboratorRestricted backs that up.
app.use("/api/access", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, accessRoutes);
// Sharing between admins (Settings → Sharing): connecting with another admin, browsing their
// content and copying it into this workspace. Owner-only, same guards as the two above — what a
// workspace shares, and with whom, is never a staff decision.
app.use("/api/sharing", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, sharingRoutes);
// The Activity page — reading the activity log. The workspace owner, and staff whose role grants
// Activity log → View (a staff request is only treated as admin here when it does).
app.use("/api/audit", protect, attachOwnRecords, authorize("admin"), auditRoutes);
// Educator claims — an educator requesting payment for a course they teach, reviewed by a
// supervisor and then the admin. Educators and the workspace's reviewers share this router; its
// own routes file says who reaches what (see claim.routes.js).
app.use("/api/claims", protect, attachOwnRecords, claimRoutes);
// Hub check-ins — Account Managers and Training Leads checking in with each hub on a schedule,
// reporting, and following up; the workspace owner and check-in managers oversee them. See
// modules/checkins/ (checkin.access.js for who sees which hubs).
app.use("/api/checkins", protect, attachOwnRecords, checkinRoutes);
// Training of trainers — educators learning on a curriculum made for them, marked by their
// supervisor. See modules/tot/.
app.use("/api/tot", protect, attachOwnRecords, totRoutes);
// Quality assurance — supervisors (and admins) visiting educators, announced or by surprise, and
// reviewing them against a template; the educator reads and replies, the hub sees a summary. See
// modules/qa/ (qa.access.js for who sees what).
app.use("/api/qa", protect, attachOwnRecords, qaRoutes);
// Parent–mentor check-ins — a class's educators meeting each family, one at a time, about their
// child; set up by an admin, times drawn at random, the parent confirms or picks another time and
// approves the report. See modules/mentor-checkins/ (mentor-checkin.access.js for who sees what).
app.use("/api/mentor-checkins", protect, attachOwnRecords, mentorCheckinRoutes);
// Mentor standards — the bar every mentor is measured against (Settings → Mentor standards); each
// mentor's standing comes with their profile and Reports → Educators. See modules/mentor-standards/.
app.use("/api/mentor-standards", protect, attachOwnRecords, mentorStandardRoutes);
// Parent feedback on mentors — parents (and TOT learners) review the educators teaching them; admins,
// supervisors, the educator (anonymously) and the hub (averages) read it. See modules/mentor-reviews/.
app.use("/api/mentor-reviews", protect, attachOwnRecords, mentorReviewRoutes);
// The educator performance profile — internal views, the educator's own, publishing, Find a mentor
// (parents) and mentor requests. See modules/educator-profiles/.
app.use("/api/educator-profiles", protect, attachOwnRecords, educatorProfileRoutes);
// Affiliate marketing — admins manage affiliates, commissions and payouts; parents and educators
// see their own "Refer & earn" (/me). See modules/affiliates/.
app.use("/api/affiliates", protect, attachOwnRecords, affiliateRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
