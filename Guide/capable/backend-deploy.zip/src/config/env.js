const env = {
  PORT: process.env.PORT || 5000,
  NODE_ENV: process.env.NODE_ENV || "development",
  JWT_SECRET: process.env.JWT_SECRET,
  // Hard cap on one sign-in, however active the user is. The idle limit below is what normally
  // ends a session; this is the backstop.
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || "12h",
  // Minutes without user activity (clicks, typing, scrolling — reported by the client via
  // POST /api/auth/activity; background polling doesn't count) before a session is ended.
  SESSION_IDLE_MINUTES: Number(process.env.SESSION_IDLE_MINUTES) > 0 ? Number(process.env.SESSION_IDLE_MINUTES) : 30,
  COOKIE_NAME: "token",
  // Mirrors client/src/config/authConfig.js — flip both back to false together to
  // bypass login enforcement for local work. While false, `protect` lets every request through.
  AUTH_ENABLED: true,
  CLIENT_URL: process.env.CLIENT_URL,
  // The public digifunzi-landing site — cookie-less origin(s) that only ever call the
  // /api/public/* routes. Optional: those routes work fine with this unset (no browser CORS
  // check applies to a same-origin curl/server-to-server call), it only matters once the
  // landing site is actually deployed and calling this API from a browser.
  // Comma-separated to allow several origins at once, e.g.
  //   PUBLIC_SITE_URL=https://africa.digifunzi.com,http://localhost:5175,http://localhost:4199
  // (deployed site + Vite dev server + the build-time prerender's origin).
  PUBLIC_SITE_URL: process.env.PUBLIC_SITE_URL,
  // This API's own externally-visible base URL, e.g. https://nodeapp.digifunzi.com — used to
  // turn stored relative "/uploads/..." media paths into absolute URLs in the /api/public/*
  // responses, since the landing site consumes them cross-origin (an <img src="/uploads/x">
  // there would resolve against the landing site's own origin, not this API). Optional: if
  // unset, public responses fall back to returning the raw stored value.
  API_PUBLIC_URL: process.env.API_PUBLIC_URL,
  // Which admin's tenant (hubs/curricula/pathways) the public digifunzi-landing site's diagnostic
  // feature reads from — see public-diagnostic.service.js. Each admin is its own isolated tenant
  // now (no shared data by default), so the public site needs to be told explicitly whose
  // content to show rather than guessing "the first admin" or merging everyone's. Optional: the
  // public diagnostic endpoints return a clean 503 if unset, same posture as the other optional
  // public-site vars above — nothing else in the app depends on this.
  PUBLIC_CONTENT_ADMIN_ID: process.env.PUBLIC_CONTENT_ADMIN_ID,
  // Outbound email — all optional. Unset means mailer.js silently no-ops (logs, doesn't throw),
  // so auto-ack/reply/digest emails degrade to a no-op instead of blocking the request that
  // triggered them. Works against any standard SMTP account (Google Workspace, a transactional
  // provider's SMTP endpoint, etc) — no vendor-specific SDK.
  SMTP_HOST: process.env.SMTP_HOST,
  SMTP_PORT: Number(process.env.SMTP_PORT) || 587,
  SMTP_USER: process.env.SMTP_USER,
  SMTP_PASS: process.env.SMTP_PASS,
  // Brevo API key (starts "xkeysib-"). When set, email goes through Brevo's HTTP API instead of
  // SMTP — for hosts that block or redirect outbound SMTP ports. MAIL_FROM is still required.
  BREVO_API_KEY: process.env.BREVO_API_KEY,
  MAIL_FROM: process.env.MAIL_FROM,
  MAIL_REPLY_TO: process.env.MAIL_REPLY_TO,
  // The product name account emails are signed with (password resets, invoices, notifications).
  MAIL_BRAND_NAME: process.env.MAIL_BRAND_NAME || "Digifunzi",
  // How emails look — all optional (see shared/mail/mail.layout.js). The header logo is served by
  // this API, so it shows once API_PUBLIC_URL is set; MAIL_LOGO_URL points at a different image.
  // The footer links to MAIL_WEBSITE_URL (default: the first https PUBLIC_SITE_URL) and to
  // MAIL_SOCIAL_LINKS, e.g. "Facebook=https://facebook.com/…,Instagram=https://instagram.com/…".
  MAIL_LOGO_URL: process.env.MAIL_LOGO_URL,
  MAIL_WEBSITE_URL: process.env.MAIL_WEBSITE_URL,
  MAIL_SOCIAL_LINKS: process.env.MAIL_SOCIAL_LINKS,
  // How long an emailed password-reset link stays valid.
  PASSWORD_RESET_MINUTES: Number(process.env.PASSWORD_RESET_MINUTES) > 0 ? Number(process.env.PASSWORD_RESET_MINUTES) : 60,
  DB_HOST: process.env.DB_HOST || "127.0.0.1",
  DB_PORT: Number(process.env.DB_PORT) || 3306,
  DB_USER: process.env.DB_USER,
  DB_PASSWORD: process.env.DB_PASSWORD,
  DB_NAME: process.env.DB_NAME,
};

// Fail fast at boot with a clear message instead of starting successfully and failing later
// with an opaque Knex connection error or a JWT-signing crash on the first real request — every
// one of these is required for the app to do anything, so there's no valid state where starting
// without them is better than refusing to start.
const REQUIRED_KEYS = ["JWT_SECRET", "CLIENT_URL", "DB_USER", "DB_PASSWORD", "DB_NAME"];
const missing = REQUIRED_KEYS.filter((key) => !env[key]);
if (missing.length) {
  throw new Error(
    `Missing required environment variable(s): ${missing.join(", ")}. Check your .env file.`
  );
}

module.exports = env;
