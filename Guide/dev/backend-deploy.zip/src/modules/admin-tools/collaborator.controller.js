const asyncHandler = require("express-async-handler");
const { z } = require("zod");
const CollaboratorService = require("./collaborator.service");
const { MODULE_KEYS } = require("./module-registry");

// See module-registry.js for what each key gates and scope.middleware.js's attachOwnRecords for
// enforcement. Omitted entirely on invite (allowedModules left undefined) means "every module" —
// see collaborator.service.js's invite() — but once set, editing always sends an explicit list.
const moduleListSchema = z.array(z.enum(MODULE_KEYS)).max(MODULE_KEYS.length);

// A staff member's access comes from their role (roleId — see modules/access/). allowedModules is
// the pre-roles way and is still accepted for direct API callers.
const inviteSchema = z.object({
  name: z.string().min(1, "Name is required").max(150),
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  roleId: z.string().min(1).optional(),
  allowedModules: moduleListSchema.optional(),
});

const updateSchema = z.object({
  roleId: z.string().min(1).optional(),
  allowedModules: moduleListSchema.optional(),
}).refine((data) => data.roleId !== undefined || data.allowedModules !== undefined, { message: "Choose a role" });

// This whole route is mounted under admin-tools (authorize("admin") + attachOwnRecords at the
// app.js level) and additionally refused outright for role "collaborator" by
// blockIfCollaboratorRestricted — a collaborator can edit the tenant's content but can never
// invite or remove another collaborator, so only the tenant's own admin ever reaches these.
const inviteCollaborator = asyncHandler(async (req, res) => {
  const data = inviteSchema.parse(req.body);
  const collaborator = await CollaboratorService.invite({ ...data, invitedByAdminId: req.ownerAdminId });
  res.status(201).json({ success: true, data: collaborator });
});

const listCollaborators = asyncHandler(async (req, res) => {
  const collaborators = await CollaboratorService.listForAdmin(req.ownerAdminId);
  res.json({ success: true, data: collaborators, count: collaborators.length });
});

const updateCollaborator = asyncHandler(async (req, res) => {
  const data = updateSchema.parse(req.body);
  const collaborator = data.roleId !== undefined
    ? await CollaboratorService.updateRole(req.params.id, req.ownerAdminId, data.roleId)
    : await CollaboratorService.updateModules(req.params.id, req.ownerAdminId, data.allowedModules);
  res.json({ success: true, data: collaborator });
});

const revokeCollaborator = asyncHandler(async (req, res) => {
  const result = await CollaboratorService.revoke(req.params.id, req.ownerAdminId);
  res.json({ success: true, ...result });
});

module.exports = { inviteCollaborator, listCollaborators, updateCollaborator, revokeCollaborator };
