const asyncHandler = require("express-async-handler");
const CompetitionService = require("./competition.service");
const CompetitionHubService = require("./competition-hub.service");
const LearningHubModel = require("../learning-hubs/learning-hub.model");
const { assertOwn } = require("../../shared/middleware/scope.middleware");
const { createCompetitionSchema, updateCompetitionSchema, cancelRegistrationSchema } = require("./competition.validation");
const CompetitionRegistrationService = require("./competition-registration.service");
const UsageService = require("../usage/usage.service");
const { createOfferingSchema } = require("./competition-hub.validation");
const { parsePatch } = require("../../shared/validators/common.validator");

// This whole module is authorize("admin")-only (see app.js/competition.routes.js). A competition
// carries its own ownerAdminId, so ownership is a direct match, same shape as bootcamps.
function isOwn(req, competition) {
  return competition && competition.ownerAdminId === req.ownerAdminId;
}

// A hub-offering's target hub must belong to the same admin.
async function assertOwnHub(req, hubId) {
  const hubs = await LearningHubModel.findAll({ ownerAdminId: req.ownerAdminId, includeDrafts: true });
  assertOwn(hubs.some((h) => h.id === hubId));
}

const createCompetition = asyncHandler(async (req, res) => {
  const data = createCompetitionSchema.parse(req.body);
  // ownerAdminId is never client-supplied — always the creating admin's own tenant id.
  const record = await CompetitionService.createCompetition({ ...data, ownerAdminId: req.ownerAdminId });
  res.status(201).json({ success: true, data: record });
});

const getAllCompetitions = asyncHandler(async (req, res) => {
  const { curriculumId, status } = req.query;
  const records = await CompetitionService.getAllCompetitions({ ownerAdminId: req.ownerAdminId, curriculumId, status });
  res.json({ success: true, data: records, count: records.length });
});

const getCompetitionById = asyncHandler(async (req, res) => {
  const record = await CompetitionService.getCompetitionById(req.params.id);
  assertOwn(isOwn(req, record));
  res.json({ success: true, data: record });
});

const updateCompetition = asyncHandler(async (req, res) => {
  // Only the fields that were sent — a partial update must not reset the others to their
  // defaults (see parsePatch).
  const data = parsePatch(updateCompetitionSchema, req.body);
  assertOwn(isOwn(req, await CompetitionService.getCompetitionById(req.params.id)));
  const record = await CompetitionService.updateCompetition(req.params.id, data, req.ownerAdminId);
  res.json({ success: true, data: record });
});

const deleteCompetition = asyncHandler(async (req, res) => {
  assertOwn(isOwn(req, await CompetitionService.getCompetitionById(req.params.id)));
  // People registered for it → refused (close it instead); ?check=1 only asks.
  if (await UsageService.guardDelete(req, res, "competition", req.params.id, "This competition")) return;
  const result = await CompetitionService.deleteCompetition(req.params.id);
  res.json({ success: true, ...result });
});

const listOfferings = asyncHandler(async (req, res) => {
  assertOwn(isOwn(req, await CompetitionService.getCompetitionById(req.params.id)));
  const records = await CompetitionHubService.getOfferingsForCompetition(req.params.id);
  res.json({ success: true, data: records, count: records.length });
});

const createOffering = asyncHandler(async (req, res) => {
  assertOwn(isOwn(req, await CompetitionService.getCompetitionById(req.params.id)));
  const { hubId } = createOfferingSchema.parse(req.body);
  await assertOwnHub(req, hubId);
  const record = await CompetitionHubService.createOffering({ competitionId: req.params.id, hubId, ownerAdminId: req.ownerAdminId });
  res.status(201).json({ success: true, data: record });
});

const deleteOffering = asyncHandler(async (req, res) => {
  assertOwn(isOwn(req, await CompetitionService.getCompetitionById(req.params.id)));
  const result = await CompetitionHubService.deleteOffering(req.params.offeringId);
  res.json({ success: true, ...result });
});

// Registrations (20 Nov 2026) — the competition page's Registrations tab.
const listRegistrations = asyncHandler(async (req, res) => {
  assertOwn(isOwn(req, await CompetitionService.getCompetitionById(req.params.id)));
  const records = await CompetitionRegistrationService.listForCompetition(req.params.id);
  res.json({ success: true, data: records, count: records.length });
});

const cancelRegistration = asyncHandler(async (req, res) => {
  assertOwn(isOwn(req, await CompetitionService.getCompetitionById(req.params.id)));
  const { reason } = cancelRegistrationSchema.parse(req.body);
  const record = await CompetitionRegistrationService.cancel(req.params.id, req.params.registrationId, { reason, actorUserId: req.user.id });
  res.json({ success: true, data: record });
});

module.exports = {
  listRegistrations,
  cancelRegistration,
  createCompetition,
  getAllCompetitions,
  getCompetitionById,
  updateCompetition,
  deleteCompetition,
  listOfferings,
  createOffering,
  deleteOffering,
};
