const logger = require("../utils/logger");
const { NODE_ENV } = require("../../config/env");
const { IMAGE_MAX_BYTES, DOCUMENT_MAX_BYTES } = require("../../modules/uploads/upload.middleware");

const errorHandler = (err, req, res, next) => {
  logger.error(err.message, err.stack);
  // Why it failed, for the activity log (audit.middleware.js) — the real message, even where the
  // response below hides it.
  res.locals.auditReason = err.message;

  if (err.name === "ZodError") {
    return res.status(400).json({
      success: false,
      message: "Validation failed",
      errors: err.issues || err.errors,
    });
  }

  if (err.name === "MulterError" && err.code === "LIMIT_FILE_SIZE") {
    // Images and other files have different limits (upload.middleware.js) — name the right one.
    const isImage = req.originalUrl.split("?")[0].replace(/\/+$/, "").endsWith("/uploads/image");
    const maxMb = Math.round((isImage ? IMAGE_MAX_BYTES : DOCUMENT_MAX_BYTES) / (1024 * 1024));
    return res.status(413).json({
      success: false,
      message: isImage ? `This image is too large. Images can be up to ${maxMb} MB.` : `This file is too large. Files can be up to ${maxMb} MB.`,
    });
  }

  const statusCode = err.statusCode || err.status || 500;
  // Below 500 the message is a deliberate app-thrown one (validation, 401/403/404, etc.) and
  // safe to show as-is. 500s are unexpected — in production, surface a generic message instead
  // of leaking internals (raw DB errors, stack-revealing text); the real message is still logged
  // above.
  const message =
    statusCode >= 500 && NODE_ENV === "production"
      ? "Internal server error"
      : err.message || "Internal server error";
  res.status(statusCode).json({
    success: false,
    message,
    // Machine-readable discriminators for the client — only present when an app-thrown error
    // set them (e.g. ACCOUNT_SUSPENDED from auth.service.js / scope.middleware.js). Absent for
    // every other error, so nothing existing changes shape.
    ...(err.code ? { code: err.code } : {}),
    ...(err.reason ? { reason: err.reason } : {}),
    // Every problem at once, when an app-thrown 4xx lists them (e.g. what a check-in report
    // still needs before it can be submitted).
    ...(statusCode < 500 && Array.isArray(err.errors) ? { errors: err.errors } : {}),
    // What a refused delete is still used by (code IN_USE — modules/usage/usage.service.js).
    ...(err.code === "IN_USE" && err.usage ? { usage: err.usage } : {}),
    // An M-Pesa prompt already waiting for this invoice — the client follows it instead.
    ...(err.requestId ? { requestId: err.requestId } : {}),
  });
};

const notFound = (req, res, next) => {
  const err = new Error(`Route not found: ${req.originalUrl}`);
  err.statusCode = 404;
  next(err);
};

module.exports = { errorHandler, notFound };
