// One-off operational script: creates a sample curriculum owned by PUBLIC_CONTENT_ADMIN_ID plus
// a Bootcamp linked to it, flipped `saleStatus: "for_sale"`, so it appears immediately on the
// public marketing site's Bootcamps section (africa.digifunzi.com/bootcamps) with a price and an
// "Enquire to book" button. See Guide/BOOTCAMP_SALE_SETUP.md and
// Guide/WEBSITE_INTEGRATION_CONTRACT.md §3.1/§3.2.
//
// Safe to re-run — it skips creation if a curriculum with the same name already exists.
//
// Usage (from server/):
//   node src/scripts/seedSampleForSaleBootcamp.js

require("dotenv").config();

const env = require("../config/env");
const db = require("../config/db");
const CurriculumModel = require("../modules/curriculum/curriculum.model");
const BootcampModel = require("../modules/bootcamps/bootcamp.model");

const BOOTCAMP_NAME = "Robot Builders Holiday Bootcamp";

async function run() {
  if (!env.PUBLIC_CONTENT_ADMIN_ID) {
    console.error("PUBLIC_CONTENT_ADMIN_ID is not set in server/.env — cannot seed.");
    process.exitCode = 1;
    return;
  }

  const owner = await db("users")
    .where({ id: env.PUBLIC_CONTENT_ADMIN_ID, role: "admin" })
    .first();
  if (!owner) {
    console.error(
      `PUBLIC_CONTENT_ADMIN_ID (${env.PUBLIC_CONTENT_ADMIN_ID}) does not match any admin user — cannot seed.`,
    );
    process.exitCode = 1;
    return;
  }

  const existingCurriculum = await db("curricula")
    .where({ ownerAdminId: env.PUBLIC_CONTENT_ADMIN_ID, name: BOOTCAMP_NAME })
    .first();
  const existingBootcamp = await db("bootcamps")
    .where({ ownerAdminId: env.PUBLIC_CONTENT_ADMIN_ID, name: BOOTCAMP_NAME })
    .first();
  if (existingCurriculum || existingBootcamp) {
    console.log(`"${BOOTCAMP_NAME}" already exists — nothing to do.`);
    if (existingCurriculum) console.log(`curriculum: ${existingCurriculum.id}`);
    if (existingBootcamp) console.log(`bootcamp: ${existingBootcamp.id} (saleStatus: ${existingBootcamp.saleStatus})`);
    process.exit(0);
  }

  const curriculum = await CurriculumModel.create({
    ownerAdminId: env.PUBLIC_CONTENT_ADMIN_ID,
    name: BOOTCAMP_NAME,
    code: "RB-HOLIDAY",
    description:
      "One intensive week of hands-on robotics. Learners start with a bare Quarky board and " +
      "finish with a robot they built, coded and can drive around an obstacle course — with a " +
      "showcase for families on the last afternoon. No prior coding needed.",
    status: "active",
    academicCycleModel: "terms",
  });

  const bootcamp = await BootcampModel.create({
    ownerAdminId: env.PUBLIC_CONTENT_ADMIN_ID,
    curriculumId: curriculum.id,
    name: BOOTCAMP_NAME,
    description: curriculum.description,
    tagline: "A full robot build, coded and driven, in one week",
    coverImage: null, // no image → the card shows a brand-blue band with the name
    format: "holiday",
    durationLabel: "1 week",
    priceAmount: 12000,
    priceCurrency: "KES",
    priceNote: "Includes all materials and the end-of-week showcase. Sibling discount available.",
    ageMin: 9,
    ageMax: 14,
    highlights: [
      "Build a working robot from a bare board",
      "Write real code to make it move, sense and react",
      "Drive it through an obstacle course you design",
      "Showcase for families on the final afternoon",
    ],
    saleStatus: "for_sale",
  });

  console.log("Created curriculum:", { id: curriculum.id, name: curriculum.name });
  console.log("Created for-sale bootcamp:", {
    id: bootcamp.id,
    name: bootcamp.name,
    curriculumId: bootcamp.curriculumId,
    saleStatus: bootcamp.saleStatus,
    price: `${bootcamp.priceCurrency} ${bootcamp.priceAmount}`,
  });

  console.log(
    "\nIt's live now. Check GET /api/public/bootcamps, or open /bootcamps on the landing site.\n" +
      "To edit it: Programs > Bootcamps > \"" +
      BOOTCAMP_NAME +
      "\". Set its dates and run it at a hub to give it real run dates.",
  );
  process.exit(0);
}

run().catch((err) => {
  console.error("Seed failed:", err);
  process.exitCode = 1;
});
