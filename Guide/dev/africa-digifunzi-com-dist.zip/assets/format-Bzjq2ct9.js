const K=(t,o="KES")=>`${o==="KES"?"KSh":o} ${Number(t||0).toLocaleString("en-KE")}`;export{K as f};
