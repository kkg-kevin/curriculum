import{j as r}from"./query-DE-srvWZ.js";import{g as o}from"./index-DwgB0Mg3.js";const s=o(r.jsx("path",{d:"m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"}),"ArrowForward");export{s as A};
