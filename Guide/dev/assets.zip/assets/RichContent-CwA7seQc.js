import{n as e}from"./chunk-CacB07dV.js";import{b as t}from"./api-DVCOLfX-.js";import{n,t as r}from"./sanitizeHtml-D_uEd0z_.js";function i(e){return e?/<(img|video)[\s>]/i.test(e)?!1:e.replace(/<[^>]*>/g,``).trim().length===0:!0}function a(e){return e?e.replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``}function o({html:e,emptyText:t}){return i(e)?(0,s.jsx)(`p`,{style:{margin:0,fontSize:`13px`,color:`#9CA3AF`,fontStyle:`italic`},children:t}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:`
        .asm-rich-content { font-size: 14px; color: #374151; line-height: 1.65; }
        .asm-rich-content p { margin: 0 0 10px; }
        .asm-rich-content p:last-child { margin-bottom: 0; }
        .asm-rich-content ul, .asm-rich-content ol { margin: 0 0 10px; padding-left: 22px; }
        .asm-rich-content img { max-width: 100%; border-radius: 8px; margin: 8px 0; display: block; }
        .asm-rich-content video { max-width: 100%; border-radius: 8px; margin: 8px 0; display: block; background: #000; }
        .asm-rich-content strong { font-weight: 700; }
        .asm-rich-content h2 { font-size: 1.25em; font-weight: 800; margin: 0 0 10px; color: #111827; }
        .asm-rich-content h3 { font-size: 1.1em; font-weight: 700; margin: 0 0 8px; color: #111827; }
        .asm-rich-content blockquote { margin: 0 0 10px; padding-left: 12px; border-left: 3px solid #a8d5ee; color: #6B7280; font-style: italic; }
        .asm-rich-content code { background: #F3F4F6; padding: 1px 5px; border-radius: 4px; font-size: 0.9em; }
        .asm-rich-content pre { background: #111827; color: #F9FAFB; padding: 10px 12px; border-radius: 8px; overflow-x: auto; margin: 0 0 10px; }
        .asm-rich-content pre code { background: none; padding: 0; color: inherit; }
        .asm-rich-content a { color: #25476a; text-decoration: underline; }
        .asm-rich-content hr { border: none; border-top: 1.5px solid #E5E7EB; margin: 14px 0; }
        .asm-rich-content table { border-collapse: collapse; width: 100%; margin: 0 0 10px; table-layout: fixed; }
        .asm-rich-content th, .asm-rich-content td { border: 1.5px solid #E5E7EB; padding: 6px 9px; text-align: left; vertical-align: top; }
        .asm-rich-content th { background: #F9FAFB; font-weight: 700; }
      `}),(0,s.jsx)(`div`,{className:`asm-rich-content`,dangerouslySetInnerHTML:{__html:n(e)}})]})}var s,c=e((()=>{r(),s=t()}));export{a as i,c as n,i as r,o as t};