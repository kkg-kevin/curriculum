import{j as o}from"./query-DE-srvWZ.js";import{g as r}from"./index-i_yqXf0s.js";const s=r(o.jsx("path",{d:"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z"}),"ArrowBack");export{s as A};
