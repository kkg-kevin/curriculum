const path = require("path");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const env = require("./config/env");
const authRoutes = require("./modules/auth/auth.routes");
const curriculumRoutes = require("./modules/curriculum/curriculum.routes");
const competencyRoutes = require("./modules/settings/competencies/competency.routes");
const pathwayTemplateRoutes = require("./modules/settings/pathways/pathway-template.routes");
const systemLevelRoutes = require("./modules/settings/system-levels/system-level.routes");
const inventoryRoutes = require("./modules/settings/inventory/inventory.routes");
const itemsRoutes = require("./modules/settings/items/items.routes");
const learningHubRoutes = require("./modules/learning-hubs/learning-hub.routes");
const teacherRoutes = require("./modules/teachers/teacher.routes");
const classRoutes = require("./modules/classes/class.routes");
const classGroupRoutes = require("./modules/classes/groups/class-group.routes");
const roomRoutes = require("./modules/rooms/room.routes");
const learnerRoutes = require("./modules/learners/learner.routes");
const publicLearnerProfileRoutes = require("./modules/learners/public-profile.routes");
const courseRoutes = require("./modules/courses/course.routes");
const attendanceRoutes = require("./modules/attendance/attendance.routes");
const timetableRoutes = require("./modules/timetable/timetable.routes");
const assessmentRoutes = require("./modules/assessments/assessment.routes");
const assessmentSubmissionRoutes = require("./modules/assessments/submissions/assessment-submission.routes");
const reportRoutes = require("./modules/reports/report.routes");
const uploadRoutes = require("./modules/uploads/upload.routes");
const competitionRoutes = require("./modules/competitions/competition.routes");
const bootcampRoutes = require("./modules/bootcamps/bootcamp.routes");
const notificationRoutes = require("./modules/notifications/notification.routes");
const billingRoutes = require("./modules/billing/billing.routes");
const hubVisitRoutes = require("./modules/hub-visits/hub-visit.routes");
const publicLeadRoutes = require("./modules/leads/public-lead.routes");
const publicBootcampEnrollmentRoutes = require("./modules/bootcamp-enrollment/bootcamp-enrollment.routes");
const leadRoutes = require("./modules/leads/lead.routes");
const publicSiteRoutes = require("./modules/public-site/public-site.routes");
const publicDiagnosticRoutes = require("./modules/public-site/public-diagnostic.routes");
const reassignOwnerRoutes = require("./modules/admin-tools/reassign-owner.routes");
const collaboratorRoutes = require("./modules/admin-tools/collaborator.routes");
const { errorHandler, notFound } = require("./shared/middleware/error.middleware");
const { protect: protectBase, authorize, blockIfSuspended, blockIfCollaboratorRestricted } = require("./shared/middleware/auth.middleware");
const { attachOwnRecords } = require("./shared/middleware/scope.middleware");

// Every authenticated route already mounts `protect`; pairing it here with `blockIfSuspended`
// means a suspended account keeps a read-only session everywhere but is refused every write in
// one place, without touching each route file. `protect` is exported as `protectBase` and
// re-exposed as this array so the existing `protect, ...` mount calls below need no change.
const protect = [protectBase, blockIfSuspended];

const app = express();

app.use(
  helmet({
    // This is a JSON API — the only HTML-adjacent response is the "/" health check, which
    // returns JSON too, so there's no page for a CSP to protect and the default policy only
    // risks conflicting with the client's own. Static /uploads files (photos, assessment
    // media) are fetched cross-origin by the client's <img>/<video> tags, so the default
    // same-origin resource policy would silently block them from loading.
    contentSecurityPolicy: false,
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);
// The admin client (CLIENT_URL) sends cookies and needs credentials: true. The public
// digifunzi-landing site (PUBLIC_SITE_URL) never sends a JWT/cookie (see its src/services/api.js)
// and only ever reaches the /api/public/* routes below, but still needs its origin allowed or the
// browser blocks the request before it reaches Express at all.
//
// PUBLIC_SITE_URL is comma-separated: the landing site is served from more than one origin
// (apex + www + staging) and its build-time prerender step runs from yet another origin
// (http://localhost:4199) — see Guide/WEBSITE_INTEGRATION_CONTRACT.md §5. A request with no
// Origin header at all (server-to-server curl, same-origin) is always allowed.
const allowedOrigins = [
  env.CLIENT_URL,
  ...String(env.PUBLIC_SITE_URL || "")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean),
].filter(Boolean);
app.use(cors({
  // A disallowed origin gets `false` (no CORS headers set → the browser blocks it), not a
  // thrown Error — throwing would surface as a confusing 500 in our logs for what is really
  // just an un-whitelisted caller. A request with no Origin header (server-to-server curl,
  // the prerender step in some modes) is always allowed.
  origin(origin, cb) {
    cb(null, !origin || allowedOrigins.includes(origin));
  },
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  credentials: true,
}));
app.use(express.json());
app.use(cookieParser());
app.use(morgan("dev"));
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

app.get("/", (req, res) => {
  res.json({ message: "API is running" });
});

// General abuse/runaway-loop backstop for everything under /api — login already has its own
// stricter limiter layered on top of this one. Deliberately generous (same reasoning as
// loginLimiter in auth.routes.js: a school/office network puts many real concurrent users
// behind one shared IP, and this app's own polling — notifications every 60s, a teacher's
// per-class dashboard queries — can legitimately add up to a lot of requests from one IP over
// 15 minutes). This isn't meant to shape normal traffic, just cap the pathological case (a
// broken client retry loop, a scraper) before it can degrade the shared connection pool for
// everyone else.
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 3000,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests. Please try again later." },
});
app.use("/api", apiLimiter);

app.use("/api/auth", authRoutes);
// Unauthenticated by design — the "share via QR" destination for a learner's public profile
// link. Deliberately its own router (not a route inside learnerRoutes) so it can never end up
// behind the `protect` chain every other /api/learners route is mounted with below. Read-only,
// and scoped by learner.service.js's getPublicProfile to a hand-picked, deliberately narrow
// field set — see that function's comment for exactly what it excludes.
app.use("/api/public/learners", publicLearnerProfileRoutes);
// Unauthenticated by design — the digifunzi-landing site's Enroll/Contact forms (see
// public-lead.routes.js). Mounted at /api/public rather than /api/public/leads since it
// serves both /api/public/leads and /api/public/contact.
app.use("/api/public", publicLeadRoutes);
// Unauthenticated by design — the digifunzi-landing site's Pathways listing and detail pages
// (see public-site.routes.js).
app.use("/api/public", publicSiteRoutes);
// Unauthenticated by design — the anonymous public diagnostic feature (pick a pathway, take a
// diagnostic, see a graded report on the spot). Reads/grades against the ONE admin tenant
// PUBLIC_CONTENT_ADMIN_ID designates (see env.js) — never the caller's own tenant, since there
// is no caller identity here at all. Own rate limiters, see public-diagnostic.routes.js.
app.use("/api/public", publicDiagnosticRoutes);
// Unauthenticated by design — a bootcamp's public enrollment flow. Auto-provisions a real learner
// account (see bootcamp-enrollment.service.js) instead of just sending a lead for a human to
// follow up on. The admin-only "mark paid" counterpart lives on the existing protected
// /api/leads router instead (see lead.routes.js).
app.use("/api/public", publicBootcampEnrollmentRoutes);

// Everything below requires a logged-in session. Curriculum authoring, settings, assessments
// (builder) and uploads are admin-only in full; curriculum.routes.js carves out the two
// non-admin reads a school inherits (its curriculum, and that curriculum's current courses)
// before the router-wide admin gate — attachOwnRecords is mounted here too so those routes can
// verify the requested curriculum is actually the caller's own. Learning hubs/teachers/classes/
// learners are read (and, for "school"-type hubs, written) by more than one role, so their
// own routes files apply per-method role checks plus attachOwnRecords-based ownership scoping —
// a school/teacher/learner account can only ever touch its own school's data, never another's.
app.use("/api/curricula", protect, attachOwnRecords, curriculumRoutes);
app.use("/api/competencies", protect, attachOwnRecords, authorize("admin"), competencyRoutes);
app.use("/api/pathway-templates", protect, attachOwnRecords, authorize("admin"), pathwayTemplateRoutes);
app.use("/api/system-levels", protect, attachOwnRecords, authorize("admin"), systemLevelRoutes);
app.use("/api/inventory", protect, attachOwnRecords, authorize("admin"), inventoryRoutes);
app.use("/api/items", protect, attachOwnRecords, authorize("admin"), itemsRoutes);
app.use("/api/learning-hubs", protect, attachOwnRecords, learningHubRoutes);
app.use("/api/teachers", protect, attachOwnRecords, teacherRoutes);
app.use("/api/classes", protect, attachOwnRecords, classRoutes);
// Reusable class-level learner groups, for group-based assessments — see class-group.routes.js.
app.use("/api/class-groups", protect, attachOwnRecords, classGroupRoutes);
app.use("/api/rooms", protect, attachOwnRecords, roomRoutes);
app.use("/api/learners", protect, attachOwnRecords, learnerRoutes);
app.use("/api/courses", protect, attachOwnRecords, courseRoutes);
app.use("/api/attendance", protect, attachOwnRecords, attendanceRoutes);
// Same shape as attendance — a timetable slot belongs to a Class, ownership resolved through it.
app.use("/api/timetable", protect, attachOwnRecords, timetableRoutes);
// Authoring stays admin-only, but one read (an assessment's linked competencies) is needed by
// teacher/school too, when grading — see assessment.routes.js for the per-route split.
app.use("/api/assessments", protect, attachOwnRecords, assessmentRoutes);
// Issuing/taking/grading is not authoring — teacher/school/learner reach it here, scoped by
// attachOwnRecords, while the assessment *builder* above stays admin-only.
app.use("/api/assessment-submissions", protect, attachOwnRecords, assessmentSubmissionRoutes);
// Course reports read off graded submissions above — same not-authoring, multi-role,
// attachOwnRecords-scoped shape.
app.use("/api/reports", protect, attachOwnRecords, reportRoutes);
// Learner access is scoped to assessment-submission file uploads (documentUpload/imageUpload/
// videoUpload/audioUpload/codeUpload items and project deliverables) — see AssessmentTaker.jsx.
// teacher/school need this too, for their own profile-photo uploads (teacher-portal/
// school-portal profile pages, and the admin-side Teacher/LearningHub forms).
app.use("/api/uploads", protect, authorize("admin", "teacher", "school", "learner"), uploadRoutes);
// Competitions — an independent module (a sibling of curriculum), admin-only. A competition can
// optionally link to a curriculum via curriculumId.
app.use("/api/competitions", protect, attachOwnRecords, authorize("admin"), competitionRoutes);
// Bootcamps — an independent module (a sibling of curriculum/competitions), admin-only. A
// bootcamp can optionally link to a curriculum via curriculumId.
app.use("/api/bootcamps", protect, attachOwnRecords, authorize("admin"), bootcampRoutes);
// Scoped entirely by req.user.id (see notification.routes.js) — every role shares this one
// router, no attachOwnRecords/authorize needed.
app.use("/api/notifications", protect, notificationRoutes);
app.use("/api/billing", protect, attachOwnRecords, billingRoutes);
// Hub Visits — a non-school hub logging learner space-usage visits and turning them into
// hub_usage invoices through the Billing module above (see hub-visit.service.js's header
// comment). Admin/school only, same posture as billing — a learner's own charges surface
// exclusively through /api/billing, never this route.
app.use("/api/hub-visits", protect, attachOwnRecords, hubVisitRoutes);
// Enquiries page — the staff-facing read/triage side of the public leads above.
app.use("/api/leads", protect, authorize("admin"), leadRoutes);
// One-time operational tool: move a hub/curriculum/course/assessment the calling admin owns to
// a different admin, by email. See reassign-owner.service.js's header comment for why this
// exists — the 2026-09-07 tenant-isolation backfill had no per-row creator to recover ownership
// from, so pre-existing Live data landed on one admin and needs manual redistribution.
//
// blockIfCollaboratorRestricted is mounted here specifically (rather than tenant-wide) because
// this is the one place authorize("admin") alone isn't enough: attachOwnRecords aliases a
// collaborator's role to "admin" for non-DELETE requests (see its own comment), which would
// otherwise let a collaborator reach reassign-owner and, worse, invite/revoke OTHER
// collaborators on their inviting admin's behalf — both are real-admin-only tenant management,
// not "content creation".
app.use("/api/admin-tools", protect, attachOwnRecords, authorize("admin"), blockIfCollaboratorRestricted, reassignOwnerRoutes, collaboratorRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;