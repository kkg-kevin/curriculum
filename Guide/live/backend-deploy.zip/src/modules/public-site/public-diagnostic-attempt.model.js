const db = require("../../config/db");
const { createRecord, stringifyJsonFields } = require("../../shared/utils/model.utils");

const TABLE = "public_diagnostic_attempts";
const JSON_FIELDS = ["answers", "indicatorBreakdown"];

// One row per anonymous website visitor's completed public diagnostic. Write-once — an attempt
// is graded and stored in a single step (see public-diagnostic.service.js), it never transitions
// status the way assessment_submissions does, so there's no update()/status lifecycle here.
const PublicDiagnosticAttemptModel = {
  // updatedAt: false — this table has no updatedAt column (see the migration's comment: an
  // attempt is graded and written once, it never transitions state the way
  // assessment_submissions does), so createRecord must not try to stamp one.
  create(data) {
    return createRecord(db, TABLE, stringifyJsonFields(data, JSON_FIELDS), { updatedAt: false });
  },
};

module.exports = PublicDiagnosticAttemptModel;
