const { z } = require("zod");

// Mirrors digifunzi-landing's EnrollForm.jsx / lead.validation.js's createLeadSchema field
// shapes exactly — same phone regex, same length limits — so a request that bypasses the
// browser can't skip validation.
const phone = z
  .string()
  .trim()
  .min(7, "Enter a valid phone number")
  .max(20, "Enter a valid phone number")
  .regex(/^[+0-9()\-\s]+$/, "Enter a valid phone number");

// { itemId, response } — response shape depends on item kind (string for mcq/trueFalse,
// string[] for fillBlank/ordering, [{left,right}] for matching) — same permissive `z.any()`
// posture as assessment-submission.validation.js's own answerSchema, since grading.utils.js
// already handles shape mismatches defensively per kind.
const answerSchema = z.object({
  itemId: z.string().min(1),
  response: z.any(),
});

const submitDiagnosticSchema = z.object({
  answers: z.array(answerSchema).default([]),
  parentName: z.string().trim().min(2, "Please enter your name").max(120),
  parentEmail: z.string().trim().email("Enter a valid email address").max(160),
  parentPhone: phone.optional().or(z.literal("")),
  childName: z.string().trim().max(120).optional().or(z.literal("")),
  childAge: z.coerce.number().int().min(3).max(19),
});

module.exports = { submitDiagnosticSchema };
