const asyncHandler = require("express-async-handler");
const { redactUnpublishedReport } = require("./grading.utils");
const AssessmentSubmissionService = require("./assessment-submission.service");
const WebsiteDiagnosticService = require("./website-diagnostic.service");
const LearnerActivityService = require("./learner-activity.service");
const AssessmentModel = require("../assessment.model");
const AssessmentIssueModel = require("./assessment-issue.model");
const ClassModel = require("../../classes/class.model");
const LearnerHubLinkModel = require("../../learners/learner-hub-link.model");
const ClassCourseTeacherLinkModel = require("../../classes/class-course-teacher-link.model");
const LearningHubModel = require("../../learning-hubs/learning-hub.model");
const { assertOwn, isOwnHub } = require("../../../shared/middleware/scope.middleware");
const TotService = require("../../tot/tot.service");
const { withLearnerSafeAssessment } = require("../../../shared/utils/assessment-for-learner");

// A supervisor marks the work of the educators they supervise who are learning (training of
// trainers — modules/tot/): only those educators' own learner records, in whatever class.
async function assertSupervisesLearner(req, learnerId) {
  assertOwn(await TotService.supervisesLearner(req.user.id, learnerId));
}

async function isOwnHubForAdmin(req, hubId) {
  if (!hubId) return false;
  const hubs = await LearningHubModel.findAll({ ownerAdminId: req.ownerAdminId, includeDrafts: true });
  return hubs.some((h) => h.id === hubId);
}
const {
  issueAssessmentSchema,
  issueOnSessionCompleteSchema,
  submitAnswersSchema,
  gradeSubmissionSchema,
  startObservationSchema,
  openObservationSchema,
  gradeMilestoneSchema,
  reissueSchema,
  learnersSchema,
} = require("./assessment-submission.validation");

// Whether this teacher has at least one course-educator link in the given class — the one
// precision level every teacher-facing ownership check in this file uses, whether the class is
// known directly (assertClassAccess) or reached indirectly through a learner's enrollment
// (assertLearnerHubAccess).
async function teacherLinkedToClass(req, classId) {
  const links = await ClassCourseTeacherLinkModel.findByClassId(classId);
  return links.some((l) => l.teacherId === req.ownTeacher?.id);
}

// Issuing/grading/roster-viewing all revolve around a class — reuse the exact ownership check
// classes/attendance already apply, so a teacher can only ever touch a class they have at least
// one course-educator link in, and a school only its own school's classes.
async function assertClassAccess(req, cls) {
  if (!cls) {
    const err = new Error("Class not found");
    err.statusCode = 404;
    throw err;
  }
  if (req.user.role === "school")  assertOwn(cls.schoolId === req.ownSchool?.id);
  if (req.user.role === "admin") assertOwn(await isOwnHubForAdmin(req, cls.schoolId));
  if (req.user.role === "teacher") assertOwn(await teacherLinkedToClass(req, cls.id));
  // A supervisor reaches a class only through an educator of theirs learning in it.
  if (req.user.role === "supervisor") {
    const mine = new Set(await TotService.supervisedTraineeIds(req.user.id));
    const links = await LearnerHubLinkModel.findByClassId(cls.id);
    assertOwn(links.some((l) => mine.has(l.learnerId)));
  }
}

// A standalone diagnostic submission (see issueDiagnostic in assessment-submission.service.js)
// has no classId, so assertClassAccess doesn't apply — ownership instead comes from whether
// the learner is enrolled at a hub/class this caller owns. A "teacher" caller has no hub of
// their own, so their access comes from the learner's class instead — same "any course-link in
// the class is enough" precision assertClassAccess already uses for ordinary class-issued
// grading, not narrowed down to the specific Pathway's courses.
async function assertLearnerHubAccess(req, learnerId) {
  if (req.user.role === "school") {
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    const hubIds = links.map((l) => l.hubId);
    assertOwn(hubIds.some((hubId) => isOwnHub(req, hubId)));
  } else if (req.user.role === "admin") {
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    const results = await Promise.all(links.map((l) => isOwnHubForAdmin(req, l.hubId)));
    assertOwn(results.some(Boolean));
  } else if (req.user.role === "teacher") {
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    const classIds = links.filter((l) => l.classId).map((l) => l.classId);
    const results = await Promise.all(classIds.map((classId) => teacherLinkedToClass(req, classId)));
    assertOwn(results.some(Boolean));
  }
}

function assertLearnerOwnsSubmission(req, submission) {
  if (!submission) {
    const err = new Error("Submission not found");
    err.statusCode = 404;
    throw err;
  }
  if (req.user.role === "learner") assertOwn(submission.learnerId === req.ownLearner?.id);
}

// Shared by getSubmission/gradeSubmission/publishSubmissionReport — a class-issued submission
// checks ownership via its class, a standalone one (diagnostic/course-progress, no classId) via
// the learner's own hub/class links instead.
async function assertSubmissionAccess(req, submission) {
  if (req.user.role === "supervisor") return assertSupervisesLearner(req, submission.learnerId);
  if (submission.classId) {
    await assertClassAccess(req, await ClassModel.findById(submission.classId));
  } else {
    await assertLearnerHubAccess(req, submission.learnerId);
  }
}

// Shared by getIssuesForClass/getSubmissionsNeedingGrading/getStandaloneSubmissionsNeedingGrading
// — every one of them is "resolve the classId query param, require it, then prove this caller
// owns that class" before doing anything else.
async function requireOwnedClassFromQuery(req) {
  const { classId } = req.query;
  if (!classId) {
    const err = new Error("classId is required");
    err.statusCode = 400;
    throw err;
  }
  const cls = await ClassModel.findById(classId);
  await assertClassAccess(req, cls);
  return cls;
}

const issueAssessment = asyncHandler(async (req, res) => {
  const data = issueAssessmentSchema.parse(req.body);
  const cls = await ClassModel.findById(data.classId);
  await assertClassAccess(req, cls);
  const issue = await AssessmentSubmissionService.issueAssessment({ ...data, issuedBy: req.ownTeacher?.id || req.user.id });
  res.status(201).json({ success: true, data: issue });
});

// A Teacher Observation is recorded on a session, never issued (16 Nov 2026): the teacher opens
// the session's observation for their class and marks each learner straight away. Behind it is
// still the class's issue row — reports, competencies and analytics count work through it — made
// here quietly the first time (no due date, the whole class, nothing sent to learners), or the
// one already there. Learners only see it once the teacher submits each one.
const openObservation = asyncHandler(async (req, res) => {
  const data = openObservationSchema.parse(req.body);
  const cls = await ClassModel.findById(data.classId);
  await assertClassAccess(req, cls);
  const assessment = await AssessmentModel.findById(data.assessmentId);
  if (assessment?.type !== "observation") {
    const err = new Error("Only a Teacher Observation is recorded this way — other assessments are issued");
    err.statusCode = 400;
    throw err;
  }
  const existing = await AssessmentIssueModel.findOne({ assessmentId: data.assessmentId, sessionId: data.sessionId, classId: data.classId });
  const issue = existing || await AssessmentSubmissionService.issueAssessment({ ...data, issuedBy: req.ownTeacher?.id || req.user.id, groupMode: false });
  res.status(existing ? 200 : 201).json({ success: true, data: issue });
});

const getIssuesForClass = asyncHandler(async (req, res) => {
  const cls = await requireOwnedClassFromQuery(req);
  const issues = await AssessmentSubmissionService.getIssuesForClass(cls.id);
  res.json({ success: true, data: issues, count: issues.length });
});

// The teacher's cross-cutting "needs grading" queue for one class — see
// getSubmissionsNeedingGrading in the service for why this is separate from a per-issue roster.
const getSubmissionsNeedingGrading = asyncHandler(async (req, res) => {
  const cls = await requireOwnedClassFromQuery(req);
  const rows = await AssessmentSubmissionService.getSubmissionsNeedingGrading(cls.id);
  res.json({ success: true, data: rows, count: rows.length });
});

// Teacher-facing counterpart to getSubmissionsNeedingGrading — see
// getStandaloneSubmissionsNeedingGrading in the service for why this is separate.
const getStandaloneSubmissionsNeedingGrading = asyncHandler(async (req, res) => {
  const cls = await requireOwnedClassFromQuery(req);
  const rows = await AssessmentSubmissionService.getStandaloneSubmissionsNeedingGrading(cls.id);
  res.json({ success: true, data: rows, count: rows.length });
});

const getRosterForIssue = asyncHandler(async (req, res) => {
  const { issue, assessment, roster, groups, ungroupedLearners } = await AssessmentSubmissionService.getRosterForIssue(req.params.id);
  const cls = await ClassModel.findById(issue.classId);
  await assertClassAccess(req, cls);
  // A supervisor sees only their own educators in the class.
  if (req.user.role === "supervisor") {
    const mine = new Set(await TotService.supervisedTraineeIds(req.user.id));
    const keep = (row) => mine.has(row.learner?.id);
    return res.json({ success: true, data: { issue, assessment, roster: roster.filter(keep), groups: [], ungroupedLearners: ungroupedLearners.filter(keep) } });
  }
  res.json({ success: true, data: { issue, assessment, roster, groups, ungroupedLearners } });
});

const revokeIssue = asyncHandler(async (req, res) => {
  const issue = await AssessmentSubmissionService.getIssue(req.params.id);
  if (!issue) {
    const err = new Error("Issue not found");
    err.statusCode = 404;
    throw err;
  }
  // A reissue's id stands for its class issue — revoking for everyone takes every attempt.
  const cls = await ClassModel.findById(await AssessmentSubmissionService.classIdForIssue(issue));
  await assertClassAccess(req, cls);
  await AssessmentSubmissionService.revokeIssue(req.params.id);
  res.json({ success: true });
});

// A learner's issued assessments exactly as their own list shows them — feedback still held back
// until its report is published. Shared by the learner's route and the staff one below.
async function issuedRowsAsLearnerSeesThem(learnerId) {
  const rawRows = await AssessmentSubmissionService.getIssuedRowsForLearner(learnerId);
  return Promise.all(rawRows.map(async (row) => {
    const submission = redactUnpublishedReport(row.submission);
    // Redacted (unpublished) rows already have gradedBy nulled out above, so this naturally
    // resolves to null for them too — no separate gating needed.
    const grader = await AssessmentSubmissionService.resolveGrader(submission.gradedBy);
    return { ...row, submission: { ...submission, gradedByName: grader.name, gradedByPhoto: grader.photo } };
  }));
}

// Learner's own issued-assessments list — scoped entirely off their own enrollment links,
// never off a client-supplied classId, so a learner can't read another class's assignments.
// A learner can now be enrolled in several classes at once, so this merges every active
// enrollment's issued assessments into one list rather than assuming a single class.
const getIssuedForLearner = asyncHandler(async (req, res) => {
  const learner = req.ownLearner;
  if (!learner) return res.json({ success: true, data: [] });
  // The questions without their answers (assessment-for-learner.js) — marking is done on the server.
  const rows = (await issuedRowsAsLearnerSeesThem(learner.id)).map(withLearnerSafeAssessment);
  res.json({ success: true, data: rows, count: rows.length });
});

// Admin/school-facing: the same list, for the learner's profile as staff see it. Rows issued to
// a class are kept to classes at the caller's own hubs, so a learner also enrolled in another
// workspace never shows that workspace's assessments here.
const getIssuedForLearnerAsStaff = asyncHandler(async (req, res) => {
  const { learnerId } = req.params;
  await assertLearnerHubAccess(req, learnerId);
  const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
  const own = await Promise.all(links.map((l) => (req.user.role === "school" ? isOwnHub(req, l.hubId) : isOwnHubForAdmin(req, l.hubId))));
  const ownClassIds = new Set(links.filter((l, i) => own[i] && l.classId).map((l) => l.classId));
  const rows = (await issuedRowsAsLearnerSeesThem(learnerId))
    .filter((row) => !row.issue.classId || ownClassIds.has(row.issue.classId));
  res.json({ success: true, data: rows, count: rows.length });
});

// The profile's activity grid (10 Nov 2026): a year of the learner's assessment work by day, with
// what each piece is and where it opens (learner-activity.service.js). The learner (or their
// parent, through the active child) their own; an admin / hub / staff only work of classes at
// their own hubs, as the issued list above.
const getLearnerActivity = asyncHandler(async (req, res) => {
  const { learnerId } = req.params;
  let classIds = null;
  if (req.user.role === "learner") {
    assertOwn(learnerId === req.ownLearner?.id);
  } else {
    await assertLearnerHubAccess(req, learnerId);
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    const own = await Promise.all(links.map((l) => (req.user.role === "school" ? isOwnHub(req, l.hubId) : isOwnHubForAdmin(req, l.hubId))));
    classIds = new Set(links.filter((l, i) => own[i] && l.classId).map((l) => l.classId));
  }
  const data = await LearnerActivityService.forLearner(learnerId, { classIds });
  res.json({ success: true, data });
});

// Admin/school-facing: this learner's auto-issued diagnostic (if any), for the Diagnostic
// Assessment card on LearnerPage. Also learner-facing (own record only) — the learner-
// portal's first-login diagnostic gate reads this directly, scoped to its own curriculum via
// ?curriculumId, so a learner's Stage diagnostic from a different hub never leaks in.
const getDiagnosticForLearner = asyncHandler(async (req, res) => {
  if (req.user.role === "learner") {
    assertOwn(req.params.learnerId === req.ownLearner?.id);
  } else {
    await assertLearnerHubAccess(req, req.params.learnerId);
  }
  const row = await AssessmentSubmissionService.getDiagnosticForLearner(req.params.learnerId, req.query.curriculumId || null);
  res.json({ success: true, data: req.user.role === "learner" ? withLearnerSafeAssessment(row) : row });
});

// Same access shape as getDiagnosticForLearner, plural — this learner's Pathway
// diagnostics, for the Pathway section of LearnerPage. Also readable by the
// learner themselves (their own record only) — the learner-portal's first-login diagnostic
// gate uses this same endpoint rather than a separate one.
const getPathwayDiagnosticsForLearner = asyncHandler(async (req, res) => {
  if (req.user.role === "learner") {
    assertOwn(req.params.learnerId === req.ownLearner?.id);
  } else {
    await assertLearnerHubAccess(req, req.params.learnerId);
  }
  const all = await AssessmentSubmissionService.getPathwayDiagnosticsForLearner(req.params.learnerId);
  const rows = req.user.role === "learner" ? all.map(withLearnerSafeAssessment) : all;
  res.json({ success: true, data: rows, count: rows.length });
});

// The profile's diagnostic report — every marked pathway diagnostic this learner holds, from the
// website or the portal, with its competency marks (website-diagnostic.service.js). Same access
// shape as the two above; ?curriculumId narrows it to one hub's curriculum.
const getDiagnosticReportsForLearner = asyncHandler(async (req, res) => {
  if (req.user.role === "learner") {
    assertOwn(req.params.learnerId === req.ownLearner?.id);
  } else {
    await assertLearnerHubAccess(req, req.params.learnerId);
  }
  const rows = await WebsiteDiagnosticService.reportsForLearner(req.params.learnerId, req.query.curriculumId || null);
  res.json({ success: true, data: rows, count: rows.length });
});

// A learner reading their own accumulating competency progress, or an admin/school reviewing
// it for a learner in their own hub — same access shape as the diagnostic card.
const getLearnerIndicatorProgress = asyncHandler(async (req, res) => {
  const learnerId = req.params.learnerId;
  if (req.user.role === "learner") {
    assertOwn(learnerId === req.ownLearner?.id);
  } else {
    await assertLearnerHubAccess(req, learnerId);
  }
  const rows = await AssessmentSubmissionService.getLearnerIndicatorProgress(learnerId, req.query.curriculumId || null);
  res.json({ success: true, data: rows, count: rows.length });
});

// Learner-facing: fired client-side the moment SectionViewPage.jsx detects every other
// section of a session is complete — issues that session's attached assessment(s) to this
// learner alone (see issueOnSessionComplete), independent of classmates' own progress.
const issueOnSessionComplete = asyncHandler(async (req, res) => {
  const learner = req.ownLearner;
  assertOwn(!!learner);
  const data = issueOnSessionCompleteSchema.parse(req.body);
  const issue = await AssessmentSubmissionService.issueOnSessionComplete({ ...data, learnerId: learner.id });
  res.status(201).json({ success: true, data: issue });
});

const getOrCreateSubmission = asyncHandler(async (req, res) => {
  const { issueId } = req.body;
  if (!issueId) {
    const err = new Error("issueId is required");
    err.statusCode = 400;
    throw err;
  }
  const learner = req.ownLearner;
  assertOwn(!!learner);
  // Teacher Observation assessments have no learner-facing "take" step at all — the teacher
  // records the whole thing directly (see startObservationSubmission below). This is the real
  // access-control boundary, not just the learner-portal list hiding it (getIssuedAssessmentsForLearner) —
  // a learner hitting this endpoint directly for one still gets turned away.
  const issue = await AssessmentSubmissionService.getIssue(issueId);
  if (!issue) {
    const err = new Error("Issue not found");
    err.statusCode = 404;
    throw err;
  }
  const assessment = await AssessmentModel.findById(issue.assessmentId);
  if (assessment?.type === "observation") {
    const err = new Error("Teacher Observation assessments are recorded by your teacher — there's nothing here for you to start.");
    err.statusCode = 403;
    throw err;
  }
  const submission = await AssessmentSubmissionService.getOrCreateSubmission({ issueId, learnerId: learner.id });
  res.status(201).json({ success: true, data: submission });
});

// The teacher-side counterpart to getOrCreateSubmission above, for Teacher Observation
// assessments only — a teacher directly opens/creates a learner's submission (no "submitted"
// step to wait on) so they can go straight to GradingPanel and record indicators themselves.
// Rejects any other assessment type server-side, not just hidden client-side (see
// AssessmentRosterPage.jsx's "Begin Observation" flow, the only caller).
const startObservationSubmission = asyncHandler(async (req, res) => {
  const { learnerId } = startObservationSchema.parse(req.body);
  const issue = await AssessmentSubmissionService.getIssue(req.params.id);
  if (!issue) {
    const err = new Error("Issue not found");
    err.statusCode = 404;
    throw err;
  }
  // A reissue has no class of its own: its original's, and only for the learner it was reissued to.
  const classId = await AssessmentSubmissionService.classIdForIssue(issue);
  if (issue.learnerId && issue.learnerId !== learnerId) {
    const err = new Error("This assessment was reissued to another learner");
    err.statusCode = 400;
    throw err;
  }
  const cls = await ClassModel.findById(classId);
  await assertClassAccess(req, cls);
  if (req.user.role === "supervisor") await assertSupervisesLearner(req, learnerId);
  const assessment = await AssessmentModel.findById(issue.assessmentId);
  if (assessment?.type !== "observation") {
    const err = new Error("Only Teacher Observation assessments can be started this way");
    err.statusCode = 400;
    throw err;
  }
  const links = await LearnerHubLinkModel.findByClassId(classId);
  const enrolled = links.some((l) => l.learnerId === learnerId && l.status === "active");
  if (!enrolled) {
    const err = new Error("This learner isn't enrolled in this class");
    err.statusCode = 400;
    throw err;
  }
  const submission = await AssessmentSubmissionService.getOrCreateSubmission({ issueId: req.params.id, learnerId });
  res.status(201).json({ success: true, data: submission });
});

// Grades one milestone of a project assessment — same ownership shape as startObservationSubmission
// (a teacher may only grade milestones for a learner enrolled in a class they own), but gated to
// type "project" instead. Auto-creates the submission on the first milestone grade, same as
// observation's start flow — see gradeMilestone's comment in the service for why.
const gradeMilestone = asyncHandler(async (req, res) => {
  const { learnerId, marks, feedback } = gradeMilestoneSchema.parse(req.body);
  const issue = await AssessmentSubmissionService.getIssue(req.params.id);
  if (!issue) {
    const err = new Error("Issue not found");
    err.statusCode = 404;
    throw err;
  }
  // A reissue has no class of its own: its original's, and only for the learner it was reissued to.
  const classId = await AssessmentSubmissionService.classIdForIssue(issue);
  if (issue.learnerId && issue.learnerId !== learnerId) {
    const err = new Error("This assessment was reissued to another learner");
    err.statusCode = 400;
    throw err;
  }
  const cls = await ClassModel.findById(classId);
  await assertClassAccess(req, cls);
  if (req.user.role === "supervisor") await assertSupervisesLearner(req, learnerId);
  const assessment = await AssessmentModel.findById(issue.assessmentId);
  if (assessment?.type !== "project") {
    const err = new Error("Only Project assessments can be graded by milestone");
    err.statusCode = 400;
    throw err;
  }
  const links = await LearnerHubLinkModel.findByClassId(classId);
  const enrolled = links.some((l) => l.learnerId === learnerId && l.status === "active");
  if (!enrolled) {
    const err = new Error("This learner isn't enrolled in this class");
    err.statusCode = 400;
    throw err;
  }
  const submission = await AssessmentSubmissionService.gradeMilestone({
    issueId: req.params.id, learnerId, milestoneId: req.params.milestoneId, marks, feedback,
    gradedBy: req.ownTeacher?.id || req.user.id,
  });
  res.json({ success: true, data: submission });
});

// A teacher, having graded a submission and decided it wasn't good enough, gives this one
// learner another shot at the same assessment — see reissueToLearner's comment in the service
// for why this creates a new issue rather than resetting the original. Same ownership shape as
// gradeMilestone/startObservationSubmission: whoever could grade the original issue can reissue
// it, checked off the ORIGINAL issue's class (a reissue's own new issue has no classId of its
// own to check).
// Reissues to chosen learners (`learnerIds`; one `learnerId` still works): `{ reissued, skipped }`
// — each skipped learner with why (see reissueBlocker in the service).
const reissueAssessment = asyncHandler(async (req, res) => {
  const { learnerIds, dueDate, timeLimitMinutes } = reissueSchema.parse(req.body);
  const issue = await AssessmentSubmissionService.getIssue(req.params.id);
  if (!issue) {
    const err = new Error("Issue not found");
    err.statusCode = 404;
    throw err;
  }
  if (req.user.role === "supervisor") {
    for (const learnerId of learnerIds) await assertSupervisesLearner(req, learnerId);
  } else {
    const classId = await AssessmentSubmissionService.classIdForIssue(issue);
    if (classId) {
      await assertClassAccess(req, await ClassModel.findById(classId));
    } else {
      for (const learnerId of learnerIds) await assertLearnerHubAccess(req, learnerId);
    }
  }
  const result = await AssessmentSubmissionService.reissueToLearners({
    issueId: req.params.id, learnerIds, dueDate, timeLimitMinutes, reissuedBy: req.ownTeacher?.id || req.user.id,
  });
  // One learner asked for and refused: the reason as the error, as before.
  if (!result.reissued.length && result.skipped.length === 1 && learnerIds.length === 1) {
    const err = new Error(result.skipped[0].reason);
    err.statusCode = 409;
    throw err;
  }
  res.status(201).json({ success: true, data: result });
});

// Revokes an issued assessment for chosen learners only, or gives it back to them — whoever may
// manage the class. A reissue's id stands for its class issue.
async function classOfIssueForStaff(req) {
  const issue = await AssessmentSubmissionService.getIssue(req.params.id);
  const classId = issue ? await AssessmentSubmissionService.classIdForIssue(issue) : null;
  if (!classId) {
    const err = new Error("Issue not found");
    err.statusCode = 404;
    throw err;
  }
  await assertClassAccess(req, await ClassModel.findById(classId));
}

const revokeForLearners = asyncHandler(async (req, res) => {
  await classOfIssueForStaff(req);
  const { learnerIds } = learnersSchema.parse(req.body);
  res.json({ success: true, data: await AssessmentSubmissionService.revokeForLearners({ issueId: req.params.id, learnerIds, revokedBy: req.ownTeacher?.id || req.user.id }) });
});

const restoreForLearners = asyncHandler(async (req, res) => {
  await classOfIssueForStaff(req);
  const { learnerIds } = learnersSchema.parse(req.body);
  res.json({ success: true, data: await AssessmentSubmissionService.restoreForLearners({ issueId: req.params.id, learnerIds }) });
});

const saveDraft = asyncHandler(async (req, res) => {
  const existing = await AssessmentSubmissionService.getSubmission(req.params.id);
  assertLearnerOwnsSubmission(req, existing);
  const { answers } = submitAnswersSchema.parse(req.body);
  const submission = await AssessmentSubmissionService.saveDraft(req.params.id, answers);
  res.json({ success: true, data: submission });
});

const submitAnswers = asyncHandler(async (req, res) => {
  const existing = await AssessmentSubmissionService.getSubmission(req.params.id);
  assertLearnerOwnsSubmission(req, existing);
  const { answers } = submitAnswersSchema.parse(req.body);
  const submission = await AssessmentSubmissionService.submit(req.params.id, answers);
  res.json({ success: true, data: submission });
});

const getSubmission = asyncHandler(async (req, res) => {
  const submission = await AssessmentSubmissionService.getSubmission(req.params.id);
  if (!submission) {
    const err = new Error("Submission not found");
    err.statusCode = 404;
    throw err;
  }
  if (req.user.role === "learner") {
    assertOwn(submission.learnerId === req.ownLearner?.id);
    res.json({ success: true, data: redactUnpublishedReport(submission) });
    return;
  }
  await assertSubmissionAccess(req, submission);
  res.json({ success: true, data: submission });
});

const gradeSubmission = asyncHandler(async (req, res) => {
  const existing = await AssessmentSubmissionService.getSubmission(req.params.id);
  if (!existing) {
    const err = new Error("Submission not found");
    err.statusCode = 404;
    throw err;
  }
  await assertSubmissionAccess(req, existing);
  const data = gradeSubmissionSchema.parse(req.body);
  const submission = await AssessmentSubmissionService.grade(req.params.id, { ...data, gradedBy: req.ownTeacher?.id || req.user.id });
  res.json({ success: true, data: submission });
});

// Teacher's explicit "make this grade visible to the learner" action — same ownership shape as
// gradeSubmission, since only whoever could grade it should be able to release it.
const publishSubmissionReport = asyncHandler(async (req, res) => {
  const existing = await AssessmentSubmissionService.getSubmission(req.params.id);
  if (!existing) {
    const err = new Error("Submission not found");
    err.statusCode = 404;
    throw err;
  }
  await assertSubmissionAccess(req, existing);
  const submission = await AssessmentSubmissionService.publishReport(req.params.id, req.ownTeacher?.id || req.user.id);
  res.json({ success: true, data: submission });
});

module.exports = {
  issueAssessment,
  getIssuesForClass,
  getSubmissionsNeedingGrading,
  getStandaloneSubmissionsNeedingGrading,
  getRosterForIssue,
  revokeIssue,
  getIssuedForLearner,
  getIssuedForLearnerAsStaff,
  getLearnerActivity,
  getDiagnosticForLearner,
  getPathwayDiagnosticsForLearner,
  getDiagnosticReportsForLearner,
  getLearnerIndicatorProgress,
  issueOnSessionComplete,
  getOrCreateSubmission,
  startObservationSubmission,
  openObservation,
  gradeMilestone,
  saveDraft,
  submitAnswers,
  getSubmission,
  gradeSubmission,
  publishSubmissionReport,
  reissueAssessment,
  revokeForLearners,
  restoreForLearners,
};
