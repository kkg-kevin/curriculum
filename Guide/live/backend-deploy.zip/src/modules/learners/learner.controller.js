const asyncHandler = require("express-async-handler");
const LearnerService = require("./learner.service");
const LearnerModel = require("./learner.model");
const AuthService = require("../auth/auth.service");
const LearnerHubLinkModel = require("./learner-hub-link.model");
const { createLearnerSchema, updateLearnerSchema, updateLearnerAccountStatusSchema, enrollLearnerSchema, updateEnrollmentSchema, transferHubSchema, bulkImportLearnersSchema, bulkImportRowSchema } = require("./learner.validation");
const { assertOwn, isOwnHub } = require("../../shared/middleware/scope.middleware");
const ClassCourseTeacherLinkModel = require("../classes/class-course-teacher-link.model");
const ClassModel = require("../classes/class.model");
const LearningHubModel = require("../learning-hubs/learning-hub.model");
const UsageService = require("../usage/usage.service");
const UserModel = require("../auth/user.model");
const LearnerParentService = require("./learner-parent.service");
const { cleanImportRow, sameLearner } = require("./learner.import");
const { kenyaToday } = require("../../shared/utils/age");
const { originOf } = require("./learner-origin");
const WebsiteDiagnosticService = require("../assessments/submissions/website-diagnostic.service");
const LearnerPasswordVault = require("../auth/learner-password-vault");
const AuditService = require("../audit/audit.service");

// A learner has no ownerAdminId of its own (see the migration's comment on why only
// learning_hubs/curricula/courses/assessments got one) — tenancy is entirely derived from which
// hub(s) it's enrolled at, same idea as teacher.controller.js's adminOwnedHubIds.
async function adminOwnedHubIds(req) {
  const hubs = await LearningHubModel.findAll({ ownerAdminId: req.ownerAdminId, includeDrafts: true });
  return hubs.map((h) => h.id);
}

// A learner belongs to a class, and a class has zero or more course-educator links — this is the
// only place a teacher's access to a learner is decided, so both getAllLearners and
// getLearnerById go through it.
async function classTaughtByTeacher(classId, teacherId) {
  if (!classId) return false;
  const links = await ClassCourseTeacherLinkModel.findByClassId(classId);
  return links.some((l) => l.teacherId === teacherId);
}

// True whenever `learnerId` has an enrollment link at `hubId` — the membership test a
// "school"-role caller needs to prove a learner belongs to its own hub. Same pattern as
// teacher.controller.js's `isLinkedToHub`.
async function isLinkedToHub(learnerId, hubId) {
  const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
  return links.some((l) => l.hubId === hubId);
}

// Same membership test, scoped to a "school" account's currently active hub (see
// scope.middleware.js's req.ownSchool — a parent hub's admin switching into a branch hub gets
// this for free, no change needed here) — or, for "admin", any of the hubs they own. An admin
// also owns every learner their tenant created, even one not yet linked to any hub (created from
// the top-level Learners page, hub assigned afterwards from the profile).
async function isLinkedToOwnHub(req, learnerId) {
  if (req.user.role === "school") return isLinkedToHub(learnerId, req.ownSchool?.id);
  if (req.user.role === "admin") {
    const learner = await LearnerModel.findById(learnerId);
    if (learner?.createdByAdminId && learner.createdByAdminId === req.ownerAdminId) return true;
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    const ownHubIds = new Set(await adminOwnedHubIds(req));
    return links.some((l) => ownHubIds.has(l.hubId));
  }
  return false;
}

// True whenever any of `learnerId`'s enrollment links puts them in a class this teacher
// teaches — a learner can now have several enrollments, so this is an "any", not the old
// single-classId equality check.
async function anyEnrollmentTaughtByTeacher(learnerId, teacherId) {
  const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
  const results = await Promise.all(links.map((l) => classTaughtByTeacher(l.classId, teacherId)));
  return results.some(Boolean);
}

const createLearner = asyncHandler(async (req, res) => {
  const { hubId, classId, spaceId } = req.body;
  const { password, learnerPassword, ...data } = createLearnerSchema.parse(req.body);
  // Create the login first — if it fails (e.g. the email already belongs to a different-role
  // account), nothing is written at all, rather than leaving a learner record with no login.
  if (password) {
    await AuthService.setOrCreatePassword({ name: data.guardianName, email: data.guardianEmail, password, role: "learner" });
  } else {
    await AuthService.linkExistingLogin(data.guardianEmail, "learner");
  }
  // Stamped server-side (never from the body — the schema strips it) so the creating admin keeps
  // access before any hub link exists; see isLinkedToOwnHub.
  if (req.user.role === "admin") data.createdByAdminId = req.ownerAdminId;
  if (data.statedAge != null) data.statedAgeOn = kenyaToday();
  const record = await LearnerService.createLearner(data);
  // The learner's OWN dedicated login is minted only after the record — createLearner's own
  // username-uniqueness check (assertUsernameAvailable) has to throw first, so a colliding/
  // typo'd username can never silently reset a different learner's own login before this
  // record is even confirmed valid.
  if (learnerPassword) {
    await AuthService.setOrCreatePasswordByUsername({
      name: `${record.firstName} ${record.lastName}`.trim(),
      username: record.username,
      password: learnerPassword,
      role: "learner",
    });
  }
  // A learner is never linked to a hub as part of its own identity — hubId here is purely an
  // optional one-shot convenience (e.g. "Enroll Learner" clicked from within a school's own
  // page), a second write after the learner already exists, same as createTeacher.
  let linkHubId = hubId || undefined;
  if (req.user.role === "school") linkHubId = req.ownSchool?.id;
  else if (req.user.role === "admin" && linkHubId) {
    // A client-supplied hubId must actually be one of this admin's own hubs — otherwise an
    // admin could plant a brand-new learner directly into another admin's tenant.
    assertOwn((await adminOwnedHubIds(req)).includes(linkHubId));
  }
  if (linkHubId) await LearnerService.enrollInHub(record.id, { hubId: linkHubId, classId: classId || "", status: "active", spaceId: spaceId || null });
  res.status(201).json({ success: true, data: record });
});

// Onboards many learners in one request (a school importing a class roster from a spreadsheet)
// by running each row through the exact same steps createLearner uses one at a time — guardian
// login, then the record, then the learner's own login, then hub enrollment — just per-row and
// non-atomic: one bad row (duplicate username, invalid email) is recorded as a per-row failure
// and the rest of the batch still goes through, rather than the whole import dying on row 47.
// Unlike createLearner's own optional hubId/classId, classId is REQUIRED here (see
// bulkImportLearnersSchema) — every row in the batch enrolls into that one class, so a
// mismatched/forged classId still fails safely per-row via enrollInHub's own
// class-belongs-to-hub check, it just never falls back to "first active class" the way a single
// manual enrollment does.
//
// Each row is tidied first (learner.import.js: phone, date of birth, gender; the template's
// example row refused). A learner already on record — at this hub, or created by this workspace
// — or one earlier in the same file isn't added again. A guardian email that already has a login
// keeps its own password: the shared password only ever sets up NEW parent logins; an existing
// login of another kind (an educator, an admin) takes the parent role instead (account-roles.js).
const bulkImportLearners = asyncHandler(async (req, res) => {
  const { hubId: bodyHubId, classId, defaultPassword, learners } = bulkImportLearnersSchema.parse(req.body);
  let hubId = bodyHubId || undefined;
  if (req.user.role === "school") hubId = req.ownSchool?.id;
  else if (req.user.role === "admin" && hubId) {
    assertOwn((await adminOwnedHubIds(req)).includes(hubId));
  }

  // Who's already on record here, to catch the same child imported twice.
  const knownIds = new Set(hubId ? (await LearnerHubLinkModel.findByHubId(hubId)).map((l) => l.learnerId) : []);
  if (req.user.role === "admin") (await LearnerModel.findIdsCreatedByAdmin(req.ownerAdminId)).forEach((id) => knownIds.add(id));
  const known = knownIds.size ? await LearnerModel.findAll({ ids: [...knownIds] }) : [];
  const seenInFile = [];

  const results = [];
  for (let i = 0; i < learners.length; i++) {
    const raw = learners[i];
    const name = `${raw.firstName || ""} ${raw.lastName || ""}`.trim() || `Row ${i + 1}`;
    try {
      const cleaned = cleanImportRow(raw);
      if (cleaned.errors.length) throw new Error(cleaned.errors.join("; "));
      // Parsed per-row, inside the try — a malformed row (bad gender, missing guardian phone,
      // etc.) throws here and is caught as this row's own failure, same as any other error
      // below, instead of ever reaching bulkImportLearnersSchema and rejecting the whole batch.
      const row = bulkImportRowSchema.parse(cleaned.row);
      const existing = known.find((l) => sameLearner(row, l));
      if (existing) throw new Error(`Already on record as ${existing.firstName} ${existing.lastName}${existing.registrationNumber ? ` (${existing.registrationNumber})` : ""} — not added again`);
      if (seenInFile.some((r) => sameLearner(row, r))) throw new Error("The same learner is on an earlier row of this file — not added twice");
      seenInFile.push(row);

      let parentLogin = null;
      if (row.guardianEmail) {
        const login = await UserModel.findByEmail(row.guardianEmail);
        if (!login && defaultPassword) {
          await AuthService.setOrCreatePassword({ name: row.guardianName, email: row.guardianEmail, password: defaultPassword, role: "learner" });
          parentLogin = "created";
        } else if (login) {
          // Never reset: a parent (or an educator/admin who is also a parent) keeps their password.
          parentLogin = (await AuthService.linkExistingLogin(row.guardianEmail, "learner")) ? "linked" : "kept";
        }
      }
      const record = await LearnerService.createLearner(req.user.role === "admin" ? { ...row, createdByAdminId: req.ownerAdminId } : row);
      if (defaultPassword && row.username) {
        await AuthService.setOrCreatePasswordByUsername({ name, username: record.username, password: defaultPassword, role: "learner" });
      }
      await LearnerService.enrollInHub(record.id, { hubId, classId, status: "active" });
      results.push({ row: i, name, success: true, learnerId: record.id, parentLogin });
    } catch (err) {
      const error = Array.isArray(err.issues) ? err.issues.map((issue) => issue.message).join("; ") : err.message;
      results.push({ row: i, name, success: false, error });
    }
  }

  const created = results.filter((r) => r.success).length;
  res.status(201).json({ success: true, data: { created, failed: results.length - created, results } });
});

const getAllLearners = asyncHandler(async (req, res) => {
  const { schoolId, classId, status, guardianEmail, q, limit, offset } = req.query;
  // Cross-hub search by name, username, or registration number — how a school finds a learner
  // already enrolled at a DIFFERENT hub, in order to also enroll them at this one (see
  // AddExistingLearnerPanel on the client). Deliberately bypasses the single-hub scoping filter
  // below, since the whole point is finding someone outside it; gated to roles that already
  // manage enrollment (never teacher/learner, which would otherwise gain arbitrary cross-learner
  // lookup). Returns only a hubCount per match, never the other hub's identity — same privacy
  // shape as the unscoped cross-hub branch in LearnerService.getAllLearners. For "admin" this
  // still respects TENANT boundaries though (unlike "school", which is allowed to search across
  // every hub platform-wide by design) — otherwise an admin could discover another admin's
  // learners by name/registration number, the same leak this whole feature exists to close.
  if (q && q.trim() && ["admin", "school"].includes(req.user.role)) {
    const records = await LearnerModel.search(q);
    let scoped = records;
    if (req.user.role === "admin") {
      const ownHubIds = new Set(await adminOwnedHubIds(req));
      const withLinks = await Promise.all(records.map(async (record) => ({
        record,
        links: await LearnerHubLinkModel.findByLearnerId(record.id),
      })));
      scoped = withLinks
        .filter(({ record, links }) => record.createdByAdminId === req.ownerAdminId || links.some((l) => ownHubIds.has(l.hubId)))
        .map(({ record }) => record);
    }
    const data = await Promise.all(scoped.map(async (record) => ({
      ...record,
      hubCount: (await LearnerHubLinkModel.findByLearnerId(record.id)).length,
    })));
    return res.json({ success: true, data, count: data.length });
  }
  const filters = {
    schoolId, classId, status, guardianEmail,
    limit: limit ? Number(limit) : undefined,
    offset: offset ? Number(offset) : undefined,
    // Educators in training (TOT) aren't the hub's learners — left out of hub and workspace lists,
    // but kept in a class's own roster (a TOT class is made of them) and in a learner's own view.
    // ?trainees=1 keeps them anywhere.
    excludeTrainees: !classId && req.user.role !== "learner" && req.query.trainees !== "1",
  };
  if (req.user.role === "school") {
    if (!req.ownSchool) return res.json({ success: true, data: [], count: 0 });
    filters.schoolId = req.ownSchool.id;
  } else if (req.user.role === "teacher") {
    if (!req.ownTeacher || !(await classTaughtByTeacher(classId, req.ownTeacher.id))) {
      return res.json({ success: true, data: [], count: 0 });
    }
  }
  let ownHubIds = null;
  if (req.user.role === "admin") {
    ownHubIds = await adminOwnedHubIds(req);
    if (schoolId) {
      // A specific schoolId was requested directly (e.g. a hub's own learner-roster page) —
      // confirm it's actually one of this admin's own hubs rather than trusting the query param,
      // same posture as isOwnedByAdmin elsewhere; a client-supplied id must never widen access.
      assertOwn(ownHubIds.includes(schoolId));
    } else if (classId) {
      // classId alone (no schoolId) — resolve the class's own hub and check that instead, same
      // idea as the schoolId branch above, just one hop further (a class always belongs to
      // exactly one hub via schoolId — see class.model.js).
      const cls = await ClassModel.findById(classId);
      assertOwn(cls && ownHubIds.includes(cls.schoolId));
    } else {
      // Unbounded case — resolve every hub this admin owns, then every learner linked to any of
      // them. A learner has no owner column of its own, so this is the only way to scope the
      // otherwise-unbounded !schoolId && !classId branch (see learner.service.js's
      // getAllLearners) to this admin's tenant — plus every learner the tenant created that has no
      // hub link yet, or they'd be unreachable until someone enrolled them.
      const links = (await Promise.all(ownHubIds.map((hubId) => LearnerHubLinkModel.findByHubId(hubId)))).flat();
      const createdIds = await LearnerModel.findIdsCreatedByAdmin(req.ownerAdminId);
      filters.ids = [...new Set([...links.map((l) => l.learnerId), ...createdIds])];
    }
  } else if (req.user.role === "learner") {
    if (!req.ownLearner) return res.json({ success: true, data: [], count: 0 });
    // The learner's own dedicated login only ever sees itself, never siblings — the
    // guardian-mediated login is the one that broadens to every learner sharing its email
    // (see the sibling-switcher this feeds in the learner-portal).
    if (req.user.username) {
      filters.ids = [req.ownLearner.id];
      // Only itself, whatever email the page asked by (an educator learning — TOT — signs in
      // with their own email, which is no guardian's).
      delete filters.guardianEmail;
    } else filters.guardianEmail = req.ownLearner.guardianEmail;
  }
  let records = await LearnerService.getAllLearners(filters);
  // A learner of this workspace may also be enrolled at another workspace's hub — that one isn't
  // named here.
  if (ownHubIds && !schoolId && !classId) {
    const own = new Set(ownHubIds);
    records = records.map((r) => ({ ...r, hubIds: (r.hubIds || []).filter((id) => own.has(id)) }));
  }
  res.json({ success: true, data: records, count: records.length });
});

// The learner's parent on its own (the staff learner page's Parent tab): their details, their login,
// their children this viewer may see, and — for admins — what they've signed up for. See
// learner-parent.service.js.
const getLearnerParent = asyncHandler(async (req, res) => {
  const record = await LearnerService.getLearnerById(req.params.id);
  assertOwn(await isLinkedToOwnHub(req, record.id));
  const isAdmin = req.user.role === "admin";
  const visibleHubIds = isAdmin ? await adminOwnedHubIds(req) : [req.ownSchool?.id].filter(Boolean);
  const data = await LearnerParentService.forLearner(record, { visibleHubIds, ownerAdminId: isAdmin ? req.ownerAdminId : null, isAdmin });
  res.json({ success: true, data });
});

// The learner page's Login card: the child's own username login and, when someone clicks Show,
// its password — kept for children's logins only (auth/learner-password-vault.js). Same access as
// the Parent tab; every look is recorded in the Activity log. `password` is null when none is kept
// (set before passwords were kept, or there's no login yet) — staff set a new one instead.
const getLearnerLoginPassword = asyncHandler(async (req, res) => {
  // An Account Manager / Training Lead has view-only hub access — not a child's password.
  if (req.user.hubLead) throw Object.assign(new Error("Only staff who manage learners can see a learner's password"), { statusCode: 403 });
  const record = await LearnerService.getLearnerById(req.params.id);
  assertOwn(await isLinkedToOwnHub(req, record.id));
  const login = record.username ? await UserModel.findByUsername(record.username) : null;
  const childLogin = LearnerPasswordVault.isChildLogin(login) ? login : null;
  const { password, setAt } = childLogin ? await LearnerPasswordVault.reveal(childLogin.id) : { password: null, setAt: null };
  if (childLogin) {
    AuditService.recordViewed(req, {
      module: "learners", entityType: "learners", entityId: record.id,
      entityLabel: `${record.firstName} ${record.lastName}`.trim(),
      summary: password ? "Viewed the learner's login password" : "Looked for the learner's login password (none kept)",
    });
  }
  res.json({ success: true, data: { username: record.username || null, hasLogin: Boolean(childLogin), password, setAt } });
});

// Website diagnostics staff can link to a learner they added (the family took one, then enquired
// rather than enrolling online) — and linking one, which places them from it like a diagnostic
// marked in the portal. See website-diagnostic.service.js.
const getLearnerWebsiteDiagnostics = asyncHandler(async (req, res) => {
  const record = await LearnerService.getLearnerById(req.params.id);
  assertOwn(await isLinkedToOwnHub(req, record.id));
  res.json({ success: true, data: await WebsiteDiagnosticService.candidatesFor(record) });
});

const linkLearnerWebsiteDiagnostic = asyncHandler(async (req, res) => {
  const record = await LearnerService.getLearnerById(req.params.id);
  assertOwn(await isLinkedToOwnHub(req, record.id));
  // Only one of the diagnostics offered for this learner — never an arbitrary attempt id.
  const candidates = await WebsiteDiagnosticService.candidatesFor(record);
  assertOwn(candidates.some((c) => c.attemptId === req.params.attemptId));
  const { created } = await WebsiteDiagnosticService.attach(record.id, req.params.attemptId);
  res.status(created ? 201 : 200).json({ success: true, data: { created } });
});

const getLearnerById = asyncHandler(async (req, res) => {
  const record = await LearnerService.getLearnerById(req.params.id);
  if (req.user.role === "school") assertOwn(await isLinkedToOwnHub(req, record.id));
  if (req.user.role === "admin") assertOwn(await isLinkedToOwnHub(req, record.id));
  if (req.user.role === "teacher") assertOwn(await anyEnrollmentTaughtByTeacher(record.id, req.ownTeacher?.id));
  if (req.user.role === "learner") assertOwn(record.id === req.ownLearner?.id);
  // Staff also see how the learner joined (the learner page's "Joined via").
  if (req.user.role === "learner") return res.json({ success: true, data: record });
  res.json({ success: true, data: { ...record, origin: await originOf(record) } });
});

// Self-service fields the learner's OWN dedicated login (as opposed to the guardian-mediated
// one) may change on the record — deliberately excludes guardianName/guardianPhone/
// guardianEmail: those are the GUARDIAN's own profile, edited only from the guardian's login.
// The guardian's own `password` is likewise never honored from this login (see below) — only
// `learnerPassword`, the learner's own credential, ever is.
const LEARNER_SELF_EDIT_FIELDS = ["firstName", "lastName", "gender", "dateOfBirth", "statedAge", "nationality", "languages", "photo", "username"];

const updateLearner = asyncHandler(async (req, res) => {
  const { password, learnerPassword, ...parsed } = updateLearnerSchema.parse(req.body);
  // .partial() still applies each field's .default() when it's absent from the request body
  // (currentRungId defaults to null) — without this filter, a PUT that only sends identity
  // fields (e.g. the learner-portal profile edit form) would silently wipe whatever placement a
  // teacher/admin had already set. Only keys the caller actually sent survive.
  const data = Object.fromEntries(Object.entries(parsed).filter(([key]) => key in req.body));
  if ("accountStatus" in data && req.user.role !== "admin") {
    const err = new Error("Only administrators can change learner account status");
    err.statusCode = 403;
    throw err;
  }
  // Fetched unconditionally (not just for "school") — the username-rename sync below
  // needs the pre-update value regardless of who's making the change.
  const before = await LearnerService.getLearnerById(req.params.id);
  if (req.user.role === "school" || req.user.role === "admin") {
    assertOwn(await isLinkedToOwnHub(req, before.id));
  }
  // A learner's own dedicated login may only touch its own identity fields + its own login
  // password — guardian contact info and the guardian's own password stay guardian-login-only,
  // enforced here (not just hidden client-side) since a determined caller could otherwise still
  // PUT those fields directly. The guardian-mediated login (req.user.username absent) keeps full
  // write access to everything, exactly as before this change.
  let allowGuardianPassword = true;
  if (req.user.role === "learner") {
    // "learner" (either login) may only ever update its own linked record — the learner-portal
    // profile edit form, never an arbitrary id.
    assertOwn(req.params.id === req.ownLearner?.id);
    if (req.user.username) {
      Object.keys(data).forEach((key) => { if (!LEARNER_SELF_EDIT_FIELDS.includes(key)) delete data[key]; });
      allowGuardianPassword = false;
    }
    // An educator learning (TOT) signs in as the educator: their learning record gets no username
    // or password of its own.
    if (req.user.learningAsEducator && (learnerPassword || "username" in data)) {
      throw Object.assign(new Error("You sign in as an educator — your learning has no separate login"), { statusCode: 400 });
    }
  }
  // The day an age is given is the day it changes — re-saving the same age keeps its day.
  if ("statedAge" in data) {
    if ((data.statedAge ?? null) === (before.statedAge ?? null)) delete data.statedAge;
    else data.statedAgeOn = data.statedAge != null ? kenyaToday() : null;
  }
  const record = await LearnerService.updateLearner(req.params.id, data);
  // A new date of birth or age moves a stage that was worked out from the age (and places a
  // learner who had none) at each hub where they're in a class.
  if (("dateOfBirth" in data && data.dateOfBirth !== before.dateOfBirth) || ("statedAge" in data && data.statedAge !== before.statedAge)) {
    await LearnerService.placeByAge(record.id);
  }
  if (password && allowGuardianPassword) {
    if (!record.guardianEmail) {
      const err = new Error("This learner needs a guardian email before a password can be set");
      err.statusCode = 400;
      throw err;
    }
    await AuthService.setOrCreatePassword({ name: record.guardianName, email: record.guardianEmail, password, role: "learner" });
  }
  // Keeps the learner's own dedicated login (if any) attached to their current username when
  // it's renamed — otherwise it'd still work but silently become unreachable under the old one.
  if ("username" in data && before.username && before.username !== data.username) {
    await AuthService.renameUsernameAccount(before.username, data.username || null);
  }
  if (learnerPassword) {
    if (!record.username) {
      const err = new Error("This learner needs a username before a learner-portal password can be set");
      err.statusCode = 400;
      throw err;
    }
    await AuthService.setOrCreatePasswordByUsername({
      name: `${record.firstName} ${record.lastName}`.trim(),
      username: record.username,
      password: learnerPassword,
      role: "learner",
    });
  }
  res.json({ success: true, data: record });
});

const updateLearnerAccountStatus = asyncHandler(async (req, res) => {
  const { accountStatus } = updateLearnerAccountStatusSchema.parse(req.body);
  if (req.user.role === "admin") assertOwn(await isLinkedToOwnHub(req, req.params.id));
  const record = await LearnerService.updateLearner(req.params.id, { accountStatus });
  res.json({ success: true, data: record });
});

// True delete is admin-only (see learner.routes.js) — a "school" losing access to a learner
// shared with another hub must unenroll (DELETE /:id/hubs/links/:hubId), never destroy the
// underlying record, same split as teacher.controller.js. An admin may only delete a learner
// linked to one of their own hubs — same ownership check as every other write here.
const deleteLearner = asyncHandler(async (req, res) => {
  assertOwn(await isLinkedToOwnHub(req, req.params.id));
  if (await UsageService.guardDelete(req, res, "learner", req.params.id, "This learner")) return;
  const result = await LearnerService.deleteLearner(req.params.id);
  res.json({ success: true, ...result });
});

const getLearnerHubs = asyncHandler(async (req, res) => {
  if (req.user.role === "learner") assertOwn(req.params.id === req.ownLearner?.id);
  let hubs = await LearnerService.getLearnerHubs(req.params.id);
  if (req.user.role === "school") {
    assertOwn(await isLinkedToOwnHub(req, req.params.id));
    // A school only ever gets to see its own hub(s) in the list — not the names of
    // any other hub a shared learner also happens to attend.
    hubs = hubs.filter((h) => isOwnHub(req, h.id));
  } else if (req.user.role === "admin") {
    assertOwn(await isLinkedToOwnHub(req, req.params.id));
    // Same narrowing as "school" above, just across every hub this admin owns rather than one.
    const ownHubIds = new Set(await adminOwnedHubIds(req));
    hubs = hubs.filter((h) => ownHubIds.has(h.id));
  } else if (req.user.role === "teacher") {
    assertOwn(await anyEnrollmentTaughtByTeacher(req.params.id, req.ownTeacher?.id));
  }
  res.json({ success: true, data: hubs, count: hubs.length });
});

const enrollLearnerHub = asyncHandler(async (req, res) => {
  const data = enrollLearnerSchema.parse(req.body);
  if (req.user.role === "school") assertOwn(isOwnHub(req, data.hubId));
  if (req.user.role === "admin") {
    // Unlike "school" (which may freely cross-enroll a learner from ANY other hub — the "Add
    // Existing Learner" feature — since every hub still shares one operator), an admin's tenants
    // are meant to be fully independent: enrolling a learner who's exclusively linked to another
    // admin's hub(s) would silently pull them into this admin's tenant. Require both the
    // destination hub AND the learner (if they have any existing links at all) to already be
    // this admin's own.
    const ownHubIds = await adminOwnedHubIds(req);
    assertOwn(ownHubIds.includes(data.hubId));
    const existingLinks = await LearnerHubLinkModel.findByLearnerId(req.params.id);
    assertOwn(existingLinks.length === 0 || existingLinks.some((l) => ownHubIds.includes(l.hubId)));
  }
  const hubs = await LearnerService.enrollInHub(req.params.id, data);
  res.status(201).json({ success: true, data: hubs });
});

const updateLearnerHubLink = asyncHandler(async (req, res) => {
  const data = updateEnrollmentSchema.parse(req.body);
  if (req.user.role === "school") assertOwn(isOwnHub(req, req.params.hubId));
  if (req.user.role === "admin") assertOwn((await adminOwnedHubIds(req)).includes(req.params.hubId));
  const hubs = await LearnerService.updateEnrollment(req.params.id, req.params.hubId, data);
  res.json({ success: true, data: hubs });
});

const unenrollLearnerHub = asyncHandler(async (req, res) => {
  if (req.user.role === "school") assertOwn(isOwnHub(req, req.params.hubId));
  if (req.user.role === "admin") assertOwn((await adminOwnedHubIds(req)).includes(req.params.hubId));
  const hubs = await LearnerService.unenrollFromHub(req.params.id, req.params.hubId);
  res.json({ success: true, data: hubs });
});

// Moves a learner from the hub in the URL (:hubId) to another hub in one action. For "school",
// only the SOURCE hub needs to be the caller's own (see enrollLearnerHub's comment on why —
// cross-hub is allowed there by design). For "admin", BOTH ends must be this admin's own tenant —
// same reasoning as enrollLearnerHub, a transfer is really an unenroll+enroll and must not be
// able to move a learner into or out of another admin's tenant.
const transferLearnerHub = asyncHandler(async (req, res) => {
  const { toHubId, toClassId } = transferHubSchema.parse(req.body);
  if (req.user.role === "school") assertOwn(isOwnHub(req, req.params.hubId));
  if (req.user.role === "admin") {
    const ownHubIds = await adminOwnedHubIds(req);
    assertOwn(ownHubIds.includes(req.params.hubId) && ownHubIds.includes(toHubId));
  }
  const hubs = await LearnerService.transferHub(req.params.id, {
    fromHubId: req.params.hubId, toHubId, toClassId, transferredBy: req.user.id,
  });
  res.json({ success: true, data: hubs });
});

// Learner-portal-only: fired once from the first-login diagnostic gate before it reads this
// learner's Pathway diagnostics, so an enrollment whose issuance was missed/incomplete
// still gets caught before the gate decides there's nothing to show.
const ensureDiagnosticsIssued = asyncHandler(async (req, res) => {
  assertOwn(req.params.id === req.ownLearner?.id);
  const { hubId } = req.body;
  if (!hubId) {
    const err = new Error("hubId is required");
    err.statusCode = 400;
    throw err;
  }
  await LearnerService.ensureDiagnosticsIssued(req.params.id, hubId);
  res.json({ success: true });
});

// Learner-portal-only: fired once the first-login diagnostic gate has nothing left
// outstanding for this hub. Deliberately its own narrow endpoint rather than reusing
// updateLearnerHubLink — that route also allows changing classId/status, which a learner must
// never be able to do to their own enrollment.
const completeHubOnboarding = asyncHandler(async (req, res) => {
  assertOwn(req.params.id === req.ownLearner?.id);
  const hub = await LearnerService.markHubOnboardingComplete(req.params.id, req.params.hubId);
  res.json({ success: true, data: hub });
});

// Get-or-create the "share via QR" token — same ownership scoping as updateLearner (a
// school may only mint a share link for a learner actually linked to a hub they
// own; admin is unrestricted). A "learner" login (guardian-mediated or the learner's own
// dedicated one — either way req.ownLearner resolves to this same record, see
// scope.middleware.js) may only ever mint its own link, mirroring ensureDiagnosticsIssued's
// self-only scoping below. The token itself never appears anywhere but this response and the
// public read below.
const getPublicToken = asyncHandler(async (req, res) => {
  const record = await LearnerService.getLearnerById(req.params.id);
  if (req.user.role === "school" || req.user.role === "admin") {
    assertOwn(await isLinkedToOwnHub(req, record.id));
  } else if (req.user.role === "learner") {
    assertOwn(req.params.id === req.ownLearner?.id);
  }
  const token = await LearnerService.getOrCreatePublicToken(req.params.id);
  res.json({ success: true, data: { token } });
});

// Same scoping as getPublicToken — invalidates whatever's currently printed/shared and hands
// back a fresh one.
const regeneratePublicToken = asyncHandler(async (req, res) => {
  const record = await LearnerService.getLearnerById(req.params.id);
  if (req.user.role === "school" || req.user.role === "admin") {
    assertOwn(await isLinkedToOwnHub(req, record.id));
  } else if (req.user.role === "learner") {
    assertOwn(req.params.id === req.ownLearner?.id);
  }
  const token = await LearnerService.regeneratePublicToken(req.params.id);
  res.json({ success: true, data: { token } });
});

// Unauthenticated — mounted separately in app.js, ahead of the `protect` middleware chain that
// guards every other /api/learners route (see public-profile.routes.js). No req.user, no
// ownership check: the token itself IS the access control.
const getPublicProfile = asyncHandler(async (req, res) => {
  const profile = await LearnerService.getPublicProfile(req.params.token);
  res.json({ success: true, data: profile });
});

module.exports = {
  getLearnerLoginPassword,
  createLearner,
  bulkImportLearners,
  getAllLearners,
  getLearnerById,
  getLearnerParent,
  getLearnerWebsiteDiagnostics,
  linkLearnerWebsiteDiagnostic,
  updateLearner,
  updateLearnerAccountStatus,
  deleteLearner,
  getLearnerHubs,
  enrollLearnerHub,
  updateLearnerHubLink,
  unenrollLearnerHub,
  transferLearnerHub,
  ensureDiagnosticsIssued,
  completeHubOnboarding,
  getPublicToken,
  regeneratePublicToken,
  getPublicProfile,
};
