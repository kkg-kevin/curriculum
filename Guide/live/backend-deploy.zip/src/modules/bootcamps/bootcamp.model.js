const db = require("../../config/db");
const {
  createRecord,
  updateRecord,
  deleteRecord,
  firstOrNull,
  stringifyJsonFields,
} = require("../../shared/utils/model.utils");

const TABLE = "bootcamps";
// `highlights`/`coursePricing`/`priceNotes`/`pathwayIds`/`gameIds`/`images` are stored as JSON
// columns — mysql2 auto-parses them back on read, but doesn't auto-serialize a raw JS array on
// write (see CLAUDE.md), so they go through stringifyJsonFields.
const JSON_FIELDS = ["highlights", "coursePricing", "priceNotes", "pathwayIds", "gameIds", "images"];

const BootcampModel = {
  create(data) {
    return createRecord(db, TABLE, stringifyJsonFields(data, JSON_FIELDS));
  },

  // ownerAdminId optional here so the same findAll can serve callers that scope a different
  // way (none yet — but matches the pattern in curriculum/learning-hub models). Admin-facing
  // controllers always pass it.
  findAll({ ownerAdminId, curriculumId, saleStatus, audience } = {}) {
    let query = db(TABLE);
    if (audience) query = query.where({ audience });
    if (ownerAdminId) query = query.where({ ownerAdminId });
    if (curriculumId) query = query.where({ curriculumId });
    if (saleStatus) query = query.where({ saleStatus });
    return query.orderBy("createdAt", "desc");
  },

  findById(id) {
    return firstOrNull(db(TABLE).where({ id }));
  },

  // Every run of one bootcamp ("Schedule another run" — they share the first run's id as seriesId).
  findSeries(seriesId) {
    return db(TABLE).where({ seriesId }).orderBy("startDate", "asc");
  },

  // The designated public-content admin's bootcamps marked for sale — the one query the public
  // /api/public/bootcamps endpoint runs. `ownerAdminId` required (a missing scope would leak
  // every tenant's bootcamps), mirroring CompetitionModel.findPublic.
  findPublic(ownerAdminId) {
    if (!ownerAdminId) throw new Error("findPublic requires an ownerAdminId");
    return db(TABLE)
      .where({ ownerAdminId, saleStatus: "for_sale" })
      .orderBy("createdAt", "desc");
  },

  update(id, data) {
    return updateRecord(db, TABLE, id, stringifyJsonFields(data, JSON_FIELDS));
  },

  delete(id) {
    return deleteRecord(db, TABLE, id);
  },
};

module.exports = BootcampModel;
