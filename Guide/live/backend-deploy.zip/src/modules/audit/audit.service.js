const db = require("../../config/db");
const env = require("../../config/env");
const AuditLogModel = require("./audit-log.model");
const { resolve, shouldSkip, UUID } = require("./audit.resolver");
const { diffRecords } = require("./audit.diff");

// The activity log: who did what, to which record, when, and whether it went through.
//
//   capture()     what the audit middleware calls for every change-making request. It reads the
//                 record before the handler runs, and afterwards writes one entry describing what
//                 happened — including what changed, field by field.
//   recordAuth()  sign-in events, which aren't about a record (auth.controller.js).
//   list()/…      what the Activity page reads.
//
// Nothing here may ever break or slow the request it is describing: every write is best-effort,
// happens after the response has gone, and swallows its own errors.

const RETENTION_DAYS = 730; // two years
const PRUNE_EVERY_MS = 24 * 60 * 60 * 1000;
let lastPruneAt = 0;

const clip = (value, max) => (value == null ? null : String(value).slice(0, max));
const capitalise = (text) => (text ? text[0].toUpperCase() + text.slice(1) : text);

// What a record is called, for a person reading the log.
function labelOf(row) {
  if (!row) return null;
  const person = [row.firstName, row.lastName].filter(Boolean).join(" ").trim();
  const label =
    row.name || row.title || person || row.invoiceNumber || row.batchNumber || row.certificateNumber || row.orderNumber ||
    row.pathwayName || row.guardianName || row.customerName || row.label ||
    // A booking or a meeting: what it's about and when.
    (row.date && row.startTime ? [row.sessionTitle || row.courseName, `${String(row.date).slice(0, 10)} ${row.startTime}`].filter(Boolean).join(" · ") : null) ||
    [row.gradeName, row.streamName].filter(Boolean).join(" ").trim() || row.email || row.username || null;
  return label ? clip(label, 255) : null;
}

async function loadRow(table, id) {
  if (!table || !id) return null;
  try {
    return (await db(table).where({ id }).first()) || null;
  } catch {
    return null;
  }
}

// Which table an id column points at, so a changed "curriculumId" can be shown by name.
const REFERENCES = {
  curriculumId: "curricula", hubId: "learning_hubs", schoolId: "learning_hubs", parentHubId: "learning_hubs", teacherId: "teachers",
  classTeacherId: "teachers", educatorId: "teachers", classId: "classes", courseId: "courses", learnerId: "learners", roleId: "access_roles",
  assessmentId: "assessments", diagnosticAssessmentId: "assessments", pathwayId: "pathways", ageCategoryId: "age_categories",
  packageId: "home_learning_packages", roomId: "rooms", moduleId: "course_modules",
};

async function resolveNames(before, after) {
  const names = new Map();
  for (const [column, table] of Object.entries(REFERENCES)) {
    for (const id of new Set([before?.[column], after?.[column]].filter((v) => typeof v === "string" && UUID.test(v)))) {
      if (before?.[column] === after?.[column]) continue;
      names.set(`${column}:${id}`, labelOf(await loadRow(table, id)));
    }
  }
  return (column, id) => names.get(`${column}:${id}`) || null;
}

// The workspace (admin) an account's actions belong to. Admins and staff are direct; a hub,
// educator or learner login belongs to the admin who owns the hub they're attached to. Cached
// briefly — it is asked on every change such an account makes.
const workspaceCache = new Map();
async function workspaceOf(req) {
  if (req.ownerAdminId) return req.ownerAdminId;
  const user = req.user;
  if (!user) return null;
  const role = user.actualRole || user.role;
  if (role === "admin") return user.organisationId || user.id;
  if (role === "collaborator" || role === "supervisor") return user.invitedByAdminId || null;
  const cacheKey = `${user.id}:${role}`;
  const cached = workspaceCache.get(cacheKey);
  if (cached && cached.at > Date.now() - 10 * 60 * 1000) return cached.ownerAdminId;

  let ownerAdminId = null;
  try {
    if (role === "school") ownerAdminId = req.ownSchool?.ownerAdminId || (await db("learning_hubs").whereRaw("LOWER(email) = ?", [String(user.email || "").toLowerCase()]).first())?.ownerAdminId || null;
    else if (role === "teacher") {
      const teacher = req.ownTeacher || (await db("teachers").whereRaw("LOWER(email) = ?", [String(user.email || "").toLowerCase()]).first());
      ownerAdminId = teacher?.createdByAdminId || null;
      if (!ownerAdminId && teacher) {
        const hub = await db("teacher_hub_links").join("learning_hubs", "learning_hubs.id", "teacher_hub_links.hubId").where("teacher_hub_links.teacherId", teacher.id).select("learning_hubs.ownerAdminId").first();
        ownerAdminId = hub?.ownerAdminId || null;
      }
    } else if (role === "learner") {
      const learner = req.ownLearner
        || (user.username ? await db("learners").whereRaw("LOWER(username) = ?", [user.username.toLowerCase()]).first() : await db("learners").whereRaw("LOWER(guardianEmail) = ?", [String(user.email || "").toLowerCase()]).first());
      ownerAdminId = learner?.createdByAdminId || null;
      if (!ownerAdminId && learner) {
        const hub = await db("learner_hub_links").join("learning_hubs", "learning_hubs.id", "learner_hub_links.hubId").where("learner_hub_links.learnerId", learner.id).select("learning_hubs.ownerAdminId").first();
        ownerAdminId = hub?.ownerAdminId || null;
      }
    } else if (role === "curriculumAdmin") {
      ownerAdminId = (await db("curricula").where({ curriculumAdminId: user.id }).first())?.ownerAdminId || null;
    }
  } catch {
    ownerAdminId = null;
  }
  workspaceCache.set(cacheKey, { ownerAdminId, at: Date.now() });
  return ownerAdminId;
}

// Who is acting, as they are now. A staff member's request runs as "admin" (scope.middleware.js);
// the log wants the real account and, for staff, the name of their role.
async function actorOf(user) {
  if (!user) return { actorUserId: null, actorName: "Website visitor", actorEmail: null, actorRole: "visitor", actorAccessRole: null };
  let account = null;
  let accessRole = null;
  try {
    account = await db("users").where({ id: user.id }).select("name", "email", "username", "role", "roleId").first();
    if ((user.actualRole || user.role) === "collaborator" && account?.roleId) accessRole = (await db("access_roles").where({ id: account.roleId }).select("name").first())?.name || null;
  } catch {
    account = null;
  }
  return {
    actorUserId: user.id,
    actorName: clip(account?.name || user.email || user.username || "Unknown", 150),
    actorEmail: clip(account?.email || user.email || account?.username || user.username, 190),
    actorRole: user.actualRole || user.role || account?.role || null,
    actorAccessRole: clip(accessRole, 100),
  };
}

const quote = (label) => (label ? ` “${label}”` : "");

// One line a person can read: "Edited bootcamp “Robot Builders”".
function summarise({ ctx, label, parentLabel, linkedLabel, body, requestBody }) {
  const { action, entity, parent, linked, collection, rootNoun } = ctx;
  // Adding to a collection ("…/courses/<id>/sessions"): the new thing is what's named, and the
  // record the path stopped at is where it was added.
  const adding = action === "create" && collection;
  const noun = (adding ? collection : entity || collection)?.noun || rootNoun;
  const within = adding && entity ? entity : parent;
  const inParent = within && parentLabel ? ` in ${within.noun}${quote(parentLabel)}` : "";

  // A few requests read better said plainly than derived from their address.
  const path = ctx.path;
  if (path === "/api/auth/me") return "Updated their own profile";
  if (path === "/api/auth/change-password") return "Changed their own password";
  if (/^\/api\/parent\/children\/[^/]+\/login$/.test(path)) return `Set their child's login${body?.data?.username ? ` (${body.data.username})` : ""}`;
  if (path === "/api/admin-tools/reassign-owner") return `Moved a ${requestBody?.entityType || "record"}${quote(label)} to another admin${requestBody?.targetAdminEmail ? ` (${requestBody.targetAdminEmail})` : ""}`;
  if (/^\/api\/sharing\/connections\/[^/]+\/copy$/.test(path)) return `Copied ${body?.data?.label || requestBody?.kind || "content"} from another admin${body?.data?.alsoCreated?.length ? `, with ${body.data.alsoCreated.join(", ")}` : ""}`;
  if (/^\/api\/sharing\/connections\/[^/]+\/accept$/.test(path)) return `Accepted a sharing request${body?.data?.admin?.name ? ` from ${body.data.admin.name}` : ""}`;
  if (path === "/api/sharing/connections" && action === "create") return `Sent a sharing request${body?.data?.admin?.email ? ` to ${body.data.admin.email}` : ""}`;
  if (path === "/api/attendance/mark") return "Marked attendance";
  // General events, from the sign-in pop-up (modules/general-events/).
  if (/^\/api\/my-events\/[^/]+\/hide$/.test(path)) return "Put off an event's pop-up (not now)";
  if (/^\/api\/my-events\/[^/]+\/register$/.test(path)) return `Registered for an event${body?.data?.registration?.partySize > 1 ? ` (${body.data.registration.partySize} people)` : ""}`;
  if (/^\/api\/my-events\/registrations\/[^/]+\/details$/.test(path)) return "Told us about themselves for an event";
  if (/^\/api\/my-events\/registrations\/[^/]+\/cancel$/.test(path)) return "Cancelled their event registration";
  if (path === "/api/email-settings") {
    const named = (on) => Object.entries(requestBody?.types || {}).filter(([, value]) => value === on).map(([type]) => type.replace(/_/g, " ")).join(", ");
    return `Changed which emails the workspace sends${named(false) ? ` — switched off: ${named(false)}` : ""}${named(true) ? ` — switched on: ${named(true)}` : ""}`;
  }
  if (ctx.root === "public") return `Website: ${ctx.words.join(" ") || "form"} submitted${quote(label)}`;

  if (action === "link") return `Added ${linked.noun}${quote(linkedLabel)} to ${noun}${quote(label)}`;
  if (action === "unlink") return `Removed ${linked.noun}${quote(linkedLabel)} from ${noun}${quote(label)}`;
  if (action === "create") return `Added ${noun}${quote(label)}${inParent}`;
  if (action === "delete") return `Deleted ${noun}${quote(label)}${inParent}`;
  if (action === "update") return `Edited ${noun}${quote(label)}${ctx.words.length ? ` (${ctx.words.join(" ")})` : ""}${inParent}`;
  return `${capitalise(action)}: ${noun}${quote(label)}${inParent}`;
}

// Something that was refused or broke didn't happen — say what was attempted, not that it was done.
const ATTEMPT = { Added: "add", Edited: "edit", Deleted: "delete", Removed: "remove", Copied: "copy", Moved: "move", Marked: "mark", Updated: "update", Changed: "change", Sent: "send", Accepted: "accept" };
function asAttempt(summary) {
  const [first, ...rest] = summary.split(" ");
  return ATTEMPT[first] ? `Tried to ${ATTEMPT[first]} ${rest.join(" ")}` : `Tried: ${summary}`;
}

const MUTATING = new Set(["POST", "PUT", "PATCH", "DELETE"]);

// The address a request came from, for the log. With TRUST_PROXY set, req.ip already is the
// visitor's address (Express reads only the hops it's told to trust). Without it, the LAST entry
// of X-Forwarded-For is the one our own web server added; the first one (used before 13 Nov 2026)
// is whatever the visitor's browser chose to send, so anyone could write any address there.
function clientOf(req) {
  const trust = typeof req.app?.get === "function" ? req.app.get("trust proxy") : false;
  const hops = String(req.headers?.["x-forwarded-for"] || "").split(",").map((h) => h.trim()).filter(Boolean);
  const address = (trust ? req.ip : hops[hops.length - 1]) || req.ip || req.socket?.remoteAddress || null;
  // "::ffff:41.90.x.x" is just how an IPv4 address looks on a dual-stack socket.
  return { ip: clip(address ? String(address).replace(/^::ffff:/, "") : null, 64), userAgent: clip(req.headers?.["user-agent"] || null, 255) };
}

async function write(entry) {
  try {
    await AuditLogModel.create(entry);
    if (Date.now() - lastPruneAt > PRUNE_EVERY_MS) {
      lastPruneAt = Date.now();
      await AuditLogModel.prune(new Date(Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000));
    }
  } catch (err) {
    console.error("[audit] could not record:", err.message);
  }
}

const AuditService = {
  RETENTION_DAYS,

  // Before the handler runs: note what is about to be touched, as it is now. Returns the context
  // finish() needs, or null when this request isn't one the log covers.
  async begin(req) {
    if (!MUTATING.has(req.method)) return null;
    const path = String(req.originalUrl || "").split("?")[0];
    if (shouldSkip(path)) return null;
    const ctx = resolve(req.method, path);
    if (!ctx) return null;
    ctx.path = path.toLowerCase().replace(/\/+$/, "");
    const before = ctx.entity ? await loadRow(ctx.entity.table, ctx.entity.id) : null;
    return { ctx, before };
  },

  // After the response has gone: write the entry. `body` is what the handler answered with.
  async finish(req, res, started, body) {
    if (!started) return;
    // A delete dialog asking "is this in use?" (?check — modules/usage) changed nothing.
    if (req.usageCheckOnly) return;
    const status = res.statusCode;
    // Only what happened (2xx), what was refused (403), and what broke (5xx). A form sent back
    // for a typo, or a record that wasn't found, changed nothing and says nothing about anyone.
    const outcome = status < 300 ? "success" : status === 403 ? "refused" : status >= 500 ? "failed" : null;
    if (!outcome) return;
    const { ctx, before } = started;
    // Anonymous requests are only of interest on the public website routes.
    if (!req.user && ctx.root !== "public") return;

    try {
      const data = body && typeof body === "object" ? body.data : null;
      const created = ctx.action === "create" && data && !Array.isArray(data) && typeof data === "object" ? data : null;
      // Something added to a collection is the record this entry is about — not the one it was added to.
      const adding = ctx.action === "create" && ctx.collection;
      const entityId = adding ? (typeof created?.id === "string" ? created.id : null) : ctx.entity?.id || null;
      const table = (adding ? ctx.collection : ctx.entity || ctx.collection)?.table || null;

      // Still there after the request? Then what it looks like now (for the diff, and its name).
      const after = outcome === "success" && ctx.action !== "delete" && ctx.entity ? await loadRow(ctx.entity.table, ctx.entity.id) : null;
      const label = adding ? labelOf(created) : labelOf(after) || labelOf(before) || labelOf(created);
      const container = adding && ctx.entity ? ctx.entity : ctx.parent;
      const parentLabel = container ? labelOf(container === ctx.entity ? before : await loadRow(container.table, container.id)) : null;
      const linkedId = ctx.linked ? ctx.linked.id || req.body?.[ctx.linked.bodyKey] : null;
      const linkedLabel = ctx.linked ? labelOf(await loadRow(ctx.linked.table, linkedId)) : null;

      const changes = outcome === "success" && !adding && before && after ? diffRecords(before, after, await resolveNames(before, after)) : [];
      const ownerAdminId = (await workspaceOf(req)) || (ctx.root === "public" ? env.PUBLIC_CONTENT_ADMIN_ID || null : null)
        || before?.ownerAdminId || null;

      const summary = summarise({ ctx, label, parentLabel, linkedLabel, body, requestBody: req.body });
      await write({
        ownerAdminId,
        ...(await actorOf(req.user)),
        action: clip(ctx.action, 40),
        module: ctx.module,
        entityType: table,
        entityId,
        entityLabel: label,
        summary: clip(outcome === "success" ? summary : asAttempt(summary), 500),
        changes: changes.length ? changes : null,
        outcome,
        statusCode: status,
        reason: outcome === "success" ? null : clip(res.locals?.auditReason || body?.message, 300),
        method: req.method,
        path: clip(ctx.path, 255),
        ...clientOf(req),
      });
      // A copy (a course, a curriculum… duplicated) is a new record too: its own "created" entry, so
      // its stamp says who made it (modules/activity's RecordStamp — 12 Nov 2026).
      const copy = ctx.action === "duplicate" && outcome === "success" && ctx.entity && data && typeof data.id === "string" && data.id !== ctx.entity.id ? data : null;
      if (copy) {
        await write({
          ownerAdminId,
          ...(await actorOf(req.user)),
          action: "create",
          module: ctx.module,
          entityType: ctx.entity.table,
          entityId: copy.id,
          entityLabel: labelOf(copy),
          summary: clip(`Made “${labelOf(copy) || "a copy"}” as a copy of “${label || "the original"}”`, 500),
          changes: null,
          outcome,
          statusCode: status,
          reason: null,
          method: req.method,
          path: clip(ctx.path, 255),
          ...clientOf(req),
        });
      }
    } catch (err) {
      console.error("[audit] could not record:", err.message);
    }
  },

  // Sign-in events. `user` is the account (when there is one); `identifier` what was typed.
  //   event: login | login_failed | logout | password_changed | password_reset | password_reset_requested | session_expired
  async recordAuth(req, event, { user = null, identifier = null, reason = null } = {}) {
    try {
      // Always the stored account — callers may only have its id.
      const account = user?.id
        ? await db("users").where({ id: user.id }).first()
        : identifier ? await db("users").whereRaw("LOWER(email) = ? OR LOWER(username) = ?", [String(identifier).toLowerCase(), String(identifier).toLowerCase()]).first() : null;
      const who = account ? await actorOf(account) : { actorUserId: null, actorName: clip(identifier || "Unknown", 150), actorEmail: clip(identifier, 190), actorRole: null, actorAccessRole: null };
      const failed = event === "login_failed";
      const SUMMARIES = {
        login: "Signed in",
        login_failed: `Failed sign-in attempt${identifier ? ` as ${identifier}` : ""}`,
        logout: "Signed out",
        password_changed: "Changed their password",
        password_reset: "Reset their password from an emailed link",
        session_expired: "Signed out after inactivity",
        role_switched: `Switched to their ${reason === "teacher" ? "educator" : reason === "school" ? "learning hub" : reason === "learner" ? "parent" : reason || "other"} role`,
      };
      await write({
        ownerAdminId: account ? await workspaceOf({ user: account }) : null,
        ...who,
        action: event,
        module: "account",
        entityType: account ? "users" : null,
        entityId: account?.id || null,
        entityLabel: account ? clip(account.name || account.email || account.username, 255) : null,
        summary: SUMMARIES[event] || event,
        changes: null,
        outcome: failed ? "refused" : "success",
        statusCode: failed ? 401 : 200,
        reason: clip(reason, 300),
        method: req?.method || null,
        path: req ? clip(String(req.originalUrl || "").split("?")[0], 255) : null,
        ...(req ? clientOf(req) : { ip: null, userAgent: null }),
      });
    } catch (err) {
      console.error("[audit] could not record:", err.message);
    }
  },

  // A look at something sensitive that isn't a change — staff showing a child's login password.
  // Recorded like a change (who, which record, from where) so the Activity page shows it.
  async recordViewed(req, { module, entityType, entityId, entityLabel, summary }) {
    try {
      await write({
        ownerAdminId: await workspaceOf(req),
        ...(await actorOf(req.user)),
        action: "viewed",
        module,
        entityType,
        entityId,
        entityLabel: clip(entityLabel, 255),
        summary: clip(summary, 500),
        changes: null,
        outcome: "success",
        statusCode: 200,
        reason: null,
        method: req.method,
        path: clip(String(req.originalUrl || "").split("?")[0], 255),
        ...clientOf(req),
      });
    } catch (err) {
      console.error("[audit] could not record:", err.message);
    }
  },

  // ── What the Activity page reads ──────────────────────────────────────────────────────────

  async list(ownerAdminId, filters = {}, { page = 1, pageSize = 50 } = {}) {
    const limit = Math.min(Math.max(Number(pageSize) || 50, 1), 200);
    const offset = (Math.max(Number(page) || 1, 1) - 1) * limit;
    const rows = await AuditLogModel.find({ ...filters, ownerAdminId }, { limit, offset });
    return { items: rows.slice(0, limit), hasMore: rows.length > limit, page: Math.max(Number(page) || 1, 1) };
  },

  // A record's "Created by · Last changed by" stamp (its parts' changes included). `recordCreatedAt`
  // is the record's own date, so a record made before the log began (2 Oct 2026) can say so.
  async stamp(ownerAdminId, recordType, recordId) {
    if (!AuditLogModel.RECORDS[recordType]) throw Object.assign(new Error("Unknown record"), { statusCode: 400 });
    const row = await require("../../config/db")(recordType).where({ id: recordId }).first().catch(() => null);
    if (!row) throw Object.assign(new Error("Not found"), { statusCode: 404 });
    const stamp = await AuditLogModel.stamp(ownerAdminId, recordType, recordId);
    return { ...stamp, recordCreatedAt: row.createdAt || null, recordUpdatedAt: row.updatedAt || null };
  },

  // { all, signins, added, edited, deleted, problems } — the numbers on the Activity page's tabs.
  counts(ownerAdminId, filters = {}) {
    return AuditLogModel.countByView({ ...filters, ownerAdminId });
  },

  async facets(ownerAdminId) {
    const [actors, modules] = await Promise.all([AuditLogModel.actors(ownerAdminId), AuditLogModel.modules(ownerAdminId)]);
    return {
      actors: actors.map((a) => ({ id: a.actorUserId, name: a.actorName, email: a.actorEmail, role: a.actorRole, lastActiveAt: a.lastActiveAt, entries: Number(a.entries) })),
      modules: modules.sort(),
      retentionDays: RETENTION_DAYS,
    };
  },

  // Up to 10,000 rows for a spreadsheet, same filters as the page.
  async exportRows(ownerAdminId, filters = {}) {
    const rows = await AuditLogModel.find({ ...filters, ownerAdminId }, { limit: 10000, offset: 0 });
    return rows.slice(0, 10000);
  },
};

module.exports = AuditService;
module.exports._internal = { clientOf };
