const CurriculumModel        = require("../curriculum.model");
const CurriculumCompetencyLinkModel = require("./curriculum-competency-link.model");
const CurriculumCompetencyIndicatorModel = require("./curriculum-competency-indicator.model");
const PathwayModel      = require("./pathway.model");
const PathwayTemplateModel = require("../../settings/pathways/pathway-template.model");
const CourseModel            = require("../../courses/course.model");
const CompetencyModel        = require("../../settings/competencies/competency.model");
const ProgressionLadderModel = require("./progression-ladder.model");
const AgeCategoryModel       = require("./age-category.model");
const ProgressLevelModel     = require("./progress-level.model");
const AssessmentTypeModel    = require("./assessment-type.model");
const EvidenceTypeModel      = require("./evidence-type.model");
const PerformanceBandModel   = require("./performance-band.model");
const { runAssessmentEngine, runCompetencyEngine, runProgressArcEngine, runIndicatorProgressEngine } = require("./scoring-engines");
const IndicatorAchievementModel = require("./indicator-achievement.model");
const SessionModel                   = require("../../courses/session.model");
const { getSessionAssessmentIds } = require("../../courses/sessionAssessment.utils");
const CourseCurriculumLinkModel      = require("../../courses/course-curriculum-link.model");
const BuilderAssessmentModel         = require("../../assessments/assessment.model");
const { requiresManualGrading }      = require("../../assessments/submissions/grading.utils");
const AssessmentCompetencyLinkModel  = require("../../assessments/assessment-competency-link.model");
const CurriculumVersionModel         = require("../versions/curriculum-versions.model");
const LearnerPathwayModel            = require("./learner-pathway.model");
const LearnerModel                   = require("../../learners/learner.model");
const LearnerHubLinkModel            = require("../../learners/learner-hub-link.model");
const ClassModel                     = require("../../classes/class.model");
const CoursePathwayLinkModel         = require("../../courses/course-pathway-link.model");
const AssessmentPathwayLinkModel     = require("../../assessments/assessment-pathway-link.model");
// Required lazily (inside the functions that use it, not here) — assessment-submission.service.js
// already requires this file back (for diagnostic placement), and capturing a top-level reference
// to it here would risk resolving to a stale/incomplete export depending on which module happens
// to load first at server startup.

// A Pathway's `courses` field stores course ids only — reject anything
// that doesn't resolve to a real course so a dummy id can never sneak in.
async function assertCoursesExist(courseIds) {
  if (!courseIds) return;
  const found = await Promise.all(courseIds.map((id) => CourseModel.findById(id)));
  const missing = courseIds.filter((id, i) => !found[i]);
  if (missing.length > 0) {
    const err = new Error(`Course(s) not found: ${missing.join(", ")}`);
    err.statusCode = 404;
    throw err;
  }
}

// A Pathway's ageCategoryId must resolve to a real Developmental Stage belonging to THIS
// curriculum — same cross-tenant/cross-curriculum guard every other FK on this record already
// gets (assertCoursesExist above, assertPublicDiagnosticAllowed below).
async function assertStageExists(curriculumId, ageCategoryId) {
  if (ageCategoryId == null) return;
  const stage = await AgeCategoryModel.findById(ageCategoryId);
  if (!stage || stage.curriculumId !== curriculumId) {
    const err = new Error("Developmental Stage not found");
    err.statusCode = 404;
    throw err;
  }
}

function samePathwayName(a, b) {
  return (a || "").trim().toLowerCase() === (b || "").trim().toLowerCase();
}

// The workspace's pathway catalogue (pathway_templates — what courses and assessments are tagged
// with, and the "not in use" list in Settings → Pathways) follows its curricula: a pathway a
// curriculum starts using gets an entry if none has its name, and a renamed pathway takes its
// entry (and so the tags on it) to the new name once no curriculum uses the old name. Best-effort
// — never fails the curriculum change.
async function syncCatalogue(curriculumId, { name, description = "", color = null, previousName = null }) {
  try {
    const curriculum = await CurriculumModel.findById(curriculumId);
    const ownerAdminId = curriculum?.ownerAdminId;
    if (!ownerAdminId || !String(name || "").trim()) return;
    const entries = await PathwayTemplateModel.findAll({ ownerAdminId });
    if (entries.some((e) => samePathwayName(e.name, name))) return;
    const old = previousName ? entries.find((e) => samePathwayName(e.name, previousName)) : null;
    if (old) {
      const curricula = await CurriculumModel.findAll({ ownerAdminId });
      const stillUsed = (await Promise.all(curricula.map((c) => PathwayModel.findByCurriculumId(c.id)))).flat()
        .some((p) => samePathwayName(p.name, previousName));
      if (!stillUsed) {
        await PathwayTemplateModel.update(old.id, { name: String(name).trim() });
        return;
      }
    }
    await PathwayTemplateModel.create({ name: String(name).trim(), description: description || "", color: color || "#25476a", courses: [], ownerAdminId });
  } catch (err) {
    console.error("[pathways] could not update the pathway catalogue:", err.message);
  }
}

function fail(statusCode, message) {
  const err = new Error(message);
  err.statusCode = statusCode;
  throw err;
}

const DEFAULT_RUNGS = [
  { label: "Early Childhood",  ageRange: "3–5",   order: 1 },
  { label: "Lower Primary",    ageRange: "6–8",   order: 2 },
  { label: "Upper Primary",    ageRange: "9–11",  order: 3 },
  { label: "Lower Secondary",  ageRange: "12–14", order: 4 },
  { label: "Upper Secondary",  ageRange: "15–18", order: 5 },
];


// A pathway stage has two diagnostics: the learner diagnostic (diagnosticAssessmentId — issued
// once a learner is enrolled, any type) and the website diagnostic (publicDiagnosticAssessmentId —
// taken by visitors with no teacher, so auto-graded only). The website one is offered exactly when
// it is set; publicDiagnosticEnabled is kept in step for everything that reads it.
function syncWebsiteDiagnostic(data) {
  if ("publicDiagnosticAssessmentId" in data) data.publicDiagnosticEnabled = !!data.publicDiagnosticAssessmentId;
  else if ("publicDiagnosticEnabled" in data && !data.publicDiagnosticEnabled) data.publicDiagnosticAssessmentId = null;
}
const CompetencyService = {
  /* ── Curriculum ↔ Competency links ───────────────────────────────────
   * Competencies are now authored globally (see server/src/modules/competencies).
   * A curriculum no longer owns competency records — it just adopts entries
   * from the shared catalog. */

  async getCurriculumCompetencies(curriculumId) {
    const links = await CurriculumCompetencyLinkModel.findByCurriculumId(curriculumId);
    const comps = await CompetencyModel.findByIds(links.map((l) => l.competencyId));
    const linksByCompetencyId = new Map(links.map((l) => [l.competencyId, l]));
    return comps.map((c) => {
      const link = linksByCompetencyId.get(c.id);
      return {
        ...c,
        minimumThreshold: link?.minimumThreshold ?? 60,
      };
    });
  },

  async linkCompetency(curriculumId, competencyId) {
    const comp = await CompetencyModel.findById(competencyId);
    if (!comp) {
      const err = new Error("Competency not found");
      err.statusCode = 404;
      throw err;
    }
    await CurriculumCompetencyLinkModel.link(curriculumId, competencyId);
    return this.getCurriculumCompetencies(curriculumId);
  },

  async unlinkCompetency(curriculumId, competencyId) {
    await CurriculumCompetencyLinkModel.unlink(curriculumId, competencyId);
    await CurriculumCompetencyIndicatorModel.deleteByLink(curriculumId, competencyId);
    await IndicatorAchievementModel.deleteByLink(curriculumId, competencyId);
    // This curriculum no longer uses the competency — drop it from this curriculum's
    // own progression ladder too (other curricula's ladders are untouched).
    const rungs = await ProgressionLadderModel.findByCurriculumId(curriculumId);
    await Promise.all(rungs.map((rung) => {
      const filtered = (rung.assignments || []).filter((a) => a.competencyId !== competencyId);
      if (filtered.length !== (rung.assignments || []).length) {
        return ProgressionLadderModel.update(rung.id, { assignments: filtered });
      }
      return null;
    }));
    return this.getCurriculumCompetencies(curriculumId);
  },

  async updateCompetencyLink(curriculumId, competencyId, data) {
    const link = await CurriculumCompetencyLinkModel.updateLink(curriculumId, competencyId, data);
    if (!link) {
      const err = new Error("This curriculum hasn't adopted that competency yet");
      err.statusCode = 404;
      throw err;
    }
    return this.getCurriculumCompetencies(curriculumId);
  },

  /* ── Competency Indicators (how THIS curriculum evaluates an adopted competency) ── */

  async getCompetencyIndicators(curriculumId, competencyId) {
    if (!(await CurriculumCompetencyLinkModel.findOne(curriculumId, competencyId))) {
      const err = new Error("This curriculum hasn't adopted that competency yet");
      err.statusCode = 404;
      throw err;
    }
    const existing = await CurriculumCompetencyIndicatorModel.findByLink(curriculumId, competencyId);
    if (existing.length > 0) return existing;

    // First time this curriculum's indicators are viewed for this competency — seed them
    // from the global competency's base indicators (Settings), split evenly to 100% as a
    // starting point. From here they're this curriculum's own copies: editing, reweighting,
    // adding, or deleting them never touches the global catalog.
    const competency = await CompetencyModel.findById(competencyId);
    const globalIndicators = competency?.indicators || [];
    if (globalIndicators.length === 0) return [];

    const evenWeight = Math.floor(100 / globalIndicators.length);
    const remainder  = 100 - evenWeight * globalIndicators.length;
    return Promise.all(globalIndicators.map((gi, idx) =>
      CurriculumCompetencyIndicatorModel.create({
        curriculumId,
        competencyId,
        name:        gi.name,
        description: gi.description || "",
        weight:      evenWeight + (idx === globalIndicators.length - 1 ? remainder : 0),
      })
    ));
  },

  async createCompetencyIndicator(curriculumId, competencyId, data) {
    if (!(await CurriculumCompetencyLinkModel.findOne(curriculumId, competencyId))) {
      const err = new Error("This curriculum hasn't adopted that competency yet");
      err.statusCode = 404;
      throw err;
    }
    return CurriculumCompetencyIndicatorModel.create({ curriculumId, competencyId, ...data });
  },

  async updateCompetencyIndicator(curriculumId, competencyId, id, data) {
    const indicator = await CurriculumCompetencyIndicatorModel.findById(id);
    if (!indicator || indicator.curriculumId !== curriculumId || indicator.competencyId !== competencyId) {
      const err = new Error("Indicator not found");
      err.statusCode = 404;
      throw err;
    }
    return CurriculumCompetencyIndicatorModel.update(id, data);
  },

  async deleteCompetencyIndicator(curriculumId, competencyId, id) {
    const indicator = await CurriculumCompetencyIndicatorModel.findById(id);
    if (!indicator || indicator.curriculumId !== curriculumId || indicator.competencyId !== competencyId) {
      const err = new Error("Indicator not found");
      err.statusCode = 404;
      throw err;
    }
    await CurriculumCompetencyIndicatorModel.delete(id);
  },

  /* ── Pathways ─────────────────────────────────────────────────── */

  async getPathways(curriculumId) {
    return PathwayModel.findByCurriculumId(curriculumId);
  },

  // publicDiagnosticEnabled can only be true if the EFFECTIVE diagnosticAssessmentId (the
  // incoming value if this request sets one, else whatever the pathway already has) resolves to
  // an assessment that's fully auto-gradable — a public website visitor has no teacher
  // relationship to route a manually-graded attempt to. Checked here (service layer), not in
  // competency.validation.js's Zod schema, because an update payload can legitimately omit
  // diagnosticAssessmentId while still flipping publicDiagnosticEnabled on (e.g. a dedicated
  // toggle UI touching only that one field) — only the service layer has both the existing row
  // and the incoming patch to resolve the effective value from.
  async assertPublicDiagnosticAllowed(data, existingPathway) {
    if (!data.publicDiagnosticEnabled) return;
    // The public assessment wins when set (existing-or-incoming), falling back to the internal
    // one — same "effective id" resolution every public-site resolver mirrors (see
    // public-diagnostic.service.js's loadOfferableAssessment and its two sibling copies).
    const effectiveAssessmentId =
      "publicDiagnosticAssessmentId" in data ? data.publicDiagnosticAssessmentId : existingPathway?.publicDiagnosticAssessmentId;
    if (!effectiveAssessmentId) {
      const err = new Error("Choose the website diagnostic assessment first");
      err.statusCode = 400;
      throw err;
    }
    const assessment = await BuilderAssessmentModel.findById(effectiveAssessmentId);
    if (!assessment) {
      const err = new Error("Diagnostic assessment not found");
      err.statusCode = 404;
      throw err;
    }
    if (requiresManualGrading(assessment)) {
      const err = new Error("The website diagnostic must be marked automatically — this assessment has questions a teacher marks");
      err.statusCode = 400;
      throw err;
    }
  },

  // A pathway spans Developmental Stages: each row is ONE pathway in ONE stage (its own courses,
  // course ladder and diagnostic — everything downstream still works per row), and the rows that
  // share a name within a curriculum are the same pathway. So a name may repeat, but only once
  // per stage; name/description/color are shared and kept identical across the rows. A row with
  // no stage is the pathway's "not placed yet" holder (older pathways, or a brand-new one).
  async createPathway(curriculumId, data) {
    const existing = await PathwayModel.findByCurriculumId(curriculumId);
    const group = existing.filter((a) => samePathwayName(a.name, data.name));
    const stageId = data.ageCategoryId || null;
    if (group.some((a) => (a.ageCategoryId || null) === stageId)) {
      const err = new Error(
        stageId ? "This pathway is already set up for that developmental stage" : "A pathway with this name already exists"
      );
      err.statusCode = 409;
      throw err;
    }
    await assertCoursesExist(data.courses);
    await assertStageExists(curriculumId, data.ageCategoryId);
    syncWebsiteDiagnostic(data);
    await this.assertPublicDiagnosticAllowed(data, null);
    const shared = group[0]
      ? { name: group[0].name, description: group[0].description, color: group[0].color }
      : {};
    const created = await PathwayModel.create({ curriculumId, ...data, ...shared });
    await syncCatalogue(curriculumId, { name: created.name, description: created.description, color: created.color });
    // Once the pathway has a real stage, an empty "not placed yet" holder has no job left.
    if (stageId) {
      const emptyHolders = group.filter(
        (a) => !a.ageCategoryId && !(a.courses || []).length && !a.diagnosticAssessmentId
      );
      for (const holder of emptyHolders) await this.deletePathway(curriculumId, holder.id);
    }
    return created;
  },

  async updatePathway(curriculumId, id, data) {
    const pathway = await PathwayModel.findById(id);
    if (!pathway || pathway.curriculumId !== curriculumId) {
      const err = new Error("Pathway not found");
      err.statusCode = 404;
      throw err;
    }
    const all = await PathwayModel.findByCurriculumId(curriculumId);
    // The same pathway's rows for its other stages (see createPathway).
    const siblings = all.filter((p) => p.id !== id && samePathwayName(p.name, pathway.name));
    if (data.name && !samePathwayName(data.name, pathway.name)) {
      if (all.some((p) => samePathwayName(p.name, data.name))) {
        const err = new Error("A pathway with this name already exists");
        err.statusCode = 409;
        throw err;
      }
    }
    if (data.ageCategoryId !== undefined) {
      const stageId = data.ageCategoryId || null;
      if (siblings.some((p) => (p.ageCategoryId || null) === stageId)) {
        const err = new Error("This pathway is already set up for that developmental stage");
        err.statusCode = 409;
        throw err;
      }
    }
    await assertCoursesExist(data.courses);
    await assertStageExists(curriculumId, data.ageCategoryId);
    syncWebsiteDiagnostic(data);
    await this.assertPublicDiagnosticAllowed(data, pathway);
    const updated = await PathwayModel.update(id, data);
    if (data.courses !== undefined) await PerformanceBandModel.syncPathwayOrder(curriculumId, id, data.courses || []);
    const shared = {};
    for (const key of ["name", "description", "color"]) {
      if (data[key] !== undefined) shared[key] = data[key];
    }
    if (Object.keys(shared).length > 0) {
      await Promise.all(siblings.map((p) => PathwayModel.update(p.id, shared)));
    }
    if (data.name && !samePathwayName(data.name, pathway.name)) {
      await syncCatalogue(curriculumId, { name: updated.name, description: updated.description, color: updated.color, previousName: pathway.name });
    }
    return updated;
  },

  async deletePathway(curriculumId, id) {
    const pathway = await PathwayModel.findById(id);
    if (!pathway || pathway.curriculumId !== curriculumId) {
      const err = new Error("Pathway not found");
      err.statusCode = 404;
      throw err;
    }
    // Cascade the pathway's own dependents — its course-threshold bands, every learner's
    // placement history in it, and its course/assessment tag links — rather than leaving them
    // orphaned pointing at a pathway that no longer exists. The delete-confirmation UI already
    // tells the admin this happens (see PathwaysPanel's requestDelete message).
    await Promise.all([
      PerformanceBandModel.deleteByPathwayId(id),
      LearnerPathwayModel.deleteByPathwayId(id),
      CoursePathwayLinkModel.deleteByPathwayId(id),
      AssessmentPathwayLinkModel.deleteByPathwayId(id),
    ]);
    await PathwayModel.delete(id);
  },

  // Clones a pathway template (authored in Settings) into a new, independent record
  // owned by this curriculum — not a link. Once imported, editing this curriculum's
  // copy never touches the template, and vice versa.
  async importPathway(curriculumId, pathwayId) {
    const source = await PathwayTemplateModel.findById(pathwayId);
    if (!source) {
      const err = new Error("Pathway template not found");
      err.statusCode = 404;
      throw err;
    }
    // Only the template's courses that are on this curriculum's version come along — a pathway
    // is only given courses on its curriculum's version (competency.controller.js).
    const onVersion = await require("../versions/curriculum-versions.service").versionCourseIds(curriculumId);
    return this.createPathway(curriculumId, {
      name:        source.name,
      description: source.description,
      color:       source.color,
      courses:     (source.courses || []).filter((id) => onVersion?.has(id)),
    });
  },

  /* ── Progression Ladder ─────────────────────────────────────────────── */

  async getLadder(curriculumId) {
    let rungs = await ProgressionLadderModel.findByCurriculumId(curriculumId);
    if (rungs.length === 0) {
      rungs = await Promise.all(DEFAULT_RUNGS.map((r) =>
        ProgressionLadderModel.create({ curriculumId, ...r, assignments: [] })
      ));
    }
    return rungs.sort((a, b) => a.order - b.order);
  },

  async updateLadder(curriculumId, rungs) {
    await Promise.all(rungs.map(async (rung) => {
      const existing = await ProgressionLadderModel.findById(rung.id);
      if (existing && existing.curriculumId === curriculumId) {
        await ProgressionLadderModel.update(rung.id, {
          label:       rung.label,
          ageRange:    rung.ageRange,
          assignments: rung.assignments,
        });
      }
    }));
    const updated = await ProgressionLadderModel.findByCurriculumId(curriculumId);
    return updated.sort((a, b) => a.order - b.order);
  },

  /* ── Age Categories ─────────────────────────────────────────────────── */

  async getAgeCategories(curriculumId) {
    return AgeCategoryModel.findByCurriculumId(curriculumId);
  },

  async createAgeCategory(curriculumId, data) {
    const existing = await AgeCategoryModel.findByCurriculumId(curriculumId);
    if (existing.some((c) => c.name.toLowerCase() === data.name.toLowerCase())) {
      const err = new Error("An age category with this name already exists");
      err.statusCode = 409;
      throw err;
    }
    const category = await AgeCategoryModel.create({ curriculumId, ...data });

    // Every Developmental Stage in a curriculum progresses through the SAME named Performance
    // Band levels (Explorer -> Pioneer) — just configured differently underneath per stage (own
    // competencies/indicator weights/threshold). A brand-new stage inherits whichever band
    // set any existing stage already has, each band starting with empty config. The first stage
    // ever created in a curriculum has nothing to inherit — its bands, built by hand via the
    // normal Add Band flow, become the canonical set every later stage copies.
    if (existing.length > 0) {
      const template = await PerformanceBandModel.findByCurriculumAndStage(curriculumId, existing[0].id);
      for (const band of template) {
        await PerformanceBandModel.create(curriculumId, {
          name: band.name, ageCategoryId: category.id, order: band.order,
        });
      }
    }
    return category;
  },

  async updateAgeCategory(curriculumId, id, data) {
    const cat = await AgeCategoryModel.findById(id);
    if (!cat || cat.curriculumId !== curriculumId) {
      const err = new Error("Age category not found");
      err.statusCode = 404;
      throw err;
    }
    if (data.name) {
      const all = await AgeCategoryModel.findByCurriculumId(curriculumId);
      const others = all.filter((c) => c.id !== id);
      if (others.some((c) => c.name.toLowerCase() === data.name.toLowerCase())) {
        const err = new Error("An age category with this name already exists");
        err.statusCode = 409;
        throw err;
      }
    }
    return AgeCategoryModel.update(id, data);
  },

  async deleteAgeCategory(curriculumId, id) {
    const cat = await AgeCategoryModel.findById(id);
    if (!cat || cat.curriculumId !== curriculumId) {
      const err = new Error("Age category not found");
      err.statusCode = 404;
      throw err;
    }
    // Its own parts go with it — this curriculum's only (a duplicate's stage is its own record, so
    // the curriculum it was copied from keeps all of its own): each pathway's row for this stage
    // (with that row's course and assessment tags) and the stage's performance bands. What people
    // depend on (learners, issued diagnostics, bootcamps) blocks the delete first (usage.service.js).
    const db = require("../../../config/db");
    await db.transaction(async (trx) => {
      const pathwayIds = await trx("pathways").where({ curriculumId, ageCategoryId: id }).pluck("id");
      if (pathwayIds.length) {
        await trx("course_pathway_links").whereIn("pathwayId", pathwayIds).del();
        await trx("assessment_pathway_links").whereIn("pathwayId", pathwayIds).del();
        await trx("performance_bands").where({ curriculumId }).whereIn("pathwayId", pathwayIds).del();
        await trx("pathways").whereIn("id", pathwayIds).del();
      }
      await trx("performance_bands").where({ curriculumId, ageCategoryId: id }).del();
      await trx("age_categories").where({ id }).del();
    });
  },

  /* ── Progress Levels ────────────────────────────────────────────────── */

  async getProgressLevels(curriculumId) {
    return ProgressLevelModel.findByCurriculumId(curriculumId);
  },

  async createProgressLevel(curriculumId, data) {
    const existing = await ProgressLevelModel.findByCurriculumId(curriculumId);
    if (existing.some((l) => l.name.toLowerCase() === data.name.toLowerCase())) {
      const err = new Error("A level with this name already exists");
      err.statusCode = 409;
      throw err;
    }
    return ProgressLevelModel.create({ curriculumId, ...data });
  },

  async updateProgressLevel(curriculumId, id, data) {
    const level = await ProgressLevelModel.findById(id);
    if (!level || level.curriculumId !== curriculumId) {
      const err = new Error("Level not found");
      err.statusCode = 404;
      throw err;
    }
    if (data.name) {
      const all = await ProgressLevelModel.findByCurriculumId(curriculumId);
      const others = all.filter((l) => l.id !== id);
      if (others.some((l) => l.name.toLowerCase() === data.name.toLowerCase())) {
        const err = new Error("A level with this name already exists");
        err.statusCode = 409;
        throw err;
      }
    }
    return ProgressLevelModel.update(id, data);
  },

  async deleteProgressLevel(curriculumId, id) {
    const level = await ProgressLevelModel.findById(id);
    if (!level || level.curriculumId !== curriculumId) {
      const err = new Error("Level not found");
      err.statusCode = 404;
      throw err;
    }
    await ProgressLevelModel.delete(id);
  },

  /* ── Assessment Types ───────────────────────────────────────────────── */

  async getAssessmentTypes(curriculumId) {
    return AssessmentTypeModel.findByCurriculumId(curriculumId);
  },

  async createAssessmentType(curriculumId, data) {
    const existing = await AssessmentTypeModel.findByCurriculumId(curriculumId);
    if (existing.some((t) => t.name.toLowerCase() === data.name.toLowerCase())) {
      const err = new Error("An assessment type with this name already exists");
      err.statusCode = 409;
      throw err;
    }
    return AssessmentTypeModel.create({ curriculumId, ...data });
  },

  async updateAssessmentType(curriculumId, id, data) {
    const item = await AssessmentTypeModel.findById(id);
    if (!item || item.curriculumId !== curriculumId) {
      const err = new Error("Assessment type not found");
      err.statusCode = 404;
      throw err;
    }
    if (data.name) {
      const all = await AssessmentTypeModel.findByCurriculumId(curriculumId);
      const others = all.filter((t) => t.id !== id);
      if (others.some((t) => t.name.toLowerCase() === data.name.toLowerCase())) {
        const err = new Error("An assessment type with this name already exists");
        err.statusCode = 409;
        throw err;
      }
    }
    return AssessmentTypeModel.update(id, data);
  },

  async deleteAssessmentType(curriculumId, id) {
    const item = await AssessmentTypeModel.findById(id);
    if (!item || item.curriculumId !== curriculumId) {
      const err = new Error("Assessment type not found");
      err.statusCode = 404;
      throw err;
    }
    await AssessmentTypeModel.delete(id);
  },

  async updateScoring(curriculumId, id, evidenceWeights) {
    const item = await AssessmentTypeModel.findById(id);
    if (!item || item.curriculumId !== curriculumId) {
      const err = new Error("Assessment type not found");
      err.statusCode = 404;
      throw err;
    }
    return AssessmentTypeModel.update(id, { evidenceWeights });
  },

  async updateGlobalScoring(curriculumId, assessmentTypes, competencyWeights = []) {
    // Tier-1: each type's evidence weights must independently sum to 100% (if any assigned)
    for (const atConfig of assessmentTypes) {
      const at = await AssessmentTypeModel.findById(atConfig.id);
      if (!at || at.curriculumId !== curriculumId) {
        const err = new Error(`Assessment type not found: ${atConfig.id}`);
        err.statusCode = 404;
        throw err;
      }
      if (atConfig.evidenceWeights.length === 0) continue;
      const evTotal = atConfig.evidenceWeights.reduce((sum, w) => sum + w.contribution, 0);
      if (Math.round(evTotal) !== 100) {
        const err = new Error(`"${at.name}" evidence contributions must total exactly 100% (currently ${Math.round(evTotal)}%)`);
        err.statusCode = 422;
        throw err;
      }
    }
    for (const atConfig of assessmentTypes) {
      await AssessmentTypeModel.update(atConfig.id, { typeWeight: atConfig.typeWeight, evidenceWeights: atConfig.evidenceWeights });
    }
    // Tier-3: persist competency weights on the curriculum
    await CurriculumModel.update(curriculumId, { competencyWeights });
    return {
      assessmentTypes:   await AssessmentTypeModel.findByCurriculumId(curriculumId),
      competencyWeights,
    };
  },

  async getCompetencyWeights(curriculumId) {
    const curriculum = await CurriculumModel.findById(curriculumId);
    if (!curriculum) {
      const err = new Error("Curriculum not found");
      err.statusCode = 404;
      throw err;
    }
    return curriculum.competencyWeights || [];
  },

  async calculateScore(curriculumId, id, evidenceScores, ageCategoryId) {
    const assessmentType = await AssessmentTypeModel.findById(id);
    if (!assessmentType || assessmentType.curriculumId !== curriculumId) {
      const err = new Error("Assessment type not found");
      err.statusCode = 404;
      throw err;
    }
    const category = await AgeCategoryModel.findById(ageCategoryId);
    if (!category || category.curriculumId !== curriculumId) {
      const err = new Error("Developmental stage not found");
      err.statusCode = 404;
      throw err;
    }

    const evidenceTypes    = await EvidenceTypeModel.findByCurriculumId(curriculumId);
    const competencies     = await this.getCurriculumCompetencies(curriculumId);
    // This stage's own ladder — findByCurriculumAndStage can never return a Pathway
    // band (those never carry an ageCategoryId), so no separate exclusion filter is needed.
    const performanceBands = await PerformanceBandModel.findByCurriculumAndStage(curriculumId, ageCategoryId);
    const progressLevels   = await ProgressLevelModel.findByCurriculumId(curriculumId);
    const config           = assessmentType.evidenceWeights || [];

    // Engine 1 — weighted evidence scores
    const { finalScore, breakdown: rawBreakdown } = runAssessmentEngine(evidenceScores, config);

    // Enrich breakdown with evidence names
    const breakdown = rawBreakdown.map((row) => {
      const et = evidenceTypes.find((e) => e.id === row.evidenceTypeId);
      return { ...row, name: et?.name || "Unknown" };
    });

    // Engine 2 — competency distribution + normalization
    const competencyScores = runCompetencyEngine(breakdown, config, competencies);

    // Engine 3 — map competency scores to levels and bands
    const rawCompetencyBreakdown = runProgressArcEngine(competencyScores, progressLevels, performanceBands);

    // Competency gate — check each competency against its minimumThreshold
    const competencyBreakdown = rawCompetencyBreakdown.map((cr) => {
      const comp      = competencies.find((c) => c.id === cr.competencyId);
      const threshold = comp?.minimumThreshold ?? 60;
      return { ...cr, threshold, thresholdMet: cr.score >= threshold };
    });
    const allCompetenciesMet = competencyBreakdown.length > 0 && competencyBreakdown.every((cr) => cr.thresholdMet);

    // Overall band for the final score
    const band = [...performanceBands]
      .sort((a, b) => a.minScore - b.minScore)
      .find((b) => finalScore >= b.minScore && finalScore <= b.maxScore) || null;

    const behaviorType = assessmentType.behaviorType || "formative";

    const failedCompetencies = competencyBreakdown.filter((cr) => !cr.thresholdMet);

    let outcome;
    if (behaviorType === "diagnostic") {
      outcome = { type: "placement",        label: band ? `Placement: ${band.name} level` : "No band matched" };
    } else if (!allCompetenciesMet && failedCompetencies.length > 0 && behaviorType === "summative") {
      outcome = { type: "cannot_progress",  label: `Cannot progress — ${failedCompetencies.length} competenc${failedCompetencies.length !== 1 ? "ies" : "y"} below threshold` };
    } else if (allCompetenciesMet) {
      outcome = { type: "passed",           label: "All competencies met — learner can progress" };
    } else {
      outcome = { type: "passed",           label: "All requirements met" };
    }

    const hasCompetencyMappings = config.some((c) => (c.competencyMappings || []).length > 0);

    return {
      finalScore, breakdown,
      band, behaviorType, outcome,
      competencyBreakdown, failedCompetencies, allCompetenciesMet, hasCompetencyMappings,
    };
  },

  // Progress Arc — how much of each Performance Band a learner has completed, driven by
  // indicator-level achievement rather than the overall competency score (see
  // runIndicatorProgressEngine). `indicatorAchievements` is the learner's 0-100 achievement
  // per indicator (marks earned / marks possible across graded work); passed in manually for
  // now, same shape `calculateScore`'s `evidenceScores` takes for the evidence pipeline.
  async calculateIndicatorProgress(curriculumId, ageCategoryId, indicatorAchievements) {
    // findByCurriculumAndStage can never return a Pathway band (those never carry an
    // ageCategoryId), so no separate exclusion filter is needed.
    const performanceBands = await PerformanceBandModel.findByCurriculumAndStage(curriculumId, ageCategoryId);
    return runIndicatorProgressEngine(indicatorAchievements, performanceBands);
  },

  // Pathway sibling of calculateIndicatorProgress above — same engine
  // (runIndicatorProgressEngine is fully generic over whatever performanceBands array it's
  // given), just fed this Pathway's own course ladder (bands with pathwayId+courseId
  // set, ordered by their authored course sequence) instead of a Developmental Stage's ladder.
  // A course's completion% here is how much of ITS OWN indicator-contribution budget a learner
  // has earned — advancing past it (see maybeAdvancePathwayCourse below) means thresholdMet.
  async calculatePathwayCourseProgress(curriculumId, pathwayId, indicatorAchievements) {
    const performanceBands = await PerformanceBandModel.findByPathway(curriculumId, pathwayId);
    return runIndicatorProgressEngine(indicatorAchievements, performanceBands);
  },


  /* ── Evidence Types ─────────────────────────────────────────────────── */

  async getEvidenceTypes(curriculumId) {
    return EvidenceTypeModel.findByCurriculumId(curriculumId);
  },

  async createEvidenceType(curriculumId, data) {
    const existing = await EvidenceTypeModel.findByCurriculumId(curriculumId);
    if (existing.some((e) => e.name.toLowerCase() === data.name.toLowerCase())) {
      const err = new Error("An evidence type with this name already exists");
      err.statusCode = 409;
      throw err;
    }
    return EvidenceTypeModel.create({ curriculumId, ...data });
  },

  async updateEvidenceType(curriculumId, id, data) {
    const item = await EvidenceTypeModel.findById(id);
    if (!item || item.curriculumId !== curriculumId) {
      const err = new Error("Evidence type not found");
      err.statusCode = 404;
      throw err;
    }
    if (data.name) {
      const all = await EvidenceTypeModel.findByCurriculumId(curriculumId);
      const others = all.filter((e) => e.id !== id);
      if (others.some((e) => e.name.toLowerCase() === data.name.toLowerCase())) {
        const err = new Error("An evidence type with this name already exists");
        err.statusCode = 409;
        throw err;
      }
    }
    return EvidenceTypeModel.update(id, data);
  },

  /* ── Performance Bands ──────────────────────────────────────────────── */

  async getPerformanceBands(curriculumId) {
    return PerformanceBandModel.findByCurriculum(curriculumId);
  },

  async createPerformanceBand(curriculumId, data) {
    const created = await PerformanceBandModel.create(curriculumId, data);
    if (!created.pathwayId) await this._syncBandAcrossStages(curriculumId, created, "create");
    else await this._syncPathwayBandOrder(curriculumId, created.pathwayId);
    return created;
  },

  async updatePerformanceBand(curriculumId, id, data) {
    const before = await PerformanceBandModel.findById(id);
    const band = await PerformanceBandModel.update(curriculumId, id, data);
    if (!band) {
      const err = new Error("Performance band not found");
      err.statusCode = 404;
      throw err;
    }
    if (before && !before.pathwayId && data.name && data.name !== before.name) {
      await this._syncBandAcrossStages(curriculumId, band, "rename", before.name);
    }
    return band;
  },

  async deletePerformanceBand(curriculumId, id) {
    const band = await PerformanceBandModel.findById(id);
    await PerformanceBandModel.delete(curriculumId, id);
    if (band && !band.pathwayId) {
      await this._syncBandAcrossStages(curriculumId, band, "delete", band.name);
    }
  },

  // Renumbers a pathway's course bands to follow its courses list (see syncPathwayOrder).
  async _syncPathwayBandOrder(curriculumId, pathwayId) {
    const pathway = await PathwayModel.findById(pathwayId);
    if (pathway) await PerformanceBandModel.syncPathwayOrder(curriculumId, pathwayId, pathway.courses || []);
  },

  async reorderPerformanceBands(curriculumId, ageCategoryId, orderedIds) {
    const reordered = await PerformanceBandModel.reorder(curriculumId, ageCategoryId, orderedIds);
    await this._syncReorderAcrossStages(curriculumId, ageCategoryId, reordered.map((b) => b.name));
    return reordered;
  },

  // A Pathway's own course sequence (the up/down arrows on the Pathways tab). `orderedCourseIds`
  // is the pathway's courses in their new order — every course, whether or not it has
  // advancement settings (a band) yet. The order is saved on the pathway's courses list, and the
  // bands are renumbered to match, since their order is what a learner advances along (see
  // maybeAdvancePathwayCourse). No cross-stage sync: a Pathway's course ladder is unique to
  // itself, unlike Progress-Arc bands which mirror the same named rungs across every stage.
  async reorderPathwayCourses(curriculumId, pathwayId, orderedCourseIds) {
    const pathway = await PathwayModel.findById(pathwayId);
    if (!pathway || pathway.curriculumId !== curriculumId) {
      const err = new Error("Pathway not found");
      err.statusCode = 404;
      throw err;
    }
    const current = pathway.courses || [];
    const sameCourses = orderedCourseIds.length === current.length
      && new Set(orderedCourseIds).size === current.length
      && orderedCourseIds.every((id) => current.includes(id));
    if (!sameCourses) {
      const err = new Error("This pathway's courses have changed since the page loaded — refresh and try again");
      err.statusCode = 409;
      throw err;
    }
    await PathwayModel.update(pathwayId, { courses: orderedCourseIds });
    const bands = await PerformanceBandModel.syncPathwayOrder(curriculumId, pathwayId, orderedCourseIds);
    return { courses: orderedCourseIds, bands };
  },

  // Copies a fully-configured band's setup onto the NEXT band in the same stage's ladder
  // (Explorer -> Builder): its competencies, per-indicator % contributions, advancement range,
  // and score range. Name, order, stage, description are left as the target's own — this is a
  // config copy, not a rename, so it never touches _syncBandAcrossStages. The target's existing
  // config is overwritten wholesale (the client confirms first). Scoped to ONE stage's ladder;
  // other stages' same-named band is deliberately untouched, since each stage is meant to carry
  // its own age-appropriate thresholds.
  async duplicatePerformanceBandToNext(curriculumId, bandId) {
    const source = await PerformanceBandModel.findById(bandId);
    if (!source || source.curriculumId !== curriculumId) {
      const err = new Error("Performance band not found");
      err.statusCode = 404;
      throw err;
    }
    if (source.pathwayId) {
      const err = new Error("Only Progress Arc bands can be duplicated to the next level");
      err.statusCode = 400;
      throw err;
    }
    const ladder = await PerformanceBandModel.findByCurriculumAndStage(curriculumId, source.ageCategoryId);
    const idx = ladder.findIndex((b) => b.id === bandId);
    const target = ladder[idx + 1];
    if (!target) {
      const err = new Error("This is the highest band in the stage — there is no next level to copy to");
      err.statusCode = 400;
      throw err;
    }
    const updated = await PerformanceBandModel.update(curriculumId, target.id, {
      minScore:               source.minScore,
      maxScore:               source.maxScore,
      competencyIds:          source.competencyIds || [],
      indicatorContributions: source.indicatorContributions || [],
      advancementMin:         source.advancementMin ?? 0,
      advancementThreshold:   source.advancementThreshold ?? 0,
    });
    return { source, target: updated };
  },

  // Pathway sibling of duplicatePerformanceBandToNext above — copies a course's
  // competencies/indicator weights/advancement threshold onto the NEXT course in the SAME
  // pathway's ladder (ordered by findByPathway's `order`, not minScore/maxScore — those fields
  // aren't read for pathway bands, so they're deliberately not copied here, unlike the stage
  // version above).
  async duplicatePathwayBandToNext(curriculumId, bandId) {
    const source = await PerformanceBandModel.findById(bandId);
    if (!source || source.curriculumId !== curriculumId) {
      const err = new Error("Performance band not found");
      err.statusCode = 404;
      throw err;
    }
    if (!source.pathwayId) {
      const err = new Error("Only Pathway course bands can be duplicated to the next course");
      err.statusCode = 400;
      throw err;
    }
    const ladder = await PerformanceBandModel.findByPathway(curriculumId, source.pathwayId);
    const idx = ladder.findIndex((b) => b.id === bandId);
    const target = ladder[idx + 1];
    if (!target) {
      const err = new Error("This is the last course in the pathway — there is no next course to copy to");
      err.statusCode = 400;
      throw err;
    }
    const updated = await PerformanceBandModel.update(curriculumId, target.id, {
      competencyIds:          source.competencyIds || [],
      indicatorContributions: source.indicatorContributions || [],
      advancementMin:         source.advancementMin ?? 0,
      advancementThreshold:   source.advancementThreshold ?? 0,
    });
    return { source, target: updated };
  },

  // Keeps every OTHER Developmental Stage's band SET aligned with a create/rename/delete that
  // just happened on one stage's band — every stage progresses through the same named levels,
  // just with independently-configured competencies/indicators/thresholds underneath. Matched by
  // NAME (the band's name before this change, `matchName`), never by position — real-world stage
  // band lists can already be out of alignment (drift that pre-dates this sync feature, or a
  // stage with its own extra custom bands), and matching by position risks silently touching a
  // completely unrelated band that merely happens to share a numeric slot. Never called for
  // Pathway bands (pathwayId set) — callers guard that before invoking this.
  async _syncBandAcrossStages(curriculumId, changedBand, action, matchName) {
    const stages = await AgeCategoryModel.findByCurriculumId(curriculumId);
    const otherStages = stages.filter((s) => s.id !== changedBand.ageCategoryId);
    for (const stage of otherStages) {
      const stageBands = await PerformanceBandModel.findByCurriculumAndStage(curriculumId, stage.id);
      if (action === "create") {
        // Skip a stage that already has a band with this exact name (e.g. it was itself the
        // template another sync pass just copied from) — append at the end of THIS stage's own
        // list rather than forcing the same numeric position, since stages' existing band counts
        // may already differ.
        if (!stageBands.some((b) => b.name === changedBand.name)) {
          await PerformanceBandModel.create(curriculumId, { name: changedBand.name, ageCategoryId: stage.id });
        }
      } else if (action === "rename") {
        const match = stageBands.find((b) => b.name === matchName);
        if (match) await PerformanceBandModel.update(curriculumId, match.id, { name: changedBand.name });
      } else if (action === "delete") {
        const match = stageBands.find((b) => b.name === matchName);
        if (match) await PerformanceBandModel.delete(curriculumId, match.id);
      }
    }
  },

  // Reorder sibling of _syncBandAcrossStages — `newOrder` is the source stage's band NAMES in
  // their new sequence after a reorder. Replayed on every OTHER stage by matching band NAMES
  // (never position, for the same drift-safety reason as _syncBandAcrossStages) — but only for a
  // stage whose own band-name set is an exact match for the source stage's; a stage with a
  // different or incomplete set (today's real drifted data, or one still mid-setup) is left
  // untouched rather than guessed at, since there's no safe way to interleave names it doesn't
  // have into a reordering built for a different set.
  async _syncReorderAcrossStages(curriculumId, sourceStageId, newOrder) {
    const stages = await AgeCategoryModel.findByCurriculumId(curriculumId);
    const sourceNameSet = new Set(newOrder);
    for (const stage of stages.filter((s) => s.id !== sourceStageId)) {
      const stageBands = await PerformanceBandModel.findByCurriculumAndStage(curriculumId, stage.id);
      const stageNameSet = new Set(stageBands.map((b) => b.name));
      const sameSet = stageNameSet.size === sourceNameSet.size && [...sourceNameSet].every((n) => stageNameSet.has(n));
      if (!sameSet) continue;
      const byName = new Map(stageBands.map((b) => [b.name, b.id]));
      const newOrderedIds = newOrder.map((name) => byName.get(name));
      await PerformanceBandModel.reorder(curriculumId, stage.id, newOrderedIds);
    }
  },

  // Indicators actually in use — tagged on at least one question/rubric criterion/
  // observation item of an assessment reachable from this curriculum's attached courses
  // (via both the flat "Attach Course" link and the current published Version Control
  // content). Always computed live, not stored — reflects whatever's currently tagged, so
  // a newly-tagged question shows up without re-attaching anything. Grouped by competency,
  // for the Performance Bands indicator picker (which should only offer these, not every
  // indicator a competency happens to define in Settings).
  // Every assessment id reachable from this curriculum's attached courses — via both the flat
  // "Attach Course" link and the current published Version Control content. Shared by
  // getPopulatedIndicators and getEvidenceTypeScores below.
  async getAttachedAssessmentIds(curriculumId) {
    const courseLinks = await CourseCurriculumLinkModel.findByCurriculumId(curriculumId);
    const courseIds = new Set(courseLinks.map((l) => l.courseId));
    const versions = await CurriculumVersionModel.findAllByCurriculumId(curriculumId);
    const currentVersion = versions.find((v) => v.isCurrent);
    (currentVersion?.content || []).forEach((period) => {
      (period.classes || []).forEach((cls) => {
        (cls.courses || []).forEach((c) => courseIds.add(c.id));
      });
    });

    const assessmentIds = new Set();
    const sessionsByCourse = await Promise.all([...courseIds].map((courseId) => SessionModel.findByCourseId(courseId)));
    sessionsByCourse.forEach((sessions) => {
      sessions.forEach((s) => {
        getSessionAssessmentIds(s).forEach((aid) => assessmentIds.add(aid));
      });
    });
    return assessmentIds;
  },

  async getPopulatedIndicators(curriculumId) {
    const assessmentIds = await this.getAttachedAssessmentIds(curriculumId);

    const usedIndicatorIds = new Set();
    const relevantCompetencyIds = new Set();
    // Marks possible per indicator — summed from `indicatorMarks` on items/rubric criteria
    // across every assessment attached to this curriculum. This is "marks possible," not
    // "marks earned" — there's no grading/submission data yet to compute actual achievement.
    const marksByIndicator = new Map();
    const assessmentRows = await Promise.all([...assessmentIds].map(async (aid) => {
      const [assessment, compLinks] = await Promise.all([
        BuilderAssessmentModel.findById(aid),
        AssessmentCompetencyLinkModel.findByAssessmentId(aid),
      ]);
      return { assessment, compLinks };
    }));

    assessmentRows.forEach(({ assessment, compLinks }) => {
      if (!assessment) return;
      compLinks.forEach((l) => relevantCompetencyIds.add(l.competencyId));

      // Observation items too (every kind) — grading attributes their marks to indicators the
      // same way (grading.utils.js's computeIndicatorBreakdown).
      const scoredEntries = [
        ...(assessment.items || []),
        ...(assessment.rubric || []),
        ...(assessment.type === "observation" ? (assessment.indicators || []) : []),
      ];
      scoredEntries.forEach((entry) => {
        (entry.indicatorMarks || []).forEach(({ indicatorId, marks }) => {
          usedIndicatorIds.add(indicatorId);
          marksByIndicator.set(indicatorId, (marksByIndicator.get(indicatorId) || 0) + (Number(marks) || 0));
        });
      });

      (assessment.indicators || []).forEach((entry) => {
        (entry.competencyIndicatorIds || []).forEach((indId) => usedIndicatorIds.add(indId));
      });
    });

    const comps = await Promise.all([...relevantCompetencyIds].map((competencyId) => CompetencyModel.findById(competencyId)));
    const groups = [];
    comps.forEach((comp) => {
      if (!comp) return;
      const indicators = (comp.indicators || [])
        .filter((ind) => usedIndicatorIds.has(ind.id))
        .map((ind) => ({ ...ind, marksPossible: marksByIndicator.get(ind.id) || 0 }));
      if (indicators.length === 0) return;
      groups.push({ competencyId: comp.id, competencyName: comp.name, indicators });
    });

    return groups;
  },

  // ── Indicator Achievements — persisted marks-earned per indicator, joined against the live
  // marksPossible from getPopulatedIndicators above. Engine 5 aggregates these into
  // per-competency scores (feeding the Competencies tab); the same achievements, converted to
  // percentages, feed Engine 4 for Performance Band completion (feeding the Progress Arc tab).

  async getIndicatorAchievements(curriculumId) {
    const groups = await this.getPopulatedIndicators(curriculumId);
    const achievements = await IndicatorAchievementModel.findByCurriculumId(curriculumId);
    const byIndicatorId = new Map(achievements.map((a) => [a.indicatorId, a]));
    return groups.flatMap((g) =>
      g.indicators.map((ind) => ({
        competencyId:   g.competencyId,
        competencyName: g.competencyName,
        indicatorId:    ind.id,
        indicatorName:  ind.name,
        marksPossible:  ind.marksPossible,
        marksEarned:    byIndicatorId.get(ind.id)?.marksEarned ?? 0,
      }))
    );
  },

  async setIndicatorAchievement(curriculumId, indicatorId, competencyId, marksEarned) {
    if (!(await CurriculumCompetencyLinkModel.findOne(curriculumId, competencyId))) {
      const err = new Error("This curriculum hasn't adopted that competency yet");
      err.statusCode = 404;
      throw err;
    }
    const comp = await CompetencyModel.findById(competencyId);
    if (!comp || !(comp.indicators || []).some((i) => i.id === indicatorId)) {
      const err = new Error("Indicator not found on that competency");
      err.statusCode = 404;
      throw err;
    }
    return IndicatorAchievementModel.upsert(curriculumId, competencyId, indicatorId, marksEarned);
  },

  // Shared by getCompetencyScores (curriculum-wide manual preview) and getLearnerCompetencyScores
  // (real per-learner) — a competency's score is simply the % of its indicators' possible marks
  // earned, classified into this curriculum's Progress Level + Performance Band (Engine 3). No
  // separate evidence-to-competency mapping step is needed: an indicator belongs to exactly one
  // competency (it's nested under one in the global catalog), and which indicators an assessment
  // counts toward is already fixed at assessment-authoring time via indicatorMarks tagging — that
  // tagging IS the competency mapping. `indicatorRows` is either getIndicatorAchievements' shared
  // manual values (preview) or a real learner's getLearnerIndicatorProgress (live).
  async _competencyScoresFromIndicatorMarks(curriculumId, ageCategoryId, indicatorRows) {
    const competencies     = await this.getCurriculumCompetencies(curriculumId);
    // No stage yet (e.g. a learner not yet placed) — still return competency scores, just with
    // no band/level per row, rather than erroring or guessing a ladder.
    const performanceBands = ageCategoryId
      ? await PerformanceBandModel.findByCurriculumAndStage(curriculumId, ageCategoryId)
      : [];
    const progressLevels   = await ProgressLevelModel.findByCurriculumId(curriculumId);

    const byCompetency = new Map();
    indicatorRows.forEach(({ competencyId, marksEarned, marksPossible }) => {
      if (!competencyId) return;
      const cur = byCompetency.get(competencyId) || { marksEarned: 0, marksPossible: 0 };
      cur.marksEarned   += marksEarned || 0;
      cur.marksPossible += marksPossible || 0;
      byCompetency.set(competencyId, cur);
    });

    // Only competencies with at least one attempted indicator get a score — the rest simply
    // aren't in the returned array (the frontend shows "Not yet scored" for those), rather than a
    // misleading 0%.
    const competencyScores = competencies
      .filter((c) => byCompetency.has(c.id))
      .map((c) => {
        const { marksEarned, marksPossible } = byCompetency.get(c.id);
        const score = marksPossible > 0 ? Math.min(100, Math.round((marksEarned / marksPossible) * 100 * 10) / 10) : 0;
        return { competencyId: c.id, name: c.name, score };
      });

    return runProgressArcEngine(competencyScores, progressLevels, performanceBands);
  },

  // Curriculum-admin preview — every learner would see the same number from this one, since
  // "earned" comes from the shared manually-set IndicatorAchievementModel store rather than any
  // real learner's grading. See getLearnerCompetencyScores for the real per-learner version.
  async getCompetencyScores(curriculumId, ageCategoryId) {
    return this._competencyScoresFromIndicatorMarks(curriculumId, ageCategoryId, await this.getIndicatorAchievements(curriculumId));
  },

  // This learner's confirmed Developmental Stage for THIS curriculum — same link/class walk
  // getPathway below performs, extracted since getLearnerCompetencyScores and
  // getLearnerBandProgress both need it too. Returns null if the learner has no enrollment link
  // resolving to this curriculum, or hasn't been placed at a stage yet (currentStageId not set) —
  // both are legitimate, pre-placement states, not errors.
  async _resolveLearnerStageId(curriculumId, learnerId, hubId = null) {
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    // Their enrolments in a class running this curriculum. A learner can be at two hubs running the
    // same curriculum with a different stage at each — the profile shows one hub (`hubId`), so its
    // stage is the one that counts; without a hub, an active enrolment with a stage comes first.
    const inCurriculum = [];
    for (const l of links) {
      if (!l.classId) continue;
      const cls = await ClassModel.findById(l.classId);
      if (cls?.curriculumId === curriculumId) inCurriculum.push(l);
    }
    if (hubId) {
      const atHub = inCurriculum.find((l) => l.hubId === hubId);
      if (atHub) return atHub.currentStageId || null;
    }
    const best = inCurriculum.find((l) => l.status === "active" && l.currentStageId)
      || inCurriculum.find((l) => l.currentStageId)
      || inCurriculum[0];
    return best?.currentStageId || null;
  },


  // Real per-learner competency score — the number this learner should actually see on their
  // profile: their own graded work (AssessmentSubmissionService.getLearnerIndicatorProgress, the
  // same live source feeding the Competencies tab's flat indicator view), aggregated per
  // competency and classified via Engine 3, instead of the shared manual preview value.
  async getLearnerCompetencyScores(curriculumId, learnerId, hubId = null) {
    // Required lazily — see the note near the top of this file on why (circular require with
    // assessment-submission.service.js, which requires this file back for diagnostic placement).
    const AssessmentSubmissionService = require("../../assessments/submissions/assessment-submission.service");
    const rows = await AssessmentSubmissionService.getLearnerIndicatorProgress(learnerId, curriculumId);
    const ageCategoryId = await this._resolveLearnerStageId(curriculumId, learnerId, hubId);
    return this._competencyScoresFromIndicatorMarks(curriculumId, ageCategoryId, rows);
  },

  // Same pipeline as getLearnerCompetencyScores, narrowed to one specific set of assessments —
  // used by a course report, where "competency standing" should reflect the work that report
  // actually covers, not everything the learner has ever been graded on curriculum-wide. Only
  // counts assessments whose own report has been published to the learner, matching the
  // indicator breakdown shown alongside it (see getLearnerIndicatorProgressForAssessments).
  async getLearnerCompetencyScoresForAssessments(curriculumId, learnerId, assessmentIds) {
    const AssessmentSubmissionService = require("../../assessments/submissions/assessment-submission.service");
    const rows = await AssessmentSubmissionService.getLearnerIndicatorProgressForAssessments(learnerId, assessmentIds, curriculumId);
    const ageCategoryId = await this._resolveLearnerStageId(curriculumId, learnerId);
    return this._competencyScoresFromIndicatorMarks(curriculumId, ageCategoryId, rows);
  },

  // Live-data sibling of calculateIndicatorProgress — driven by what's actually persisted
  // instead of requiring the caller to construct the whole indicatorAchievements payload. This
  // is the curriculum-admin preview (shared manual store) — see getLearnerBandProgress for the
  // real per-learner version.
  async getBandProgress(curriculumId, ageCategoryId) {
    const achievements = await this.getIndicatorAchievements(curriculumId);
    const indicatorAchievements = achievements.map((a) => ({
      competencyId: a.competencyId,
      indicatorId:  a.indicatorId,
      percent:      a.marksPossible > 0 ? Math.min(100, (a.marksEarned / a.marksPossible) * 100) : 0,
    }));
    return this.calculateIndicatorProgress(curriculumId, ageCategoryId, indicatorAchievements);
  },

  // Real per-learner sibling of getBandProgress — indicatorAchievements built from this
  // learner's own accumulating progress (already computed with a `percent` per indicator) rather
  // than the shared curriculum-wide manual store. Scoped to the learner's OWN Developmental
  // Stage's ladder — every stage shares the same band NAMES (see createAgeCategory/
  // _syncBandAcrossStages) but each configures its own thresholds/indicators appropriately for
  // that age group, so a 5-year-old's "Pioneer" and an 18-year-old's "Pioneer" are the same rung
  // in name only, evaluated against completely different, age-appropriate criteria.
  // `hubId`: the hub the profile is showing (see _resolveLearnerStageId).
  async getLearnerBandProgress(curriculumId, learnerId, hubId = null) {
    const AssessmentSubmissionService = require("../../assessments/submissions/assessment-submission.service");
    // Scoped to this curriculum, matching getLearnerCompetencyScores above — omitting curriculumId
    // here (as this used to) pulled in a multi-hub/multi-curriculum learner's indicator progress
    // from every curriculum they've ever been graded under, not just the one being viewed.
    const progress = await AssessmentSubmissionService.getLearnerIndicatorProgress(learnerId, curriculumId);
    const indicatorAchievements = progress.map((p) => ({
      competencyId: p.competencyId,
      indicatorId:  p.indicatorId,
      percent:      p.percent,
    }));
    const ageCategoryId = await this._resolveLearnerStageId(curriculumId, learnerId, hubId);
    // Not yet placed at a stage — no ladder to report progress against, rather than resolving
    // findByCurriculumAndStage(curriculumId, null), which would ambiguously match orphaned
    // legacy bands still sitting with ageCategoryId null (see the backfill migration).
    if (!ageCategoryId) return [];
    return this.calculateIndicatorProgress(curriculumId, ageCategoryId, indicatorAchievements);
  },

  // Pathway sibling of getLearnerBandProgress above — same "real per-learner indicator
  // achievement, fed through the engine" shape, scoped to one Pathway's own course ladder
  // instead of a Developmental Stage's. Drives a learner-facing "how close am I to the next
  // course" display (mirrors ProgressArcCard's own useLearnerBandProgress) and is what
  // maybeAdvancePathwayCourse below checks to decide whether to advance a learner.
  async getLearnerPathwayCourseProgress(curriculumId, learnerId, pathwayId) {
    const AssessmentSubmissionService = require("../../assessments/submissions/assessment-submission.service");
    const progress = await AssessmentSubmissionService.getLearnerIndicatorProgress(learnerId, curriculumId);
    const indicatorAchievements = progress.map((p) => ({
      competencyId: p.competencyId,
      indicatorId:  p.indicatorId,
      percent:      p.percent,
    }));
    return this.calculatePathwayCourseProgress(curriculumId, pathwayId, indicatorAchievements);
  },

  // Real cross-learner replacement for the old manual-entry preview above (IndicatorAchievementModel
  // has no UI anywhere to populate it — see getCompetencyScores). Averages every participating
  // learner's own getLearnerCompetencyScores by competencyId, then re-derives level/band from the
  // averaged score via the same runProgressArcEngine used everywhere else. "Participating" means
  // any learner with a graded submission against this curriculum's attached assessments — same
  // signal _evidenceTypeScoresFromEarnedMap already uses for "possible" marks.
  async getCurriculumWideCompetencyScores(curriculumId, ageCategoryId) {
    const AssessmentSubmissionModel = require("../../assessments/submissions/assessment-submission.model");
    const attachedIds = await this.getAttachedAssessmentIds(curriculumId);
    const assessmentIds = new Set(attachedIds);
    const graded = await AssessmentSubmissionModel.findAll({ status: "graded" });
    const gradedLearnerIds = [...new Set(
      graded.filter((s) => assessmentIds.has(s.assessmentId)).map((s) => s.learnerId)
    )];
    if (gradedLearnerIds.length === 0) return [];

    // Only learners currently placed at this stage get averaged into its ladder — averaging
    // across stages would mix bands that don't correspond to each other now that each stage has
    // its own independent ladder.
    const stageIds = await Promise.all(gradedLearnerIds.map((learnerId) => this._resolveLearnerStageId(curriculumId, learnerId)));
    const learnerIds = gradedLearnerIds.filter((_, i) => stageIds[i] === ageCategoryId);
    if (learnerIds.length === 0) return [];

    const sums = {}, counts = {}, names = {};
    const allScores = await Promise.all(learnerIds.map((learnerId) => this.getLearnerCompetencyScores(curriculumId, learnerId)));
    allScores.forEach((scores) => {
      scores.forEach((cs) => {
        sums[cs.competencyId]   = (sums[cs.competencyId]   || 0) + cs.score;
        counts[cs.competencyId] = (counts[cs.competencyId] || 0) + 1;
        names[cs.competencyId]  = cs.name;
      });
    });
    const averaged = Object.keys(sums).map((id) => ({
      competencyId: id, name: names[id], score: Math.round((sums[id] / counts[id]) * 10) / 10,
    }));

    const performanceBands = await PerformanceBandModel.findByCurriculumAndStage(curriculumId, ageCategoryId);
    const progressLevels   = await ProgressLevelModel.findByCurriculumId(curriculumId);
    return runProgressArcEngine(averaged, progressLevels, performanceBands);
  },

  // Same cross-learner averaging as above, for Engine 4's band-completion % (getBandProgress).
  async getCurriculumWideBandProgress(curriculumId, ageCategoryId) {
    const AssessmentSubmissionModel = require("../../assessments/submissions/assessment-submission.model");
    const attachedIds = await this.getAttachedAssessmentIds(curriculumId);
    const assessmentIds = new Set(attachedIds);
    const graded = await AssessmentSubmissionModel.findAll({ status: "graded" });
    const gradedLearnerIds = [...new Set(
      graded.filter((s) => assessmentIds.has(s.assessmentId)).map((s) => s.learnerId)
    )];
    if (gradedLearnerIds.length === 0) return [];

    const stageIds = await Promise.all(gradedLearnerIds.map((learnerId) => this._resolveLearnerStageId(curriculumId, learnerId)));
    const learnerIds = gradedLearnerIds.filter((_, i) => stageIds[i] === ageCategoryId);
    if (learnerIds.length === 0) return [];

    const sums = {}, counts = {}, meta = {};
    const allProgress = await Promise.all(learnerIds.map((learnerId) => this.getLearnerBandProgress(curriculumId, learnerId)));
    allProgress.forEach((progress) => {
      progress.forEach((bp) => {
        sums[bp.bandId]   = (sums[bp.bandId]   || 0) + bp.completion;
        counts[bp.bandId] = (counts[bp.bandId] || 0) + 1;
        meta[bp.bandId]   = { name: bp.name, advancementMin: bp.advancementMin ?? 0, advancementThreshold: bp.advancementThreshold };
      });
    });
    return Object.keys(sums).map((bandId) => {
      const completion = Math.round((sums[bandId] / counts[bandId]) * 10) / 10;
      const min = meta[bandId].advancementMin;
      const threshold = meta[bandId].advancementThreshold;
      // Same "0 = unconfigured, never trivially met, but 100% always counts" rule as
      // runIndicatorProgressEngine.
      const thresholdMet = (threshold > 0 && completion >= threshold) || completion >= 100;
      return {
        bandId, name: meta[bandId].name, completion,
        advancementMin: min,
        advancementThreshold: threshold,
        onTrack: !thresholdMet && min > 0 && completion >= min,
        thresholdMet,
      };
    });
  },

  async deleteEvidenceType(curriculumId, id) {
    const item = await EvidenceTypeModel.findById(id);
    if (!item || item.curriculumId !== curriculumId) {
      const err = new Error("Evidence type not found");
      err.statusCode = 404;
      throw err;
    }
    await EvidenceTypeModel.delete(id);
    // Remove this evidence type from all assessment type scoring configs
    const types = await AssessmentTypeModel.findByCurriculumId(curriculumId);
    await Promise.all(types.map((at) => {
      const filtered = (at.evidenceWeights || []).filter((w) => w.evidenceTypeId !== id);
      if (filtered.length !== (at.evidenceWeights || []).length) {
        return AssessmentTypeModel.update(at.id, { evidenceWeights: filtered });
      }
      return null;
    }));
  },

  /* ── Pathway ─────────────────────────────────────────────────
   * The pathways a learner is on, and their placement timeline in each: where they started,
   * every time they've advanced, and wherever they currently stand. A learner is on:
   *   - the automatic pathway — the one authored for their Developmental Stage at a hub whose
   *     class runs this curriculum (the same pick maybeAutoIssuePathwayDiagnostics issues its
   *     diagnostic for). Nothing is saved until that diagnostic places them; until then they're
   *     shown at its first course.
   *   - every pathway they have a learner_pathways record for — placed by a diagnostic or an
   *     advancement (source "auto"), or assigned by staff (source "manual", assignPathway). */

  // A pathway's courses in its own authored order — Performance Bands with pathwayId+courseId
  // set, ordered by `order` (see PerformanceBandModel.findByPathway; course-to-course
  // advancement is decided by indicator-contribution/threshold, not a score walk) — then
  // whatever's left in courses[] that has no band configured yet. A pathway belongs to exactly
  // one Developmental Stage, so the first course in ITS OWN sequence is always where a learner
  // starts.
  async orderedPathwayCourseIds(curriculumId, pathway) {
    const bands = await PerformanceBandModel.findByPathway(curriculumId, pathway.id);
    const sequencedIds = bands.map((b) => b.courseId).filter((cid) => (pathway.courses || []).includes(cid));
    return [...sequencedIds, ...(pathway.courses || []).filter((cid) => !sequencedIds.includes(cid))];
  },

  // The learner's Developmental Stage at each hub whose class runs this curriculum (stage lives
  // on the hub link — see maybeAutoIssueDiagnostic in learner.service.js).
  async learnerStageIds(curriculumId, learnerId) {
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    const stageIds = new Set();
    for (const link of links) {
      if (!link.classId || !link.currentStageId) continue;
      const cls = await ClassModel.findById(link.classId);
      if (cls?.curriculumId === curriculumId) stageIds.add(link.currentStageId);
    }
    return stageIds;
  },

  // One entry per pathway the learner is on in this curriculum, the automatic one first. Each
  // carries its ordered courseIds — the learner's My Courses adds these to their class's.
  async getPathway(curriculumId, learnerId) {
    const pathways = await PathwayModel.findByCurriculumId(curriculumId);
    const records = (await LearnerPathwayModel.findByLearner(learnerId)).filter((r) => r.curriculumId === curriculumId);
    // The automatic pathway, per class of this curriculum the learner is in: the one the class
    // runs for their stage there (a bootcamp's class runs only the bootcamp's pathways —
    // class-pathways.js), and the one they're already placed on when it runs several for that
    // stage, so a placement never gains a second, arbitrary pathway beside it.
    const { pathwaysForClass, stagePathwayFor } = require("../../../shared/utils/class-pathways");
    const placedIds = new Set(records.filter((r) => r.source !== "manual").map((r) => r.pathwayId));
    const autoIds = new Set();
    for (const link of await LearnerHubLinkModel.findByLearnerId(learnerId)) {
      if (!link.classId || !link.currentStageId) continue;
      const cls = await ClassModel.findById(link.classId);
      if (cls?.curriculumId !== curriculumId) continue;
      const pick = stagePathwayFor(await pathwaysForClass(cls), link.currentStageId, placedIds);
      if (pick) autoIds.add(pick.id);
    }

    const rows = [];
    for (const pathway of pathways) {
      const record = records.find((r) => r.pathwayId === pathway.id);
      if (!record && !autoIds.has(pathway.id)) continue;
      const courseIds = await CompetencyService.orderedPathwayCourseIds(curriculumId, pathway);
      rows.push({
        pathwayId: pathway.id,
        pathwayName: pathway.name,
        stageId: pathway.ageCategoryId || null,
        source: record?.source || "auto",
        currentCourseId: record ? record.currentCourseId : courseIds[0] || null,
        history: record?.history || [],
        isDefault: !record,
        courseIds,
      });
    }
    return rows.sort((a, b) => Number(a.source === "manual") - Number(b.source === "manual"));
  },

  // Staff put a learner on a pathway by hand, alongside their automatic one. They start at its
  // first course and move up the ladder like any other placement (maybeAdvancePathwayCourse).
  // Only a pathway in a curriculum one of the learner's classes runs — those are the courses a
  // learner can open (course.controller.js's assertCourseAccess).
  async assignPathway(curriculumId, learnerId, pathwayId) {
    const pathway = await PathwayModel.findById(pathwayId);
    if (!pathway || pathway.curriculumId !== curriculumId) fail(404, "Pathway not found");
    if (!(await LearnerModel.findById(learnerId))) fail(404, "Learner not found");
    const links = await LearnerHubLinkModel.findByLearnerId(learnerId);
    const classes = await Promise.all(links.filter((l) => l.classId).map((l) => ClassModel.findById(l.classId)));
    if (!classes.some((c) => c?.curriculumId === curriculumId)) {
      fail(400, "This learner isn't in a class that runs this curriculum.");
    }
    const current = await CompetencyService.getPathway(curriculumId, learnerId);
    if (current.some((row) => row.pathwayId === pathwayId)) fail(409, "This learner is already on this pathway.");
    const [firstCourseId] = await CompetencyService.orderedPathwayCourseIds(curriculumId, pathway);
    if (!firstCourseId) fail(400, "This pathway has no courses yet — add some before assigning it.");
    return LearnerPathwayModel.place(learnerId, curriculumId, pathwayId, firstCourseId, "manual", null, "manual");
  },

  // Takes a hand-assigned pathway off a learner (its placement history goes with it). The
  // automatic one can't be removed — it follows the learner's stage.
  async removePathway(curriculumId, learnerId, pathwayId) {
    const record = await LearnerPathwayModel.findOne(learnerId, pathwayId);
    if (!record || record.curriculumId !== curriculumId) fail(404, "This learner isn't on this pathway.");
    if (record.source !== "manual") fail(400, "Only a pathway added by hand can be removed — the automatic one follows the learner's stage.");
    await LearnerPathwayModel.deleteOne(learnerId, pathwayId);
  },

  // Records a placement/advancement for one learner in one Pathway — always appends
  // to history rather than overwriting it.
  async placeLearner(curriculumId, learnerId, pathwayId, data) {
    const pathway = await PathwayModel.findById(pathwayId);
    if (!pathway || pathway.curriculumId !== curriculumId) {
      const err = new Error("Pathway not found");
      err.statusCode = 404;
      throw err;
    }
    const learner = await LearnerModel.findById(learnerId);
    if (!learner) {
      const err = new Error("Learner not found");
      err.statusCode = 404;
      throw err;
    }
    return LearnerPathwayModel.place(learnerId, curriculumId, pathwayId, data.courseId, data.reason, data.assessmentId);
  },

  // Given a diagnostic score, which course in this Pathway's ladder (its Performance
  // Bands with pathwayId+courseId set) the learner has earned. Walks bands by score
  // range and takes the highest one cleared; if none are cleared, falls back to the lowest
  // (a "prerequisite" placement rather than leaving the learner unplaced).
  async resolvePlacementFromScore(curriculumId, pathwayId, score) {
    const bands = await PerformanceBandModel.findByPathway(curriculumId, pathwayId);
    if (bands.length === 0) return null;
    const cleared = bands.filter((b) => score >= b.minScore);
    const matched = cleared.length > 0 ? cleared[cleared.length - 1] : bands[0];
    return matched.courseId;
  },

  // Bridges a graded standalone diagnostic (see assessment-submission.service.js's
  // maybePlaceFromDiagnostic) into this learner's placement identity: the age category the
  // diagnostic was issued for becomes their confirmed Developmental Stage, and the score
  // resolves their curriculum-wide Performance Band — the same "stage x band" identity the
  // Identity Matrix preview describes, now persisted for the first time on a real learner.
  // Mirrors calculateScore's own band match (strict minScore/maxScore range) rather than
  // resolvePlacementFromScore's "highest cleared" rule, since that rule is specific to a
  // Pathway's course ladder. `hubId` is the enrollment this diagnostic was issued for
  // (see issueDiagnostic) — placement is written onto that hub's link, not the learner record,
  // so a learner enrolled at several hubs keeps a separate placement at each.
  async placeLearnerFromDiagnostic(learnerId, hubId, ageCategoryId, scorePercent) {
    const category = await AgeCategoryModel.findById(ageCategoryId);
    if (!category) return null;
    const bands = await PerformanceBandModel.findByCurriculumAndStage(category.curriculumId, ageCategoryId);
    const band = [...bands]
      .sort((a, b) => a.minScore - b.minScore)
      .find((b) => scorePercent >= b.minScore && scorePercent <= b.maxScore) || null;
    const link = await LearnerHubLinkModel.findOne(learnerId, hubId);
    if (link) await LearnerHubLinkModel.update(link.id, { currentStageId: ageCategoryId, stageSource: "diagnostic", currentBandId: band?.id ?? null });
    return { stageId: ageCategoryId, band };
  },

  // Bridges a graded standalone Pathway diagnostic (see assessment-submission.service.js's
  // maybePlaceFromDiagnostic) into that area's own Pathway: the score resolves a
  // starting course via resolvePlacementFromScore's "highest cleared threshold" rule, and always
  // places the learner there, even if that's their current or a "lower" course — a first
  // diagnostic isn't an advancement to guard against moving backward from; it's establishing the
  // starting point.
  async placeLearnerFromPathwayDiagnostic(learnerId, pathwayId, scorePercent, assessmentId = null) {
    const pathway = await PathwayModel.findById(pathwayId);
    if (!pathway) return null;
    const courseId = await this.resolvePlacementFromScore(pathway.curriculumId, pathwayId, scorePercent);
    if (!courseId) return null;
    return this.placeLearner(pathway.curriculumId, learnerId, pathwayId, { courseId, reason: "diagnostic", assessmentId });
  },

  // Called after a graded submission's marks are persisted (see assessment-submission.service.js's
  // maybePlaceFromDiagnostic sibling call sites) for every Pathway the just-graded course
  // belongs to — checks whether the learner has now cleared their CURRENT course's
  // indicator-contribution threshold in that Pathway and, if so, advances them to the next
  // course in the ladder's authored order. A no-op (returns null) whenever there's no next course
  // to advance to, the learner hasn't been placed in this Pathway yet (nothing to advance FROM —
  // their first placement is always a diagnostic or a manual action, never this), or the
  // threshold isn't met yet. Never moves a learner backward and never re-places them at their
  // already-current course.
  async maybeAdvancePathwayCourse(curriculumId, learnerId, pathwayId) {
    const journey = await LearnerPathwayModel.findOne(learnerId, pathwayId);
    if (!journey?.currentCourseId) return null;

    const bands = await PerformanceBandModel.findByPathway(curriculumId, pathwayId);
    const currentIndex = bands.findIndex((b) => b.courseId === journey.currentCourseId);
    // The learner's current course has no band configured (no contribution/threshold set up
    // yet), or it's already the last course in the ladder — nothing to advance to.
    if (currentIndex === -1 || currentIndex === bands.length - 1) return null;

    const progress = await this.getLearnerPathwayCourseProgress(curriculumId, learnerId, pathwayId);
    const currentProgress = progress.find((p) => p.bandId === bands[currentIndex].id);
    if (!currentProgress?.thresholdMet) return null;

    const nextCourseId = bands[currentIndex + 1].courseId;
    const placement = await this.placeLearner(curriculumId, learnerId, pathwayId, { courseId: nextCourseId, reason: "advanced", assessmentId: null });

    // Lazy-required (not a top-level require) — NotificationService itself requires this file
    // (see its own maybeNotifyLevelUp), so a top-level require here would be circular. Same
    // pattern getLearnerBandProgress above already uses for AssessmentSubmissionService.
    const NotificationService = require("../../notifications/notification.service");
    const pathway = await PathwayModel.findById(pathwayId);
    const course = await CourseModel.findById(nextCourseId);
    await NotificationService.notifyLearner(learnerId, {
      type: "pathway_course_unlocked",
      title: "New course unlocked!",
      message: `You've unlocked "${course?.name || "the next course"}"${pathway ? ` in ${pathway.name}` : ""} — keep going!`,
      payload: { pathwayId, courseId: nextCourseId, curriculumId, learnerId },
      dedupeKey: `pathway_course_unlocked:${learnerId}:${pathwayId}:${nextCourseId}`,
    });

    return placement;
  },

};

module.exports = CompetencyService;
