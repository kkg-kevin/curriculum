const ClassModel   = require("./class.model");
const LearnerHubLinkModel = require("../learners/learner-hub-link.model");
const ClassCourseTeacherLinkModel = require("./class-course-teacher-link.model");
const TimetableModel = require("../timetable/timetable.model");
const CourseScheduleModel = require("../timetable/course-schedule.model");
const SessionSkipModel = require("../timetable/session-skip.model");
const AttendanceModel = require("../attendance/attendance.model");
const AssessmentIssueModel = require("../assessments/submissions/assessment-issue.model");
const ClassGroupService = require("./groups/class-group.service");
const CurriculumModel = require("../curriculum/curriculum.model");
const SystemLevelModel = require("../settings/system-levels/system-level.model");
const CurriculumVersionService = require("../curriculum/versions/curriculum-versions.service");
const ReportService = require("../reports/report.service");
const TimetableService = require("../timetable/timetable.service");
const SessionOccurrenceService = require("../timetable/session-occurrence.service");

// Tag is unique across every class, system-wide (not just within one hub) — it's how a specific
// class instance gets referenced unambiguously in reports/attendance even though many hubs can
// share the same gradeId/gradeName off the same curriculum. excludeId skips the record being
// updated so re-saving a class's own unchanged tag doesn't collide with itself.
async function assertTagAvailable(tag, excludeId) {
  if (!tag) return;
  const all = await ClassModel.findAll();
  const others = all.filter((c) => c.id !== excludeId);
  if (others.some((c) => c.tag && c.tag.toLowerCase() === tag.toLowerCase())) {
    const err = new Error("A class with this tag already exists");
    err.statusCode = 409;
    throw err;
  }
}

// A grade's first class at a hub for a given year needs no stream label — it's the only one.
// Any additional class in that same (schoolId, curriculumId, gradeId, academicYear) group must be
// told apart with a streamName, and that name can't repeat another stream already in the group, so
// the Classes grid never shows two identically-labeled cards for the same grade. curriculumId is
// part of the group key because a grade's `id` is free text authored per curriculum (see
// curriculum.validation.js's classSchema) — two unrelated curricula (e.g. a hub's regular
// curriculum and a Competition/Bootcamp's own curriculum) can easily mint the same gradeId, and
// without curriculumId in the key that cross-curriculum coincidence would look like a duplicate.
async function assertStreamAvailable(schoolId, curriculumId, gradeId, academicYear, streamName, excludeId) {
  const forSchool = await ClassModel.findAll({ schoolId });
  const group = forSchool.filter(
    (c) =>
      c.id !== excludeId &&
      c.curriculumId === curriculumId &&
      c.gradeId === gradeId &&
      c.academicYear === academicYear
  );
  if (group.length === 0) return;
  const norm = (s) => (s || "").trim().toLowerCase();
  if (!norm(streamName)) {
    const err = new Error("A class for this grade already exists at this hub — give this one a stream name to tell them apart");
    err.statusCode = 409;
    throw err;
  }
  if (group.some((c) => norm(c.streamName) === norm(streamName))) {
    const err = new Error("A class with this grade and stream already exists");
    err.statusCode = 409;
    throw err;
  }
}

// Finds this class's grade in its own curriculum's grade list and takes the next entry as "the
// next grade" — the curriculum's classes[] array has no explicit order field, so array position
// is the only sequencing signal available (assumes grades are authored in progression order).
// Next academic year is just +1 on this class's own year, matching how Set Up Year always mints
// one class per grade per year. Never creates the target class — only looks up whether Set Up
// Year has already created it, same shell assertStreamAvailable's uniqueness check assumes.
async function resolveNextClass(cls) {
  const curriculum = await CurriculumModel.findById(cls.curriculumId);
  const grades = curriculum?.classes || [];
  const idx = grades.findIndex((g) => g.id === cls.gradeId);
  if (idx === -1 || idx === grades.length - 1) {
    return { nextGradeId: null, nextGradeName: null, nextAcademicYear: null, nextClass: null };
  }
  const nextGrade = grades[idx + 1];
  const nextAcademicYear = String(Number(cls.academicYear) + 1);
  const siblings = await ClassModel.findAll({ schoolId: cls.schoolId });
  const nextClass = siblings.find((c) => c.gradeId === nextGrade.id && c.academicYear === nextAcademicYear) || null;
  return { nextGradeId: nextGrade.id, nextGradeName: nextGrade.name, nextAcademicYear, nextClass };
}

// Classes in the order their grades appear on the curriculum they run, not the order they
// happened to be created in. "As on the curriculum" is the curriculum page's own order
// (CurriculumViewPage.jsx's sortClassesBySystemLevel — keep the two in step): the grades in the
// order they were added, with those mapped to a System Level arranged among themselves by that
// level's sequence. A grade with no System Level keeps its place rather than dropping to the end
// (a curriculum's youngest grades are often the unmapped ones). A class is matched to its grade
// by id, or by name when the grade was since re-created. Within a grade: newest academic
// year first, then stream name (2 before 10). A hub running more than one curriculum keeps each
// curriculum's classes together; a class whose grade is no longer on its curriculum goes after
// that curriculum's others, in its original order.
// `lookups` (optional) — curricula and levels already loaded, so sorting many hubs' classes one
// hub at a time doesn't load the same ones again (getAllClassesForHubs).
async function curriculumLookups(curriculumIds) {
  const curricula = await CurriculumModel.findByIds(curriculumIds);
  const gradesOf = (curriculum) => (Array.isArray(curriculum.classes) ? curriculum.classes : []);
  const levelIds = [...new Set(curricula.flatMap((c) => gradesOf(c).map((g) => g.systemLevelId)).filter(Boolean))];
  const levels = await SystemLevelModel.findByIds(levelIds);
  return { curriculumById: new Map(curricula.map((c) => [c.id, c])), sequenceById: new Map(levels.map((l) => [l.id, l.sequence])) };
}

async function sortByCurriculumOrder(classes, lookups = null) {
  const curriculumIds = [...new Set(classes.map((c) => c.curriculumId).filter(Boolean))];
  const { curriculumById, sequenceById } = lookups || (await curriculumLookups(curriculumIds));
  const curricula = curriculumIds.map((id) => curriculumById.get(id)).filter(Boolean);
  const gradesOf = (curriculum) => (Array.isArray(curriculum.classes) ? curriculum.classes : []);

  const gradeIndex = new Map(); // `${curriculumId}|${gradeId}` or `${curriculumId}|name|${name}` -> position
  curricula.forEach((curriculum) => {
    const grades = gradesOf(curriculum);
    const mapped = grades
      .map((grade, i) => ({ grade, i, sequence: sequenceById.get(grade.systemLevelId) }))
      .filter((entry) => entry.sequence != null)
      .sort((x, y) => x.sequence - y.sequence || x.i - y.i);
    let next = 0;
    const ordered = grades.map((grade) => (sequenceById.get(grade.systemLevelId) == null ? grade : mapped[next++].grade));
    ordered.forEach((grade, position) => {
      gradeIndex.set(`${curriculum.id}|${grade.id}`, position);
      const name = String(grade.name || "").trim().toLowerCase();
      if (name && !gradeIndex.has(`${curriculum.id}|name|${name}`)) gradeIndex.set(`${curriculum.id}|name|${name}`, position);
    });
  });
  const curriculumRank = new Map(); // order each curriculum first shows up in
  classes.forEach((c) => {
    const key = c.curriculumId || "";
    if (!curriculumRank.has(key)) curriculumRank.set(key, curriculumRank.size);
  });
  const gradeOf = (c) =>
    gradeIndex.get(`${c.curriculumId}|${c.gradeId}`) ??
    gradeIndex.get(`${c.curriculumId}|name|${String(c.gradeName || "").trim().toLowerCase()}`) ??
    Infinity;
  return classes
    .map((c, i) => ({ c, i }))
    .sort((x, y) =>
      curriculumRank.get(x.c.curriculumId || "") - curriculumRank.get(y.c.curriculumId || "") ||
      gradeOf(x.c) - gradeOf(y.c) ||
      String(y.c.academicYear || "").localeCompare(String(x.c.academicYear || ""), undefined, { numeric: true }) ||
      String(x.c.streamName || "").localeCompare(String(y.c.streamName || ""), undefined, { numeric: true }) ||
      x.i - y.i
    )
    .map(({ c }) => c);
}

const ClassService = {
  async createClass(data) {
    await assertTagAvailable(data.tag, null);
    await assertStreamAvailable(data.schoolId, data.curriculumId, data.gradeId, data.academicYear, data.streamName, null);
    return ClassModel.create(data);
  },

  async getAllClasses(filters) {
    const classes = await ClassModel.findAll(filters);
    const classIds = classes.map((c) => c.id);
    const links = await LearnerHubLinkModel.findByClassIds(classIds);
    const countMap = {};
    for (const l of links) {
      if (!l.classId) continue;
      countMap[l.classId] = (countMap[l.classId] || 0) + 1;
    }
    const counted = classes.map((c) => ({ ...c, learnerCount: countMap[c.id] || 0 }));
    // A paged request keeps the model's own stable order (see ClassModel.findAll).
    if (filters?.limit || filters?.offset) return counted;
    return sortByCurriculumOrder(counted);
  },

  // Every class of several hubs (an admin's workspace list), in the same order as calling
  // getAllClasses once per hub and joining the results — but loaded in a handful of queries
  // instead of a few per hub (17 Nov 2026).
  async getAllClassesForHubs(hubIds, filters = {}) {
    const classes = await ClassModel.findAll({ ...filters, schoolId: undefined, schoolIds: hubIds });
    const links = await LearnerHubLinkModel.findByClassIds(classes.map((c) => c.id));
    const countMap = {};
    for (const l of links) if (l.classId) countMap[l.classId] = (countMap[l.classId] || 0) + 1;
    const counted = classes.map((c) => ({ ...c, learnerCount: countMap[c.id] || 0 }));
    const lookups = await curriculumLookups([...new Set(counted.map((c) => c.curriculumId).filter(Boolean))]);
    const out = [];
    for (const hubId of hubIds) out.push(...(await sortByCurriculumOrder(counted.filter((c) => c.schoolId === hubId), lookups)));
    return out;
  },

  async getClassById(id) {
    const record = await ClassModel.findById(id);
    if (!record) {
      const err = new Error("Class not found");
      err.statusCode = 404;
      throw err;
    }
    return record;
  },

  async updateClass(id, data) {
    if (data.tag !== undefined) await assertTagAvailable(data.tag, id);
    if (data.streamName !== undefined) {
      const existing = await ClassModel.findById(id);
      if (existing) await assertStreamAvailable(existing.schoolId, existing.curriculumId, existing.gradeId, existing.academicYear, data.streamName, id);
    }
    const record = await ClassModel.update(id, data);
    if (!record) {
      const err = new Error("Class not found");
      err.statusCode = 404;
      throw err;
    }
    return record;
  },

  async bulkCreateClasses(items) {
    // Bulk-created items (Set Up Year, Event deployment) never carry a tag today, but guard
    // against both a collision with an already-saved class and a duplicate within this same
    // batch, same as a one-at-a-time create would catch.
    const seen = new Set();
    for (const item of items) {
      if (!item.tag) continue;
      const key = item.tag.toLowerCase();
      if (seen.has(key)) {
        const err = new Error("A class with this tag already exists");
        err.statusCode = 409;
        throw err;
      }
      seen.add(key);
      await assertTagAvailable(item.tag, null);
    }
    // Set Up Year / Event deployment each create exactly one class per grade per batch, so
    // there's never a same-grade collision within the batch itself — only against classes that
    // already exist from an earlier run.
    for (const item of items) {
      await assertStreamAvailable(item.schoolId, item.curriculumId, item.gradeId, item.academicYear, item.streamName, null);
    }
    return Promise.all(items.map((item) => ClassModel.create(item)));
  },

  // A learner has "completed" this class's grade once every course the grade's curriculum
  // version assigns to it is `ready` per ReportService.getReadinessForClassCourses — the exact
  // signal the Reports page already uses for "this course's final report can be generated"
  // (every session-attached assessment graded+published), reused here rather than building a
  // second completion tracker. A grade with zero courses, or any course with zero gradeable
  // content, can never read as ready — inherited from isCourseReadyForLearner, not special-cased.
  async getPromotionReadiness(classId) {
    const cls = await ClassService.getClassById(classId);
    const nextInfo = await resolveNextClass(cls);
    const courses = await CurriculumVersionService.getCurrentCourses(cls.curriculumId, cls.gradeId);
    const courseIds = courses.map((c) => c.id);
    const links = await LearnerHubLinkModel.findByClassId(classId);
    const activeLearnerIds = links.filter((l) => l.status === "active").map((l) => l.learnerId);

    let learners = activeLearnerIds.map((learnerId) => ({ learnerId, ready: false, completedCourses: 0, totalCourses: courseIds.length }));
    if (courseIds.length > 0 && activeLearnerIds.length > 0) {
      const readinessByCourse = await ReportService.getReadinessForClassCourses(classId, courseIds);
      learners = activeLearnerIds.map((learnerId) => {
        const completedCourses = courseIds.filter((courseId) =>
          (readinessByCourse[courseId] || []).find((r) => r.learner.id === learnerId)?.ready
        ).length;
        return { learnerId, completedCourses, totalCourses: courseIds.length, ready: completedCourses === courseIds.length };
      });
    }

    return { ...nextInfo, totalCourses: courseIds.length, learners };
  },

  // The four-metric close-out checklist for a class's academic year — the gate the Promotion
  // panel and the class-detail "completion" panel both read. Each metric is derived live, never
  // stored: nothing here is a flag someone sets, it's all computed from the same records the
  // rest of the app already writes.
  //
  //   1. sessionsTaught    — every past session occurrence marked taught (or cancelled).
  //   2. grading           — every session-attached assessment graded+published for every
  //                          active learner (ReportService's existing readiness signal).
  //   3. attendanceClosed  — every past session occurrence has attendance either taken or
  //                          consciously locked as not-marked (never left as "not_taken").
  //   4. reports           — every (learner, non-empty session) pair has a published session
  //                          report — a real one, or a filed "not submitted" one.
  //
  // Metrics 1 & 3 come from SessionOccurrenceService; 2 & 4 from ReportService. `unresolved`
  // lists the concrete work items still blocking 2 & 4 so the UI can link straight to them.
  async getCompletionStatus(classId) {
    const cls = await ClassService.getClassById(classId);
    const courses = await CurriculumVersionService.getCurrentCourses(cls.curriculumId, cls.gradeId);
    const courseIds = courses.map((c) => c.id);

    const links = await LearnerHubLinkModel.findByClassId(classId);
    const activeLearnerIds = links.filter((l) => l.status === "active").map((l) => l.learnerId);

    const occurrence = await SessionOccurrenceService.getOccurrenceCompletion(
      classId,
      (args) => TimetableService.resolveCalendar(args)
    );

    // Grading + reports readiness, per course, reusing the exact signal the Reports page uses.
    let readinessByCourse = {};
    if (courseIds.length > 0 && activeLearnerIds.length > 0) {
      readinessByCourse = await ReportService.getReadinessForClassCourses(classId, courseIds);
    }
    const allRows = courseIds.flatMap((id) => readinessByCourse[id] || []);
    // "Grading done" = every per-learner row across every course is `ready` (its own readiness
    // flag already means every session-attached assessment graded AND published).
    const gradingTotal = allRows.length;
    const gradingReady = allRows.filter((r) => r.ready).length;

    const unresolved = (courseIds.length > 0 && activeLearnerIds.length > 0)
      ? await ReportService.getUnresolvedSessionWork(classId, courseIds)
      : { needsGrading: [], notSubmitted: [] };

    const metrics = {
      sessionsTaught: {
        done: occurrence.sessionsTaught.pendingCount === 0 && occurrence.sessionsTaught.total > 0,
        ...occurrence.sessionsTaught,
      },
      attendanceClosed: {
        done: occurrence.attendanceClosed.pendingCount === 0 && occurrence.attendanceClosed.total > 0,
        ...occurrence.attendanceClosed,
      },
      grading: {
        done: gradingTotal > 0 && gradingReady === gradingTotal && unresolved.needsGrading.length === 0,
        total: gradingTotal,
        ready: gradingReady,
        pendingCount: unresolved.needsGrading.length,
      },
      reports: {
        // Work not handed in yet but still open (not due) counts as pending too (19 Nov 2026).
        done: gradingTotal > 0 && unresolved.needsGrading.length === 0 && unresolved.notSubmitted.length === 0 && !(unresolved.stillOpen > 0),
        pendingCount: unresolved.notSubmitted.length + (unresolved.stillOpen || 0),
      },
    };

    // A class with no active learners, or a grade with no courses, has nothing to complete —
    // treated as "not applicable" rather than "complete" so it never reads as a finished year
    // that just has no content.
    const applicable = courseIds.length > 0 && activeLearnerIds.length > 0 && occurrence.sessionsTaught.total > 0;
    const complete = applicable && Object.values(metrics).every((m) => m.done);

    return {
      classId,
      applicable,
      complete,
      metrics,
      unresolved,
      totalCourses: courseIds.length,
      activeLearners: activeLearnerIds.length,
    };
  },

  // Re-resolves readiness/next-class server-side rather than trusting whatever the client sends
  // — a stale or manipulated request can never move an unready or unenrolled learner. Only ever
  // moves a learner INTO an already-existing class shell (Set Up Year's job, not this one's).
  async promoteLearners(classId, learnerIds) {
    const readiness = await ClassService.getPromotionReadiness(classId);
    if (!readiness.nextClass) {
      const err = new Error(
        readiness.nextGradeId
          ? `Set up classes for ${readiness.nextAcademicYear} first`
          : "This is the final grade — there's no next class to promote into"
      );
      err.statusCode = 409;
      throw err;
    }
    const readyById = new Map(readiness.learners.map((l) => [l.learnerId, l.ready]));
    const links = await LearnerHubLinkModel.findByClassId(classId);
    const linkByLearnerId = new Map(links.map((l) => [l.learnerId, l]));

    const promoted = [];
    const skipped = [];
    for (const learnerId of learnerIds) {
      const link = linkByLearnerId.get(learnerId);
      if (!link) { skipped.push({ learnerId, reason: "Not enrolled in this class" }); continue; }
      if (!readyById.get(learnerId)) { skipped.push({ learnerId, reason: "Hasn't completed every course yet" }); continue; }
      await LearnerHubLinkModel.update(link.id, { classId: readiness.nextClass.id });
      promoted.push(learnerId);
    }
    return { promoted, skipped, nextClass: readiness.nextClass };
  },

  async deleteClass(id) {
    const deleted = await ClassModel.delete(id);
    if (!deleted) {
      const err = new Error("Class not found");
      err.statusCode = 404;
      throw err;
    }
    // Learners enrolled here stay enrolled at the hub, just no longer placed in a class.
    await LearnerHubLinkModel.clearClassId(id);
    await ClassCourseTeacherLinkModel.deleteByClassId(id);
    await TimetableModel.deleteByClassId(id);
    await CourseScheduleModel.deleteByClassId(id);
    await SessionSkipModel.deleteByClassId(id);
    await AttendanceModel.deleteByClassId(id);
    await SessionOccurrenceService.deleteAllForClass(id);
    await ClassGroupService.deleteAllForClass(id);
    // Only class-owned issues (no learnerId — see AssessmentIssueModel's own comment) go with the
    // class, mirroring learner.service.js's deleteLearner doing the exact opposite: it removes
    // learner-targeted issues and leaves class-owned ones alone. Learner-targeted submissions/issues
    // that merely reference this classId are real graded work belonging to a learner, not the class,
    // so they're deliberately left in place — same tolerance already relied on by revokeIssue().
    const issues = await AssessmentIssueModel.findAll({ classId: id });
    await Promise.all(issues.filter((i) => i.learnerId == null).map((i) => AssessmentIssueModel.delete(i.id)));
    return { message: "Class deleted successfully" };
  },
};

module.exports = ClassService;
