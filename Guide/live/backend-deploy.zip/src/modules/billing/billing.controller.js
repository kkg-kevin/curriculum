const asyncHandler = require("express-async-handler");
const BillingService = require("./billing.service");
const { createInvoiceSchema, updateInvoiceSchema, recordPaymentSchema, setInstalmentsSchema, bulkInvoicePreviewSchema, bulkInvoiceCreateSchema, statementQuerySchema } = require("./billing.validation");

const listBatches = asyncHandler(async (req, res) => {
  const data = await BillingService.listBatches(req);
  res.json({ success: true, data, count: data.length });
});

const previewBulkInvoices = asyncHandler(async (req, res) => {
  const data = bulkInvoicePreviewSchema.parse(req.body);
  res.json({ success: true, data: await BillingService.previewBulkInvoices(data, req) });
});

const createBulkInvoices = asyncHandler(async (req, res) => {
  const data = bulkInvoiceCreateSchema.parse(req.body);
  res.status(201).json({ success: true, data: await BillingService.createBulkInvoices(data, req) });
});

const listInvoices = asyncHandler(async (req, res) => {
  const data = await BillingService.listInvoices(req);
  res.json({ success: true, data, count: data.length });
});

const getInvoice = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await BillingService.getInvoice(req.params.id, req) });
});

const createInvoice = asyncHandler(async (req, res) => {
  const data = createInvoiceSchema.parse(req.body);
  res.status(201).json({ success: true, data: await BillingService.createInvoice(data, req) });
});

const updateInvoice = asyncHandler(async (req, res) => {
  const data = updateInvoiceSchema.parse(req.body);
  res.json({ success: true, data: await BillingService.updateInvoice(req.params.id, data, req) });
});

const issueInvoice = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await BillingService.issueInvoice(req.params.id, req) });
});

const emailInvoice = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await BillingService.emailInvoice(req.params.id, req) });
});

const cancelInvoice = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await BillingService.cancelInvoice(req.params.id, req) });
});

const recordPayment = asyncHandler(async (req, res) => {
  const data = recordPaymentSchema.parse(req.body);
  res.json({ success: true, data: await BillingService.recordPayment(req.params.id, data, req) });
});

// An invoice's payment schedule — a plan, parts typed by hand, or none.
const setInstalments = asyncHandler(async (req, res) => {
  const data = setInstalmentsSchema.parse(req.body);
  res.json({ success: true, data: await BillingService.setInstalments(req.params.id, data, req) });
});

const listReceipts = asyncHandler(async (req, res) => {
  const data = await BillingService.listReceipts(req);
  res.json({ success: true, data, count: data.length });
});

const getReceipt = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await BillingService.getReceipt(req.params.invoiceId, req.params.paymentId, req) });
});

const getStatement = asyncHandler(async (req, res) => {
  const query = statementQuerySchema.parse(req.query);
  res.json({ success: true, data: await BillingService.getStatement(req.params.payerType, req.params.payerId, query, req) });
});

const listCustomers = asyncHandler(async (req, res) => {
  const data = await BillingService.listCustomers(req);
  res.json({ success: true, data, count: data.length });
});

const getCustomer = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await BillingService.getCustomer(req.params.hubId, req) });
});

module.exports = {
  setInstalments, listInvoices, getInvoice, createInvoice, updateInvoice, issueInvoice, emailInvoice, cancelInvoice, recordPayment, listBatches, previewBulkInvoices, createBulkInvoices, listReceipts, getReceipt, getStatement, listCustomers, getCustomer };
