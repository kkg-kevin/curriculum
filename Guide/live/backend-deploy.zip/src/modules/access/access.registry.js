// What a staff role's permissions can cover, and how an incoming request maps onto them.
//
// A permission is a module + an action. Staff accounts (role "collaborator") carry a role whose
// permissions say which modules they can View / Create / Edit / Delete in — see
// scope.middleware.js's attachOwnRecords for enforcement and access.service.js for how a user's
// effective permissions are resolved.
//
// The client builds its role editor from GET /api/access/modules (served from this file), and its
// sidebar/route gating uses the same keys — keep sidebar `module` keys in
// client/src/components/ui/Sidebar.jsx and client/src/routes/StaffAccessGate.jsx identical to these.

const ACTIONS = ["view", "create", "edit", "delete"];

// `legacy: true` marks the modules a collaborator could be granted before roles existed (the
// allowedModules era); a collaborator with no role still resolves through them exactly as before.
const MODULES = [
  { key: "learning-hubs", label: "Learning Hubs", group: "Workspace", legacy: true },
  { key: "curriculum", label: "Curriculum", group: "Teaching", legacy: true },
  { key: "courses", label: "Courses", group: "Teaching", legacy: true },
  { key: "assessments", label: "Assessments", group: "Teaching", legacy: true },
  { key: "learners", label: "Learners", group: "People", legacy: true },
  { key: "teachers", label: "Educators", group: "People", legacy: true },
  { key: "classes", label: "Classes", group: "Teaching", legacy: true },
  { key: "attendance", label: "Attendance", group: "Teaching", legacy: true },
  { key: "timetable", label: "Timetable", group: "Teaching", legacy: true },
  { key: "home-learning", label: "Home Learning", group: "Programmes", legacy: true },
  { key: "tech-clubs", label: "Tech Clubs", group: "Programmes" },
  { key: "pathway-subscriptions", label: "Pathway subscriptions", group: "Programmes" },
  { key: "competitions", label: "Competitions", group: "Programmes", legacy: true },
  { key: "bootcamps", label: "Bootcamps", group: "Programmes", legacy: true },
  { key: "reports", label: "Reports", group: "Teaching", legacy: true },
  { key: "notifications", label: "Notifications", group: "Workspace", legacy: true },
  { key: "settings", label: "Settings", group: "Workspace", legacy: true },
  // Reading the activity log (who did what, when). Only View means anything here — the log
  // can't be added to, edited or deleted by anyone.
  { key: "activity", label: "Activity log", group: "Workspace" },
  { key: "billing", label: "Billing", group: "Finance" },
  { key: "hub-visits", label: "Hub visits & revenue", group: "Finance" },
  // Educator claims. A claim is normally reviewed by the educator's supervisor — a separate
  // supervisor login, not a staff role. Staff come in on the workspace's side of it:
  // "Educator claims" → Edit lets them decide a claim in a supervisor's place; "Claim approvals"
  // → Edit is the admin's part: approving a claim from an educator with no supervisor, recording
  // payments, the session rate, and managing the supervisor accounts.
  { key: "claims", label: "Educator claims (review for a supervisor)", group: "Finance" },
  { key: "claims-approval", label: "Claim approvals & payment", group: "Finance" },
  // Hub check-ins: setting up schedules and seeing every hub's check-ins. A hub's Account Manager
  // and Training Lead aren't staff — they're named on the hub and work in the hub portal
  // (modules/checkins/checkin.access.js).
  { key: "checkins-manage", label: "Hub check-ins: schedules & every hub", group: "Workspace" },
  // Quality assurance: templates, visit schedules and every educator's reviews. Supervisors aren't
  // staff — they review the educators assigned to them in the supervisor portal (modules/qa/).
  { key: "qa", label: "Quality assurance (educator reviews)", group: "Workspace" },
];

const MODULE_KEYS = MODULES.map((m) => m.key);
const LEGACY_MODULE_KEYS = MODULES.filter((m) => m.legacy).map((m) => m.key);

// Request path prefix → the module that gates it.
const PATH_PREFIX_TO_MODULE = {
  "/api/curricula": "curriculum",
  "/api/competencies": "settings",
  "/api/pathway-templates": "settings",
  "/api/system-levels": "settings",
  "/api/inventory": "settings",
  "/api/items": "settings",
  "/api/learning-hubs": "learning-hubs",
  "/api/teachers": "teachers",
  "/api/classes": "classes",
  "/api/class-groups": "classes",
  "/api/rooms": "classes",
  "/api/learners": "learners",
  "/api/courses": "courses",
  "/api/attendance": "attendance",
  "/api/timetable": "timetable",
  "/api/assessments": "assessments",
  "/api/assessment-submissions": "assessments",
  "/api/reports": "reports",
  "/api/certificates": "reports",
  "/api/competitions": "competitions",
  "/api/bootcamps": "bootcamps",
  "/api/notifications": "notifications",
  "/api/home-learning": "home-learning",
  "/api/tech-clubs": "tech-clubs",
  "/api/pathway-subscriptions": "pathway-subscriptions",
  "/api/billing": "billing",
  "/api/hub-visits": "hub-visits",
  "/api/audit": "activity",
  "/api/claims": "claims",
  "/api/checkins": "checkins-manage",
  "/api/qa": "qa",
  "/api/tot": "teachers",
};

// Settings catalogs are shared reference data: reading one (to pick from it) is also allowed by
// viewing any module that uses it, without the Settings permission. Changing a catalog — and the
// Settings page itself — still needs Settings.
const AUTHORING_MODULES = ["assessments", "courses", "curriculum"];
const CATALOG_READERS = {
  "/api/competencies": AUTHORING_MODULES,
  // Billing → Packages → Pathway plans reads the pathway directory too.
  "/api/pathway-templates": [...AUTHORING_MODULES, "billing"],
  "/api/system-levels": ["curriculum"],
  "/api/inventory": ["assessments", "courses", "billing"],
  "/api/items": ["assessments", "courses", "billing"],
  // Not a catalog, but the same rule: someone who only does final approvals still has to be able
  // to read the claims they are approving.
  "/api/claims": ["claims-approval"],
};
// The educator form offers a supervisor to pick — so the list of supervisors can also be read by
// anyone who can view Educators.
const SUPERVISOR_LIST = /^\/api\/claims\/supervisors$/;
// The hub form offers an Account Manager and a Training Lead to pick — so that list can also be
// read by anyone who can view Learning Hubs.
const CHECKIN_PEOPLE_LIST = /^\/api\/checkins\/people$/;

// Surfaces only the workspace owner can use, whatever a staff role says: staff/role management,
// moving content between admins, sharing with other admins, and the cross-workspace platform
// analytics.
const OWNER_ONLY_PREFIXES = ["/api/admin-tools", "/api/access", "/api/sharing", "/api/email-settings", "/api/certificate-settings", "/api/payment-settings", "/api/reports/platform-analytics"];

// Requests whose meaning isn't what their HTTP method suggests. Checked before the default rules.
const ACTION_OVERRIDES = [
  // Raising a Home Learning invoice creates a billing invoice — gated by Billing, not Home Learning.
  { method: "POST", pattern: /^\/api\/home-learning(\/[^/]+)?\/invoices$/, module: "billing", action: "create" },
  // Approving a website sign-up records its payment; declining one removes its accounts.
  { method: "POST", pattern: /^\/api\/home-learning\/[^/]+\/approve-payment$/, module: "billing", action: "edit" },
  { method: "POST", pattern: /^\/api\/home-learning\/[^/]+\/decline-signup$/, module: "home-learning", action: "delete" },
  // The same three for Tech Club memberships.
  { method: "POST", pattern: /^\/api\/tech-clubs(\/[^/]+)?\/invoices$/, module: "billing", action: "create" },
  { method: "POST", pattern: /^\/api\/tech-clubs\/[^/]+\/approve-payment$/, module: "billing", action: "edit" },
  { method: "POST", pattern: /^\/api\/tech-clubs\/[^/]+\/decline-signup$/, module: "tech-clubs", action: "delete" },
  // Pathway subscriptions: raising invoices is billing; the plans live in Billing → Packages.
  { method: "POST", pattern: /^\/api\/pathway-subscriptions(\/[^/]+)?\/invoices$/, module: "billing", action: "create" },
  { method: "GET", pattern: /^\/api\/pathway-subscriptions\/packages$/, module: "billing", action: "view" },
  { method: "POST", pattern: /^\/api\/pathway-subscriptions\/packages$/, module: "billing", action: "create" },
  { method: "PUT", pattern: /^\/api\/pathway-subscriptions\/packages\/[^/]+$/, module: "billing", action: "edit" },
  { method: "DELETE", pattern: /^\/api\/pathway-subscriptions\/packages\/[^/]+$/, module: "billing", action: "delete" },
  // A pathway's website listing (show, picture, hubs) is set beside its plans in Billing → Packages.
  { method: "PUT", pattern: /^\/api\/pathway-templates\/[^/]+\/website$/, module: "billing", action: "edit" },
  // Issuing, cancelling and recording a payment change an existing invoice.
  { method: "POST", pattern: /^\/api\/billing\/[^/]+\/(issue|cancel|payments)$/, module: "billing", action: "edit" },
  // Confirming or rejecting a family's "I've paid" notice records (or refuses) a payment.
  { method: "POST", pattern: /^\/api\/billing\/payment-notices\/[^/]+\/(confirm|reject)$/, module: "billing", action: "edit" },
  // Moving a website order along (preparing, ready, dispatched, cancelled) changes it.
  { method: "POST", pattern: /^\/api\/billing\/orders\/[^/]+\/status$/, module: "billing", action: "edit" },
  // Detaching a competency, pathway or material from a course or assessment edits that course or
  // assessment — nothing is deleted (attaching one is already an edit).
  { method: "DELETE", pattern: /^\/api\/courses\/[^/]+\/(competencies|pathways|inventory)\/links\/[^/]+$/, module: "courses", action: "edit" },
  { method: "DELETE", pattern: /^\/api\/assessments\/[^/]+\/(competencies|pathways|inventory)\/links\/[^/]+$/, module: "assessments", action: "edit" },
  // Taking a course out of a folder (Courses page) files it differently — nothing is deleted.
  { method: "DELETE", pattern: /^\/api\/courses\/folders\/[^/]+\/courses\/[^/]+$/, module: "courses", action: "edit" },
  // The same for an assessment taken out of a folder (Assessments page).
  { method: "DELETE", pattern: /^\/api\/assessments\/folders\/[^/]+\/assessments\/[^/]+$/, module: "assessments", action: "edit" },
  // A form's draft of unsaved work is kept, changed and thrown away as the form is used — anyone
  // who can add or edit assessments (or courses) uses it, whichever they're doing.
  { method: "POST", pattern: /^\/api\/assessments\/drafts$/, module: "assessments", action: "create", orActions: ["edit"] },
  { method: "PUT", pattern: /^\/api\/assessments\/drafts\/[^/]+$/, module: "assessments", action: "create", orActions: ["edit"] },
  { method: "DELETE", pattern: /^\/api\/assessments\/drafts\/[^/]+$/, module: "assessments", action: "create", orActions: ["edit"] },
  { method: "POST", pattern: /^\/api\/courses\/drafts$/, module: "courses", action: "create", orActions: ["edit"] },
  { method: "PUT", pattern: /^\/api\/courses\/drafts\/[^/]+$/, module: "courses", action: "create", orActions: ["edit"] },
  { method: "DELETE", pattern: /^\/api\/courses\/drafts\/[^/]+$/, module: "courses", action: "create", orActions: ["edit"] },
  // A claim's second stage — final approval and recording the payment — and the session rate
  // belong to "Claim approvals", not to the supervisor's review. (The supervisor's own decision,
  // POST /api/claims/:id/supervisor-decision, falls under the default rule: Educator claims → Edit.)
  { method: "POST", pattern: /^\/api\/claims\/[^/]+\/(admin-decision|mark-paid|mpesa-payout)$/, module: "claims-approval", action: "edit" },
  { method: "PUT", pattern: /^\/api\/claims\/settings$/, module: "claims-approval", action: "edit" },
  // Creating, changing and removing supervisor accounts is the admin's side too.
  { method: "POST", pattern: /^\/api\/claims\/supervisors$/, module: "claims-approval", action: "edit" },
  { method: "PUT", pattern: /^\/api\/claims\/supervisors\/[^/]+$/, module: "claims-approval", action: "edit" },
  { method: "DELETE", pattern: /^\/api\/claims\/supervisors\/[^/]+$/, module: "claims-approval", action: "edit" },
  // Scheduling another run of a bootcamp makes a new bootcamp (a copy with new dates).
  { method: "POST", pattern: /^\/api\/bootcamps\/[^/]+\/runs$/, module: "bootcamps", action: "create" },
  // Hub check-ins: a staff member needs "checkins-manage" for all of it; the schedules map their
  // own actions.
  { method: "GET", pattern: /^\/api\/checkins\/schedules$/, module: "checkins-manage", action: "view" },
  { method: "POST", pattern: /^\/api\/checkins\/schedules$/, module: "checkins-manage", action: "create" },
  { method: "PUT", pattern: /^\/api\/checkins\/schedules\/[^/]+$/, module: "checkins-manage", action: "edit" },
  { method: "POST", pattern: /^\/api\/checkins\/schedules\/[^/]+\/end$/, module: "checkins-manage", action: "edit" },
];

// A POST that only works something out without saving it.
const READ_ONLY_POST = /\/(preview|search|validate|check|export)$/;
// An id-shaped path segment (records use UUIDs).
const ID_SEGMENT = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Express routes ignore letter case and a trailing slash, so the rules here must too — otherwise
// "/api/x/Approve-Payment/" would reach the same handler while missing its rule.
function normalisePath(path) {
  return String(path || "").toLowerCase().replace(/\/+$/, "");
}

const underPrefix = (path, prefix) => path === prefix || path.startsWith(`${prefix}/`);

function resolveModuleForPath(rawPath) {
  const path = normalisePath(rawPath);
  const prefix = Object.keys(PATH_PREFIX_TO_MODULE).find((p) => underPrefix(path, p));
  return prefix ? PATH_PREFIX_TO_MODULE[prefix] : null;
}

function isOwnerOnlyPath(rawPath) {
  const path = normalisePath(rawPath);
  return OWNER_ONLY_PREFIXES.some((p) => underPrefix(path, p));
}

/**
 * What a request needs: { module, action } or null when the path isn't a staff-gated module.
 * A read of a Settings catalog also carries `orView` — modules whose View permission is enough.
 *   GET/HEAD/OPTIONS → view · DELETE → delete · PUT/PATCH → edit
 *   POST → create for a new record, but edit when it's under an existing record
 *   (e.g. POST /api/courses/:id/sessions adds to that course), and view for previews/searches.
 */
function resolveAccess(method, rawPath) {
  const path = normalisePath(rawPath);
  const verb = method.toUpperCase();
  const override = ACTION_OVERRIDES.find((o) => o.method === verb && o.pattern.test(path));
  if (override) return { module: override.module, action: override.action, ...(override.orActions ? { orActions: override.orActions } : {}) };
  const module = resolveModuleForPath(path);
  if (!module) return null;
  if (verb === "GET" || verb === "HEAD" || verb === "OPTIONS") {
    const catalog = Object.keys(CATALOG_READERS).find((p) => underPrefix(path, p));
    if (SUPERVISOR_LIST.test(path)) return { module, action: "view", orView: [...CATALOG_READERS[catalog], "teachers"] };
    if (CHECKIN_PEOPLE_LIST.test(path)) return { module, action: "view", orView: ["learning-hubs"] };
    return catalog ? { module, action: "view", orView: CATALOG_READERS[catalog] } : { module, action: "view" };
  }
  if (verb === "DELETE") return { module, action: "delete" };
  if (verb === "PUT" || verb === "PATCH") return { module, action: "edit" };
  if (READ_ONLY_POST.test(path)) return { module, action: "view" };
  const underExistingRecord = path.split("/").some((segment) => ID_SEGMENT.test(segment));
  return { module, action: underExistingRecord ? "edit" : "create" };
}

// "delete from Learners", "view Billing" — for 403 messages.
function describeAccess({ module, action }) {
  const label = MODULES.find((m) => m.key === module)?.label || module;
  const verb = { view: "view", create: "add to", edit: "edit", delete: "delete from" }[action] || action;
  return `${verb} ${label}`;
}

module.exports = {
  describeAccess,
  ACTIONS, MODULES, MODULE_KEYS, LEGACY_MODULE_KEYS, PATH_PREFIX_TO_MODULE,
  resolveModuleForPath, resolveAccess, isOwnerOnlyPath,
};
