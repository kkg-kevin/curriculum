import{i as e,n as t}from"./chunk-CacB07dV.js";import{b as n,x as r}from"./api-DGMXcJWw.js";import{Mn as i,On as a,tt as o,xn as s}from"./fi-CbFULhqG.js";import{Et as c,Lt as l,Vt as u,kt as d,zt as f}from"./index-5K_Fj84C.js";import{a as p,c as m,d as h,f as g,i as _,l as v,n as y,o as b,r as x,s as S,t as C,u as w}from"./AnnouncementPopup-ptqP4WHh.js";function T({isMobile:e=!1,isMobileOpen:t=!1,onClose:n=()=>{}}){let{expanded:r,handlers:i}=w(!e),a=!e&&!r;return(0,E.jsxs)(E.Fragment,{children:[e&&t?(0,E.jsx)(`div`,{role:`presentation`,onClick:n,style:{position:`fixed`,inset:0,backgroundColor:`rgba(15, 23, 42, 0.45)`,zIndex:1200}}):null,(0,E.jsxs)(`aside`,{...i,"aria-hidden":e&&!t?!0:void 0,inert:e&&!t,style:{width:e?`min(86vw, 300px)`:a?72:260,bottom:0,backgroundColor:`#25476a`,color:`#fff`,position:`fixed`,left:e?t?0:`-100%`:0,top:0,display:`flex`,flexDirection:`column`,fontFamily:`Inter, sans-serif`,zIndex:1300,transition:`left 0.25s ease, width 0.2s ease`,boxShadow:e?`0 18px 60px rgba(0,0,0,0.28)`:r?`8px 0 32px rgba(0,0,0,0.22)`:`none`,overflowY:`auto`,overflowX:`hidden`},children:[(0,E.jsxs)(`div`,{style:{padding:a?`20px 12px`:`20px 24px`,borderBottom:`1px solid rgba(255,255,255,0.1)`,display:`flex`,alignItems:`center`,justifyContent:e||a?`center`:`flex-start`,gap:`8px`},children:[!a&&(0,E.jsx)(`img`,{src:c,alt:`Digifunzi`,style:{height:`40px`,width:`auto`,objectFit:`contain`,filter:`brightness(0) invert(1)`}}),e?(0,E.jsx)(`button`,{type:`button`,onClick:n,"aria-label":`Close menu`,style:{width:`36px`,height:`36px`,borderRadius:`50%`,border:`1px solid rgba(255,255,255,0.25)`,background:`transparent`,color:`#fff`,cursor:`pointer`,fontSize:`18px`,flexShrink:0},children:`×`}):null]}),(0,E.jsx)(`nav`,{style:{flex:1,padding:a?`20px 8px`:`20px 12px`},children:D.map(t=>{let r=t.icon;return(0,E.jsxs)(f,{to:t.path,end:t.path===`/affiliate-portal`,onClick:e?n:void 0,title:a?t.name:void 0,style:({isActive:e})=>({display:`flex`,alignItems:`center`,gap:`12px`,justifyContent:a?`center`:`flex-start`,padding:a?`12px`:`12px 18px`,marginBottom:`8px`,borderRadius:`12px`,textDecoration:`none`,color:e?`#25476a`:`#fff`,fontSize:`15px`,fontWeight:e?`700`:`500`,backgroundColor:e?`#feb139`:`transparent`,transition:`all 0.2s ease`}),children:[(0,E.jsx)(r,{size:18,style:{flexShrink:0}}),!a&&(0,E.jsx)(`span`,{style:{flex:1,whiteSpace:`nowrap`,overflow:`hidden`,textOverflow:`ellipsis`},children:t.name})]},t.name)})}),(0,E.jsx)(`div`,{style:{padding:a?`8px`:`12px`,borderTop:`1px solid rgba(255,255,255,0.1)`},children:(0,E.jsx)(h,{collapsed:a})}),!a&&(0,E.jsxs)(`div`,{style:{padding:`18px`,textAlign:`center`,borderTop:`1px solid rgba(255,255,255,0.1)`,fontSize:`12px`,color:`rgba(255,255,255,0.8)`},children:[`© `,new Date().getFullYear(),` `,`Digifunzi`]})]})]})}var E,D,O=t((()=>{l(),i(),d(),g(),v(),E=n(),D=[{name:`Refer & Earn`,path:`/affiliate-portal`,icon:o},{name:`Announcements`,path:`/affiliate-portal/announcements`,icon:a},{name:`My Account`,path:`/affiliate-portal/account`,icon:s}]}));function k(){let[e,t]=(0,A.useState)(()=>typeof window<`u`?window.innerWidth<M:!1),[n,r]=(0,A.useState)(!1);return(0,A.useEffect)(()=>{let e=()=>{let e=window.innerWidth<M;t(e),e||r(!1)};return e(),window.addEventListener(`resize`,e),()=>window.removeEventListener(`resize`,e)},[]),(0,A.useEffect)(()=>{if(!(e&&n))return;let t=document.body.style.overflow;document.body.style.overflow=`hidden`;let i=e=>{e.key===`Escape`&&r(!1)};return window.addEventListener(`keydown`,i),()=>{document.body.style.overflow=t,window.removeEventListener(`keydown`,i)}},[e,n]),(0,j.jsxs)(`div`,{className:`affiliate-shell`,children:[(0,j.jsx)(T,{isMobile:e,isMobileOpen:n,onClose:()=>r(!1)}),(0,j.jsxs)(`div`,{className:`affiliate-shell__content`,style:{marginLeft:e?0:72},children:[(0,j.jsx)(S,{isMobile:e,onMenuClick:()=>r(!0)}),(0,j.jsx)(`main`,{className:`affiliate-shell__main`,children:(0,j.jsx)(u,{})}),(0,j.jsx)(p,{})]}),(0,j.jsx)(x,{}),(0,j.jsx)(C,{}),(0,j.jsx)(`style`,{children:`
        .affiliate-shell {
          display: flex;
          width: 100%;
          min-height: 100vh;
          min-height: 100dvh;
          background:
            radial-gradient(circle at top right, rgba(56,170,225,0.10), transparent 28%),
            linear-gradient(180deg, #F8FBFE 0%, #F5F7FA 100%);
        }
        .affiliate-shell__content {
          flex: 1 1 auto;
          min-width: 0;
          min-height: 100vh;
          min-height: 100dvh;
          display: flex;
          flex-direction: column;
          overflow-x: hidden;
          transition: margin-left 0.2s ease;
        }
        .affiliate-shell__main { flex: 1; min-width: 0; padding: 28px 32px 36px; }
        @media (max-width: ${M-1}px) {
          .affiliate-shell__main { padding: 18px 16px 28px; }
        }
        @media (max-width: 380px) {
          .affiliate-shell__main { padding: 14px 12px 24px; }
        }
      `})]})}var A,j,M;t((()=>{A=e(r()),l(),O(),m(),b(),v(),_(),y(),j=n(),M=900}))();export{k as default};