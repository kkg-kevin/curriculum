import{i as e,n as t}from"./chunk-CacB07dV.js";import{b as n,x as r}from"./api-DGMXcJWw.js";import{B as i,H as a,Qn as o,Sn as s,Xn as c,en as l,t as u}from"./icons-material-Cgfsq_3K.js";import{Kt as d,Lt as f,Wt as p}from"./index-DWhyOf3t.js";import{n as m,t as h}from"./courseApi-BZEAGbH9.js";import{d as g,n as _,u as v}from"./useCourse-C8s5tBII.js";import{o as y,t as b}from"./useCurriculum-DDkr8Dek.js";import{a as x,c as S,n as C,t as w}from"./useCurriculumVersion-DpCA9m5-.js";import{n as T,t as E}from"./useAcademicYear-BoJq3Cu0.js";function D(e){let t=e.classes||[];return(e.periods||[]).map(e=>({periodName:e.name,classes:t.map(e=>({classId:e.id,className:e.name,courses:[]}))}))}function O(e,t){let n=e.classes||[];return(e.periods||[]).map(e=>{let r=(t||[]).find(t=>t.periodName===e.name);return{periodName:e.name,classes:n.map(e=>{let t=r?.classes?.find(t=>t.classId===e.id);return{classId:e.id,className:e.name,courses:t?.courses||[]}})}})}function k({size:e=13,light:t=!0}){return(0,W.jsx)(`span`,{style:{width:`${e}px`,height:`${e}px`,border:`2px solid ${t?`rgba(255,255,255,0.4)`:`#E5E7EB`}`,borderTopColor:t?`#fff`:`#25476a`,borderRadius:`50%`,display:`inline-block`,animation:`vc-spin 0.7s linear infinite`,flexShrink:0}})}function A(){return(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`center`,height:`380px`,fontFamily:`Inter,sans-serif`,gap:`14px`,color:`#6B7280`,fontSize:`14px`},children:[(0,W.jsx)(`span`,{style:{width:`28px`,height:`28px`,border:`3px solid #E5E7EB`,borderTopColor:`#25476a`,borderRadius:`50%`,display:`inline-block`,animation:`vc-spin 0.7s linear infinite`}}),`Loading…`]})}function j({status:e}){let t=K.find(t=>t.value===e)||K[0];return(0,W.jsxs)(`span`,{style:{display:`inline-flex`,alignItems:`center`,gap:`4px`,padding:`3px 9px`,borderRadius:`20px`,backgroundColor:t.bg,border:`1.5px solid ${t.border}`,color:t.color,fontSize:`11px`,fontWeight:`700`,whiteSpace:`nowrap`},children:[(0,W.jsx)(`span`,{style:{width:`5px`,height:`5px`,borderRadius:`50%`,backgroundColor:t.dot,flexShrink:0}}),t.label]})}function M({children:e,color:t,bg:n,border:r}){return(0,W.jsx)(`span`,{style:{display:`inline-flex`,alignItems:`center`,padding:`2px 7px`,borderRadius:`20px`,backgroundColor:n,border:`1px solid ${r}`,color:t,fontSize:`10px`,fontWeight:`700`,whiteSpace:`nowrap`},children:e})}function N({current:e}){return(0,W.jsx)(`div`,{className:`vc-steps`,children:G.map((t,n)=>{let r=t.n<e,i=t.n===e;return(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`},children:[(0,W.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:`6px`},children:[(0,W.jsx)(`div`,{style:{width:`34px`,height:`34px`,borderRadius:`50%`,backgroundColor:r||i?`#25476a`:`#F3F4F6`,border:`2.5px solid ${r||i?`#25476a`:`#E5E7EB`}`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:r||i?`#fff`:`#9CA3AF`,fontSize:r?`15px`:`13px`,fontWeight:`700`,flexShrink:0,boxShadow:i?`0 0 0 4px rgba(37,71,106,0.1)`:`none`},children:r?(0,W.jsx)(o,{fontSize:`small`}):t.n}),(0,W.jsx)(`span`,{style:{fontSize:`11px`,fontWeight:i?`700`:`400`,color:i?`#25476a`:r?`#374151`:`#9CA3AF`,whiteSpace:`nowrap`},children:t.label})]}),n<G.length-1&&(0,W.jsx)(`div`,{className:`vc-connector`,style:{backgroundColor:r?`#25476a`:`#E5E7EB`}})]},t.n)})})}function P({periods:e,ayPeriods:t,activeIdx:n,onChange:r}){return(0,W.jsx)(`div`,{className:`vc-period-tabs`,children:e.map((e,i)=>{let a=t.find(t=>t.name===e.name),o=a?.startDate||a?.endDate?`${Y(a.startDate)} – ${Y(a.endDate)}`:null;return(0,W.jsxs)(`button`,{type:`button`,onClick:()=>r(i),className:`vc-tab${n===i?` active`:``}`,children:[e.name,o&&(0,W.jsx)(`span`,{style:{fontSize:`10px`,fontWeight:`400`,marginLeft:`6px`,opacity:.65},children:o})]},e.name)})})}function F({onAdd:e,onCancel:t,allCourses:n,existingCourseIds:r}){let[i,a]=(0,U.useState)(``),[o,s]=(0,U.useState)(``),[c,l]=(0,U.useState)(!1),[u,d]=(0,U.useState)(null),{mutateAsync:f,isPending:p}=g(),m=(0,U.useRef)(null),_=(0,U.useRef)(null);(0,U.useEffect)(()=>{m.current?.focus()},[]),(0,U.useEffect)(()=>{if(!c)return;let e=e=>{_.current?.contains(e.target)||l(!1)};return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[c]);let v=i.trim(),y=n.filter(e=>!r.includes(e.id)&&(e.status||`active`)===`active`),b=(v?y.filter(e=>e.name.toLowerCase().includes(v.toLowerCase())):y).slice(0,6),x=async t=>{d(t.id);try{let[n,r]=await Promise.all([h.getModules(t.id),h.getSessions(t.id)]);e({id:t.id,name:t.name,code:o.trim(),modulesSnapshot:n.map(e=>({id:e.id,name:e.name,order:e.order})),sessionsSnapshot:r.map(e=>({id:e.id,title:e.title,order:e.order,moduleId:e.moduleId})),snapshotAt:new Date().toISOString()}),a(``),s(``),l(!1)}finally{d(null)}};return(0,W.jsxs)(`div`,{ref:_,style:{position:`relative`,display:`inline-block`},children:[(0,W.jsxs)(`form`,{className:`vc-inline-form`,onSubmit:async t=>{if(t.preventDefault(),!(!v||p))try{let t=await f({name:v});e({id:t.id,name:t.name,code:o.trim()}),a(``),s(``),l(!1)}catch{}},children:[(0,W.jsx)(`input`,{ref:m,className:`vc-inline-input iname`,placeholder:`Type or pick a course *`,value:i,onChange:e=>{a(e.target.value),l(!0)},onFocus:()=>l(!0),autoComplete:`off`,disabled:p}),(0,W.jsx)(`input`,{className:`vc-inline-input icode`,placeholder:`Code (opt.)`,value:o,onChange:e=>s(e.target.value),disabled:p}),(0,W.jsx)(`button`,{type:`submit`,disabled:!v||p,style:{padding:`6px 12px`,background:`#25476a`,color:`#fff`,border:`none`,borderRadius:`7px`,fontSize:`12px`,fontWeight:`700`,fontFamily:`Inter,sans-serif`,cursor:v&&!p?`pointer`:`not-allowed`,opacity:v&&!p?1:.5},children:p?`Adding…`:`Add`}),(0,W.jsx)(`button`,{type:`button`,onClick:t,style:{padding:`6px 10px`,background:`transparent`,color:`#9CA3AF`,border:`1.5px solid #E5E7EB`,borderRadius:`7px`,fontSize:`12px`,fontWeight:`600`,fontFamily:`Inter,sans-serif`,cursor:`pointer`},children:`Cancel`})]}),c&&(0,W.jsxs)(`div`,{className:`vc-course-dropdown`,children:[(0,W.jsx)(`div`,{className:`vc-course-dropdown-label`,children:`Existing courses`}),b.length===0?(0,W.jsx)(`p`,{className:`vc-course-empty`,children:y.length===0?`All courses already added.`:`No matches — press Add to use this as a custom name.`}):b.map(e=>(0,W.jsx)(`button`,{type:`button`,className:`vc-course-option`,onClick:()=>x(e),disabled:u===e.id,title:e.name,children:u===e.id?`Adding…`:e.name},e.id))]})]})}function I({course:e}){let[t,n]=(0,U.useState)(!1),r=e.modulesSnapshot||[],i=e.sessionsSnapshot||[],a=r.length>0||i.length>0,o=[...r].sort((e,t)=>(e.order??0)-(t.order??0)),s=new Map,c=[];return[...i].sort((e,t)=>(e.order??0)-(t.order??0)).forEach(e=>{e.moduleId&&o.some(t=>t.id===e.moduleId)?(s.has(e.moduleId)||s.set(e.moduleId,[]),s.get(e.moduleId).push(e)):c.push(e)}),(0,W.jsxs)(`div`,{style:{display:`inline-flex`,flexDirection:`column`,maxWidth:`100%`},children:[(0,W.jsxs)(`span`,{className:`vc-chip`,onClick:a?()=>n(e=>!e):void 0,style:{cursor:a?`pointer`:`default`},title:a?`Click to view the course structure captured for this version`:void 0,children:[e.name,e.code?(0,W.jsxs)(`span`,{style:{opacity:.55,fontWeight:`400`},children:[` `,e.code]}):null,a&&(0,W.jsxs)(`span`,{style:{fontSize:`10px`,fontWeight:`700`,opacity:.65},children:[`· `,r.length,` module`,r.length===1?``:`s`,` · `,i.length,` session`,i.length===1?``:`s`]})]}),t&&a&&(0,W.jsxs)(`div`,{style:{marginTop:`6px`,padding:`10px 12px`,background:`#F9FAFB`,border:`1px solid #E5E7EB`,borderRadius:`10px`,fontSize:`11.5px`,color:`#374151`,maxWidth:`320px`},children:[o.map(e=>(0,W.jsxs)(`div`,{style:{marginBottom:`6px`},children:[(0,W.jsx)(`p`,{style:{margin:`0 0 3px`,fontWeight:`700`,color:`#25476a`},children:e.name}),(s.get(e.id)||[]).map((e,t)=>(0,W.jsxs)(`p`,{style:{margin:0,paddingLeft:`10px`,color:`#6B7280`},children:[t+1,`. `,e.title||(0,W.jsx)(`em`,{children:`Untitled session`})]},e.id))]},e.id)),c.length>0&&(0,W.jsxs)(`div`,{children:[(0,W.jsx)(`p`,{style:{margin:`0 0 3px`,fontWeight:`700`,color:`#9CA3AF`},children:`Ungrouped`}),c.map((e,t)=>(0,W.jsxs)(`p`,{style:{margin:0,paddingLeft:`10px`,color:`#6B7280`},children:[t+1,`. `,e.title||(0,W.jsx)(`em`,{children:`Untitled session`})]},e.id))]})]})]})}function L({content:e,activeTab:t}){let n=e[t];return n?n.classes?.length?(0,W.jsx)(`div`,{children:n.classes.map(e=>(0,W.jsxs)(`div`,{className:`vc-class-row`,children:[(0,W.jsx)(`div`,{className:`vc-class-label`,children:e.className}),(0,W.jsx)(`div`,{className:`vc-chips`,children:e.courses.length===0?(0,W.jsx)(`span`,{style:{fontSize:`11px`,color:`#D1D5DB`,fontStyle:`italic`},children:`No courses added`}):e.courses.map(e=>(0,W.jsx)(I,{course:e},e.id))})]},e.classId||e.className))}):(0,W.jsx)(`p`,{style:{color:`#D1D5DB`,fontSize:`13px`,fontStyle:`italic`,margin:0,padding:`16px 0`},children:`No grades configured.`}):(0,W.jsx)(`p`,{style:{color:`#9CA3AF`,fontSize:`13px`,margin:0,padding:`16px 0`},children:`No data for this period.`})}function R({content:e,activeTab:t,onUpdate:n,allCourses:r}){let[i,a]=(0,U.useState)(null);(0,U.useEffect)(()=>{a(null)},[t]);let o=e[t];if(!o)return null;if(!o.classes?.length)return(0,W.jsx)(`p`,{style:{color:`#D1D5DB`,fontSize:`13px`,fontStyle:`italic`,margin:0,padding:`16px 0`},children:`No grades configured. Add grades in Structure first.`});let s=(r,i)=>{let a=X(e);a[t].classes[r].courses=a[t].classes[r].courses.filter(e=>e.id!==i),n(a)},c=(r,i)=>{let o=X(e),s=o[t].classes[r].courses;if(s.some(e=>e.id===i.id)){a(null);return}s.push(i),n(o),a(null)};return(0,W.jsx)(`div`,{children:o.classes.map((e,t)=>(0,W.jsxs)(`div`,{children:[(0,W.jsxs)(`div`,{className:`vc-class-row`,children:[(0,W.jsx)(`div`,{className:`vc-class-label`,children:e.className}),(0,W.jsxs)(`div`,{className:`vc-chips`,children:[e.courses.map(e=>(0,W.jsxs)(`span`,{className:`vc-chip`,children:[e.name,e.code?(0,W.jsxs)(`span`,{style:{opacity:.55,fontWeight:`400`},children:[` `,e.code]}):null,(0,W.jsx)(`button`,{type:`button`,className:`vc-chip-x`,onClick:()=>s(t,e.id),children:`×`})]},e.id)),i!==t&&(0,W.jsxs)(`button`,{type:`button`,className:`vc-add-pill`,onClick:()=>a(t),children:[(0,W.jsx)(`span`,{style:{fontSize:`14px`,fontWeight:`700`},children:`+`}),` Add`]})]})]}),i===t&&(0,W.jsx)(`div`,{style:{paddingLeft:`134px`,paddingBottom:`8px`},children:(0,W.jsx)(F,{onAdd:e=>c(t,e),onCancel:()=>a(null),allCourses:r,existingCourseIds:e.courses.map(e=>e.id)})})]},e.classId||e.className))})}function z({published:e,history:t,focusedId:n,onSelect:r}){let i=[...e?[{...e,_published:!0}]:[],...t];return(0,W.jsxs)(`div`,{className:`vc-sidebar`,children:[(0,W.jsxs)(`div`,{className:`vc-sidebar-head`,children:[(0,W.jsx)(`p`,{style:{margin:0,fontSize:`12px`,fontWeight:`700`,color:`#fff`,letterSpacing:`0.04em`,textTransform:`uppercase`},children:`Version History`}),(0,W.jsxs)(`p`,{style:{margin:`3px 0 0`,fontSize:`11px`,color:`rgba(255,255,255,0.6)`},children:[i.length,` `,i.length===1?`version`:`versions`]})]}),i.length===0?(0,W.jsx)(`div`,{style:{padding:`28px 16px`,textAlign:`center`},children:(0,W.jsx)(`p`,{style:{margin:0,fontSize:`12px`,color:`#9CA3AF`,lineHeight:1.5},children:`No versions yet.`})}):(0,W.jsxs)(`div`,{className:`vc-tl-list`,style:{maxHeight:`520px`,overflowY:`auto`},children:[(0,W.jsx)(`div`,{className:`vc-tl-line`}),i.map(e=>{let t=!!e._published,i=e.id===n&&!t,a=`vc-tl-entry`;return t&&(a+=` tl-published`),i&&(a+=` tl-focused`),(0,W.jsxs)(`button`,{type:`button`,className:a,style:{paddingLeft:0},onClick:()=>r(e),children:[(0,W.jsx)(`div`,{className:`vc-tl-dot-wrap`,children:(0,W.jsx)(`div`,{className:`vc-tl-dot`})}),(0,W.jsxs)(`div`,{className:`vc-tl-body`,children:[(0,W.jsxs)(`div`,{className:`vc-tl-top`,children:[(0,W.jsxs)(`span`,{className:`vc-tl-vnum`,children:[`v`,e.versionNumber]}),(0,W.jsx)(j,{status:e.status})]}),(0,W.jsx)(`div`,{className:`vc-tl-date`,children:Y(e.createdAt)}),(0,W.jsxs)(`div`,{className:`vc-tl-badges`,children:[t&&(0,W.jsx)(M,{color:`#b07800`,bg:`#fff8e6`,border:`#fcd97a`,children:`LIVE`}),i&&(0,W.jsx)(M,{color:`#92400E`,bg:`#FFFBEB`,border:`#FCD34D`,children:`VIEWING`})]})]})]},e.id)})]})]})}function B({version:e,curriculumPeriods:t,ayPeriods:n,nextVersionNumber:r,publishedId:o,onPublish:u,onEdit:d,onNew:f,onRestore:p,isPublishing:m,isRestoring:h}){let[g,_]=(0,U.useState)(0),{status:v}=e,y=v===`published`,b=v===`draft`,x=v===`inactive`,S=(e.content||[]).reduce((e,t)=>e+t.classes.reduce((e,t)=>e+t.courses.length,0),0),C=y?{bg:`#fff8e6`,border:`#fcd97a`,titleColor:`#b07800`}:b?{bg:`#F0F7FF`,border:`#a8d5ee`,titleColor:`#25476a`}:{bg:`#FAFAFA`,border:`#E5E7EB`,titleColor:`#374151`};return(0,W.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`,animation:`vc-fadein 0.2s ease`},children:[y&&(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`,padding:`10px 16px`,backgroundColor:`#fff8e6`,border:`1.5px solid #fcd97a`,borderRadius:`12px`},children:[(0,W.jsx)(c,{sx:{fontSize:16,color:`#b07800`}}),(0,W.jsxs)(`p`,{style:{margin:0,fontSize:`12px`,color:`#b07800`,fontWeight:`500`},children:[`This is the `,(0,W.jsx)(`strong`,{children:`live version`}),` currently in use.`]})]}),b&&!o&&(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`,padding:`10px 16px`,backgroundColor:`#FFFBEB`,border:`1.5px solid #FCD34D`,borderRadius:`12px`},children:[(0,W.jsx)(l,{sx:{fontSize:16,color:`#92400E`}}),(0,W.jsx)(`p`,{style:{margin:0,fontSize:`12px`,color:`#92400E`,fontWeight:`500`},children:`No version is live yet. Publish this draft to make it active.`})]}),x&&(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`,padding:`10px 16px`,backgroundColor:`#F9FAFB`,border:`1.5px solid #E5E7EB`,borderRadius:`12px`},children:[(0,W.jsx)(i,{sx:{fontSize:16,color:`#6B7280`}}),(0,W.jsx)(`p`,{style:{margin:0,fontSize:`12px`,color:`#6B7280`,fontWeight:`500`},children:`Historical version — restore to create a new draft based on this content.`})]}),(0,W.jsx)(`div`,{style:{...J,backgroundColor:C.bg,border:`1.5px solid ${C.border}`},children:(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,justifyContent:`space-between`,gap:`16px`,flexWrap:`wrap`},children:[(0,W.jsxs)(`div`,{children:[(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`,marginBottom:`6px`,flexWrap:`wrap`},children:[(0,W.jsxs)(`h2`,{style:{margin:0,fontSize:`20px`,fontWeight:`800`,color:C.titleColor},children:[`Version `,e.versionNumber]}),(0,W.jsx)(j,{status:v})]}),(0,W.jsxs)(`div`,{style:{display:`flex`,gap:`14px`,flexWrap:`wrap`},children:[(0,W.jsxs)(`span`,{style:{fontSize:`12px`,color:`#9CA3AF`},children:[`Saved `,Y(e.createdAt)]}),(0,W.jsx)(`span`,{style:{fontSize:`12px`,color:`#9CA3AF`},children:`·`}),(0,W.jsxs)(`span`,{style:{fontSize:`12px`,color:`#6B7280`,fontWeight:`600`},children:[S,` course`,S===1?``:`s`]})]})]}),(0,W.jsxs)(`div`,{style:{display:`flex`,gap:`8px`,flexWrap:`wrap`,flexShrink:0},children:[x&&(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-restore`,onClick:p,disabled:h,children:h?(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(k,{light:!1}),` Restoring…`]}):`↩ Restore as v${r}`}),b&&(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-publish`,onClick:u,disabled:m,children:m?(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(k,{}),` Publishing…`]}):(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(a,{fontSize:`small`}),` Publish`]})}),(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-ghost`,onClick:d,children:(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(s,{fontSize:`small`}),` Edit`]})}),(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-primary`,onClick:f,children:`+ New Version`})]}),y&&(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-ghost`,onClick:d,children:(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(s,{fontSize:`small`}),` Edit → v`,r]})}),(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-primary`,onClick:f,children:`+ New Version`})]})]})]})}),(0,W.jsx)(`div`,{style:J,children:t.length===0?(0,W.jsx)(`div`,{style:{textAlign:`center`,padding:`32px 0`},children:(0,W.jsx)(`p`,{style:{margin:0,fontSize:`13px`,color:`#9CA3AF`},children:`No periods configured in structure.`})}):(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(P,{periods:t,ayPeriods:n,activeIdx:g,onChange:_}),(0,W.jsx)(L,{content:e.content||[],activeTab:g})]})})]})}function V({type:e,curriculum:t,ayPeriods:n,initialContent:r,nextVersionNumber:i,onSave:a,onCancel:o,isPending:c}){let[u,d]=(0,U.useState)(0),[f,p]=(0,U.useState)(()=>e===`edit`?O(t,r):D(t)),{data:m}=v(),h=m?.data||[],g=t.periods||[],_=(f[0]?.classes?.length||0)>0;return(0,W.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`,animation:`vc-fadein 0.2s ease`},children:[(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`10px`,padding:`10px 16px`,backgroundColor:`#e8f5fb`,border:`1.5px solid #a8d5ee`,borderRadius:`12px`},children:[(0,W.jsx)(`span`,{style:{fontSize:`14px`,flexShrink:0},children:e===`edit`?(0,W.jsx)(s,{fontSize:`small`}):(0,W.jsx)(l,{fontSize:`small`})}),(0,W.jsxs)(`p`,{style:{margin:0,fontSize:`12px`,color:`#25476a`,fontWeight:`500`},children:[e===`edit`?`Courses pre-filled from the selected version. Add or remove as needed.`:`All courses start blank. Fill in each grade for every period.`,` `,(0,W.jsx)(`strong`,{children:`Saving creates a new draft`}),` — publish it when ready.`]})]}),(0,W.jsx)(`div`,{style:{...J,backgroundColor:`#F0F7FF`,border:`1.5px solid #a8d5ee`},children:(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:`16px`,flexWrap:`wrap`},children:[(0,W.jsxs)(`div`,{children:[(0,W.jsx)(`h2`,{style:{margin:`0 0 3px`,fontSize:`18px`,fontWeight:`800`,color:`#25476a`},children:e===`edit`?`Editing → Version ${i}`:`New Version ${i}`}),(0,W.jsx)(`p`,{style:{margin:0,fontSize:`12px`,color:`#3B82F6`},children:`Saves as a draft — you can publish it from the version panel.`})]}),(0,W.jsxs)(`div`,{style:{display:`flex`,gap:`10px`},children:[(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-secondary`,onClick:o,children:`Cancel`}),(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-primary`,disabled:c,onClick:()=>a({content:f}),children:c?(0,W.jsxs)(W.Fragment,{children:[(0,W.jsx)(k,{}),` Saving…`]}):`Save Draft v${i}`})]})]})}),g.length===0?(0,W.jsx)(`div`,{style:{...J,textAlign:`center`,padding:`48px 24px`},children:(0,W.jsxs)(`p`,{style:{margin:0,fontSize:`13px`,color:`#9CA3AF`},children:[`No periods configured. Go to `,(0,W.jsx)(`strong`,{children:`Structure`}),` first.`]})}):_?(0,W.jsxs)(`div`,{style:J,children:[(0,W.jsx)(P,{periods:g,ayPeriods:n,activeIdx:u,onChange:d}),(0,W.jsx)(R,{content:f,activeTab:u,onUpdate:p,allCourses:h})]}):(0,W.jsx)(`div`,{style:{...J,textAlign:`center`,padding:`48px 24px`},children:(0,W.jsxs)(`p`,{style:{margin:0,fontSize:`13px`,color:`#9CA3AF`},children:[`No grades found. Go to `,(0,W.jsx)(`strong`,{children:`Structure`}),` to add grade levels first.`]})})]})}function H(){let{id:e}=d(),t=p(),{data:n,isLoading:r}=y(e),{data:i,isLoading:a}=T(e),{data:o,isLoading:s}=S(e),{mutate:c,isPending:u}=x(e),{mutate:f,isPending:m}=C(e),[h,g]=(0,U.useState)(`browse`),[_,v]=(0,U.useState)(null),[b,w]=(0,U.useState)(null),E=o?.current||null,D=o?.history||[],O=i?.publishedVersion?.periods||[],k=n?.periods||[],j=[...E?[E]:[],...D],M=j.map(e=>e.versionNumber),P=M.length?Math.max(...M)+1:1,F=_?j.find(e=>e.id===_.id)||_:E||D[0]||null;(0,U.useEffect)(()=>{!s&&j.length===0?g(`empty`):!s&&j.length>0&&h===`empty`&&g(`browse`)},[s,j.length]);let I=e=>{c({...e,status:`draft`,academicYearId:i?.publishedVersion?.id||null},{onSuccess:e=>{v(e),g(`browse`)}})},L=()=>{F&&f({vId:F.id,status:`published`},{onSuccess:()=>v(null)})},R=()=>{F&&c({content:F.content,status:`draft`,academicYearId:i?.publishedVersion?.id||null},{onSuccess:e=>{v(e),g(`browse`)}})},H=e=>{v(e.id===E?.id?null:e),g(`browse`)},G=()=>{w(F),g(`edit`)},J=()=>{w(null),g(`new`)},Y=()=>{w(null),g(j.length?`browse`:`empty`)};if(r||a||s)return(0,W.jsxs)(`div`,{style:{fontFamily:`Inter,sans-serif`},children:[(0,W.jsx)(`style`,{children:q}),(0,W.jsx)(A,{})]});let X={new:`Creating Version ${P} — saves as draft.`,edit:`Editing → Version ${P} (saves as draft).`,browse:F?`Viewing Version ${F.versionNumber} · ${K.find(e=>e.value===F.status)?.label||`Unknown`}`:`No versions yet.`,empty:`No versions yet. Create the first one to get started.`};return(0,W.jsxs)(`div`,{style:{fontFamily:`Inter,sans-serif`},children:[(0,W.jsx)(`style`,{children:q}),(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,justifyContent:`space-between`,marginBottom:`28px`,gap:`16px`,flexWrap:`wrap`},children:[(0,W.jsxs)(`div`,{children:[(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`6px`,marginBottom:`6px`},children:[(0,W.jsx)(`button`,{type:`button`,onClick:()=>t(`/curriculum`),style:{background:`none`,border:`none`,color:`#9CA3AF`,fontSize:`12px`,fontFamily:`Inter,sans-serif`,cursor:`pointer`,padding:0},children:`Curriculum`}),(0,W.jsx)(`span`,{style:{color:`#E5E7EB`},children:`/`}),(0,W.jsx)(`span`,{style:{fontSize:`12px`,color:`#9CA3AF`,maxWidth:`140px`,overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`},children:n?.name}),(0,W.jsx)(`span`,{style:{color:`#E5E7EB`},children:`/`}),(0,W.jsx)(`span`,{style:{fontSize:`12px`,color:`#374151`,fontWeight:`600`},children:`Version Control`})]}),(0,W.jsx)(`h1`,{style:{margin:`0 0 3px`,fontSize:`22px`,fontWeight:`800`,color:`#0F2645`},children:`Version Control`}),(0,W.jsx)(`p`,{style:{margin:0,fontSize:`13px`,color:`#6B7280`},children:X[h]})]}),(0,W.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`,flexShrink:0},children:[(0,W.jsx)(`button`,{type:`button`,onClick:()=>t(`/curriculum/${e}/structure`),className:`vc-btn-secondary`,children:`← Structure`}),(0,W.jsx)(`button`,{type:`button`,onClick:()=>t(`/curriculum`),className:`vc-btn-primary`,children:`Done`})]})]}),(0,W.jsx)(N,{current:4}),h===`empty`&&(0,W.jsxs)(`div`,{className:`vc-empty-state`,children:[(0,W.jsx)(`div`,{style:{fontSize:`36px`,color:`#9CA3AF`,display:`flex`,justifyContent:`center`,marginBottom:`12px`},children:(0,W.jsx)(l,{fontSize:`inherit`})}),(0,W.jsx)(`p`,{style:{margin:`0 0 6px`,fontSize:`16px`,fontWeight:`800`,color:`#374151`},children:`No versions yet`}),(0,W.jsx)(`p`,{style:{margin:`0 0 24px`,fontSize:`13px`,color:`#9CA3AF`,maxWidth:`340px`,marginInline:`auto`},children:`Assign courses to each grade and period to create Version 1. You can publish it once it's ready.`}),(0,W.jsx)(`button`,{type:`button`,className:`vc-btn-primary`,onClick:()=>g(`new`),children:`+ Create Version 1`})]}),h!==`empty`&&(0,W.jsxs)(`div`,{className:`vc-layout`,children:[(0,W.jsxs)(`div`,{style:{minWidth:0},children:[h===`browse`&&F&&(0,W.jsx)(B,{version:F,curriculumPeriods:k,ayPeriods:O,nextVersionNumber:P,publishedId:E?.id,onPublish:L,onEdit:G,onNew:J,onRestore:R,isPublishing:m,isRestoring:u}),(h===`new`||h===`edit`)&&(0,W.jsx)(V,{type:h,curriculum:n||{periods:[],structure:[]},ayPeriods:O,initialContent:b?.content||null,nextVersionNumber:P,onSave:I,onCancel:Y,isPending:u})]}),(0,W.jsx)(z,{published:E,history:D,focusedId:_?.id,onSelect:H})]})]})}var U,W,G,K,q,J,Y,X;t((()=>{U=e(r()),u(),f(),b(),E(),w(),_(),m(),W=n(),G=[{n:1,label:`Basic Info`},{n:2,label:`Competencies`},{n:3,label:`Structure`},{n:4,label:`Version Control`}],K=[{value:`draft`,label:`Draft`,bg:`#FFFBEB`,border:`#FCD34D`,color:`#92400E`,dot:`#F59E0B`},{value:`published`,label:`Published`,bg:`#fff8e6`,border:`#fcd97a`,color:`#b07800`,dot:`#feb139`},{value:`inactive`,label:`Inactive`,bg:`#F9FAFB`,border:`#E5E7EB`,color:`#6B7280`,dot:`#9CA3AF`}],q=`
  @keyframes vc-spin   { to { transform: rotate(360deg); } }
  @keyframes vc-fadein { from { opacity:0; transform:translateY(5px); } to { opacity:1; transform:translateY(0); } }

  .vc-steps { display:flex; align-items:center; justify-content:center; margin-bottom:32px; }
  .vc-connector { width:64px; height:2px; flex-shrink:0; margin:0 6px; margin-bottom:20px; }
  @media(max-width:580px){ .vc-connector{width:24px;} .vc-steps{justify-content:flex-start;overflow-x:auto;padding-bottom:4px;} }

  .vc-layout {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 240px;
    gap: 20px;
    align-items: start;
  }
  @media(max-width:960px){ .vc-layout{ grid-template-columns:1fr; } }

  .vc-period-tabs { display:flex; gap:6px; overflow-x:auto; padding-bottom:4px; margin-bottom:20px; }
  .vc-period-tabs::-webkit-scrollbar { height:3px; }
  .vc-period-tabs::-webkit-scrollbar-thumb { background:#E5E7EB; border-radius:4px; }

  .vc-tab {
    padding:7px 16px; border-radius:8px; border:1.5px solid #E5E7EB;
    background:#fff; font-size:12px; font-weight:600; font-family:Inter,sans-serif;
    cursor:pointer; white-space:nowrap; transition:all 0.15s; color:#6B7280; flex-shrink:0;
  }
  .vc-tab:hover  { border-color:#b8d9ee; color:#38aae1; background:#F8FBFF; }
  .vc-tab.active { border-color:#25476a; background:#e8f5fb; color:#25476a; box-shadow:0 1px 4px rgba(37,71,106,0.12); }

  .vc-class-row {
    display:flex; align-items:flex-start; gap:14px; padding:12px 0;
    border-bottom:1px solid #F3F4F6;
  }
  .vc-class-row:last-child { border-bottom:none; }
  .vc-class-label {
    width:120px; flex-shrink:0; font-size:12px; font-weight:700;
    color:#374151; padding-top:4px; line-height:1.4;
  }
  .vc-chips { display:flex; flex-wrap:wrap; gap:5px; flex:1; min-width:0; align-items:center; }

  .vc-chip {
    display:inline-flex; align-items:center; gap:5px;
    padding:4px 10px; border-radius:20px; font-size:11px; font-weight:600;
    background:#e8f5fb; border:1.5px solid #a8d5ee; color:#25476a; font-family:Inter,sans-serif;
  }
  .vc-chip-x {
    width:14px; height:14px; border-radius:50%; border:none;
    background:rgba(29,58,138,0.1); color:#25476a; cursor:pointer;
    display:inline-flex; align-items:center; justify-content:center;
    font-size:11px; font-weight:900; padding:0; transition:background 0.1s, color 0.1s; flex-shrink:0;
  }
  .vc-chip-x:hover { background:rgba(239,68,68,0.2); color:#DC2626; }

  .vc-add-pill {
    display:inline-flex; align-items:center; gap:4px;
    padding:4px 10px; border-radius:20px; font-size:11px; font-weight:600;
    background:transparent; border:1.5px dashed #D1D5DB; color:#9CA3AF;
    font-family:Inter,sans-serif; cursor:pointer; transition:all 0.15s; flex-shrink:0;
  }
  .vc-add-pill:hover { border-color:#25476a; color:#25476a; background:#e8f5fb; }

  .vc-inline-form {
    display:flex; gap:8px; align-items:center; flex-wrap:wrap;
    padding:10px 14px; background:#F0F7FF; border-radius:10px;
    border:1.5px solid #C7D9F8; margin-top:6px; animation:vc-fadein 0.15s ease;
  }
  .vc-inline-input {
    padding:6px 10px; border-radius:7px; border:1.5px solid #D1D5DB;
    font-size:12px; font-family:Inter,sans-serif; background:#fff; outline:none;
    transition:border-color 0.15s, box-shadow 0.15s;
  }
  .vc-inline-input:focus { border-color:#25476a; box-shadow:0 0 0 3px rgba(37,71,106,0.08); }
  .vc-inline-input.iname { width:160px; }
  .vc-inline-input.icode { width:88px; }

  .vc-course-dropdown {
    position:absolute; top:calc(100% + 4px); left:0; z-index:20; width:260px;
    background:#fff; border:1px solid #E5E7EB; border-radius:10px;
    box-shadow:0 10px 24px rgba(15,38,69,0.14), 0 2px 8px rgba(0,0,0,0.06);
    padding:6px; max-height:220px; overflow-y:auto; animation:vc-fadein 0.12s ease;
  }
  .vc-course-dropdown-label {
    padding:4px 8px 6px; font-size:10px; font-weight:700; color:#B0B8C4;
    text-transform:uppercase; letter-spacing:0.06em;
  }
  .vc-course-option {
    display:block; width:100%; text-align:left; padding:7px 9px; border:none; border-radius:7px;
    background:transparent; font-size:12.5px; font-weight:600; color:#374151;
    font-family:Inter,sans-serif; cursor:pointer; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
  }
  .vc-course-option:hover { background:#F3F4F6; color:#25476a; }
  .vc-course-empty {
    padding:10px 9px; font-size:11.5px; color:#D1D5DB; font-style:italic;
  }

  .vc-empty-state {
    text-align:center; padding:72px 32px; background:#FAFAFA;
    border:2px dashed #E5E7EB; border-radius:20px; animation:vc-fadein 0.2s ease;
  }

  /* Buttons */
  .vc-btn-primary {
    padding:8px 18px; background:#25476a; color:#fff; border:none; border-radius:9px;
    font-size:13px; font-weight:600; font-family:Inter,sans-serif; cursor:pointer;
    display:inline-flex; align-items:center; gap:7px; transition:background 0.15s;
    white-space:nowrap;
  }
  .vc-btn-primary:hover:not(:disabled) { background:#0A3880; }
  .vc-btn-primary:disabled { background:#b8d9ee; cursor:not-allowed; }

  .vc-btn-secondary {
    padding:8px 16px; background:#fff; color:#374151;
    border:1.5px solid #E5E7EB; border-radius:9px; font-size:13px; font-weight:600;
    font-family:Inter,sans-serif; cursor:pointer; display:inline-flex; align-items:center;
    gap:6px; transition:all 0.15s; white-space:nowrap;
  }
  .vc-btn-secondary:hover { background:#F3F4F6; }

  .vc-btn-ghost {
    padding:8px 16px; background:#e8f5fb; color:#25476a;
    border:1.5px solid #a8d5ee; border-radius:9px; font-size:13px; font-weight:600;
    font-family:Inter,sans-serif; cursor:pointer; display:inline-flex; align-items:center;
    gap:7px; transition:all 0.15s; white-space:nowrap;
  }
  .vc-btn-ghost:hover { background:#d6edf8; }

  .vc-btn-publish {
    padding:8px 18px; background:#feb139; color:#25476a; border:none; border-radius:9px;
    font-size:13px; font-weight:700; font-family:Inter,sans-serif; cursor:pointer;
    display:inline-flex; align-items:center; gap:7px; transition:background 0.15s;
    white-space:nowrap;
  }
  .vc-btn-publish:hover:not(:disabled) { background:#f0a800; }
  .vc-btn-publish:disabled { background:#fef3d0; cursor:not-allowed; }

  .vc-btn-restore {
    padding:8px 16px; background:#e8f5fb; color:#25476a;
    border:1.5px solid #a8d5ee; border-radius:9px; font-size:13px; font-weight:600;
    font-family:Inter,sans-serif; cursor:pointer; display:inline-flex; align-items:center;
    gap:7px; transition:all 0.15s; white-space:nowrap;
  }
  .vc-btn-restore:hover:not(:disabled) { background:#d6edf8; }
  .vc-btn-restore:disabled { opacity:0.5; cursor:not-allowed; }

  /* Status selector in editor */
  .vc-status-pill {
    padding:6px 14px; border-radius:8px; border:1.5px solid #E5E7EB;
    background:#fff; font-size:12px; font-weight:600; font-family:Inter,sans-serif;
    cursor:pointer; transition:all 0.15s; display:inline-flex; align-items:center; gap:5px;
  }
  .vc-status-pill:hover:not(.sp-active) { border-color:#CBD5E1; background:#F8FAFC; }
  .vc-status-pill.sp-draft    { border-color:#FCD34D; background:#FFFBEB; color:#92400E; }
  .vc-status-pill.sp-inactive { border-color:#D1D5DB; background:#F3F4F6; color:#6B7280; }

  /* Sidebar */
  .vc-sidebar {
    background:#fff; border-radius:16px; border:1.5px solid #E5E7EB;
    box-shadow:0 2px 8px rgba(0,0,0,0.04); overflow:hidden; position:sticky; top:20px;
  }
  .vc-sidebar-head {
    padding:14px 16px 12px; border-bottom:1px solid #F0F0F0;
    background:linear-gradient(135deg,#0A3880,#2e7db5);
  }

  /* Timeline */
  .vc-tl-list { position:relative; }
  .vc-tl-line { position:absolute; left:22px; top:0; bottom:0; width:2px; background:#F0F0F0; pointer-events:none; }
  .vc-tl-entry {
    display:flex; align-items:flex-start; gap:0;
    padding:10px 14px 10px 0; cursor:pointer; transition:background 0.12s;
    position:relative; border-bottom:1px solid #F5F5F5;
    background:none; border-left:none; border-right:none; border-top:none;
    width:100%; text-align:left; font-family:Inter,sans-serif;
  }
  .vc-tl-entry:last-child { border-bottom:none; }
  .vc-tl-entry:hover { background:#F9FAFB; }
  .vc-tl-entry.tl-published { background:#fff8e6; }
  .vc-tl-entry.tl-focused   { background:#FFFBEB; }

  .vc-tl-dot-wrap { width:44px; display:flex; flex-direction:column; align-items:center; flex-shrink:0; padding-top:3px; }
  .vc-tl-dot { width:12px; height:12px; border-radius:50%; flex-shrink:0; border:2px solid #E5E7EB; background:#fff; transition:all 0.15s; }
  .tl-published .vc-tl-dot { background:#feb139; border-color:#feb139; box-shadow:0 0 0 3px rgba(254,177,57,0.2); }
  .tl-focused   .vc-tl-dot { background:#F59E0B; border-color:#F59E0B; box-shadow:0 0 0 3px rgba(245,158,11,0.15); }

  .vc-tl-body { flex:1; min-width:0; padding-right:4px; }
  .vc-tl-top  { display:flex; align-items:center; justify-content:space-between; gap:6px; margin-bottom:3px; }
  .vc-tl-vnum { font-size:13px; font-weight:700; color:#111827; white-space:nowrap; }
  .vc-tl-date { font-size:10px; color:#9CA3AF; margin-top:1px; }
  .vc-tl-badges { display:flex; gap:4px; flex-wrap:wrap; margin-top:4px; }
`,J={backgroundColor:`#fff`,borderRadius:`16px`,padding:`22px 24px`,boxShadow:`0 1px 4px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.04)`},Y=e=>e?new Date(e).toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`}):`—`,X=e=>JSON.parse(JSON.stringify(e))}))();export{H as default};