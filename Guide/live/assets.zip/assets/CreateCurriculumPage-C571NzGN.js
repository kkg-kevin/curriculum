import{i as e,n as t}from"./chunk-CacB07dV.js";import{b as n,x as r}from"./api-DGMXcJWw.js";import{Qn as i,t as a}from"./icons-material-Cgfsq_3K.js";import{Lt as o,St as s,Wt as c,_t as l,bt as u,gt as d,yt as f}from"./index-CcENR8Vg.js";import{n as p,t as m}from"./ConfirmDialog-Ch94kqR5.js";import{r as h,t as g}from"./useCurriculum-B8_D55Bp.js";import{i as _,r as v}from"./curriculum.schema-DWNRtnB5.js";import{i as y,n as b,r as x,t as S}from"./CurriculumPreview-DC8wVp5x.js";function C({current:e}){return(0,D.jsx)(`div`,{className:`ccp-steps`,children:O.map((t,n)=>{let r=t.n<e,a=t.n===e;return(0,D.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`},children:[(0,D.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:`6px`},children:[(0,D.jsx)(`div`,{style:{width:`34px`,height:`34px`,borderRadius:`50%`,backgroundColor:r||a?`#25476a`:`#F3F4F6`,border:`2px solid ${r||a?`#25476a`:`#E5E7EB`}`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:r||a?`#fff`:`#9CA3AF`,fontSize:r?`15px`:`13px`,fontWeight:`700`,transition:`all 0.2s`,flexShrink:0},children:r?(0,D.jsx)(i,{fontSize:`small`}):t.n}),(0,D.jsx)(`span`,{style:{fontSize:`11px`,fontWeight:a?`600`:`400`,color:a?`#25476a`:r?`#374151`:`#9CA3AF`,whiteSpace:`nowrap`},children:t.label})]}),n<O.length-1&&(0,D.jsx)(`div`,{className:`ccp-connector`,style:{height:`2px`,backgroundColor:r?`#25476a`:`#E5E7EB`,margin:`0 6px`,marginBottom:`20px`,flexShrink:0,transition:`background-color 0.2s`}})]},t.n)})})}function w(){return(0,D.jsx)(`span`,{style:{width:`14px`,height:`14px`,border:`2px solid rgba(255,255,255,0.4)`,borderTopColor:`#ffffff`,borderRadius:`50%`,display:`inline-block`,animation:`spin 0.7s linear infinite`}})}function T(){let e=c(),{mutate:t,isPending:n}=h(),[r,i]=(0,E.useState)(!1),a=s({resolver:l(v),defaultValues:k,mode:`onTouched`}),{handleSubmit:o,setError:u,formState:{isDirty:d}}=a,p=n=>{t(n,{onSuccess:t=>e(`/curriculum/${t.id}/competencies`),onError:e=>{e?.statusCode===409&&u(`name`,{type:`server`,message:e.message},{shouldFocus:!0})}})},g=`/curriculum`,_=()=>{d?i(!0):e(g)};return(0,D.jsxs)(`div`,{style:{fontFamily:`Inter, sans-serif`},children:[(0,D.jsx)(`style`,{children:`
        @keyframes spin { to { transform: rotate(360deg); } }

        .ccp-steps {
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 32px;
          flex-wrap: nowrap;
        }
        .ccp-connector { width: 60px; }

        .ccp-layout {
          display: flex;
          gap: 24px;
          align-items: flex-start;
        }
        .ccp-form-col { flex: 1; min-width: 0; }
        .ccp-preview-col {
          flex: 1;
          min-width: 0;
          position: sticky;
          top: 24px;
          align-self: flex-start;
          max-height: calc(100vh - 140px);
          overflow-y: auto;
          padding-right: 2px;
        }

        @media (max-width: 768px) {
          .ccp-steps { justify-content: flex-start; overflow-x: auto; padding-bottom: 4px; }
          .ccp-connector { width: 40px; }
          .ccp-layout { flex-direction: column; }
          .ccp-form-col { order: 1; }
          .ccp-preview-col {
            order: 2;
            position: static;
            max-height: none;
            width: 100%;
          }
        }
      `}),(0,D.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,justifyContent:`space-between`,marginBottom:`28px`,gap:`16px`},children:[(0,D.jsxs)(`div`,{children:[(0,D.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`6px`,marginBottom:`4px`},children:[(0,D.jsx)(`button`,{type:`button`,onClick:_,style:{display:`flex`,alignItems:`center`,gap:`4px`,padding:`0`,background:`none`,border:`none`,color:`#6B7280`,fontSize:`13px`,fontFamily:`Inter, sans-serif`,cursor:`pointer`},children:`← Curriculum`}),(0,D.jsx)(`span`,{style:{color:`#D1D5DB`,fontSize:`13px`},children:`/`}),(0,D.jsx)(`span`,{style:{fontSize:`13px`,color:`#111827`,fontWeight:`500`},children:`New`})]}),(0,D.jsx)(`h1`,{style:{margin:0,fontSize:`22px`,fontWeight:`700`,color:`#111827`},children:`Create Curriculum`}),(0,D.jsx)(`p`,{style:{margin:`4px 0 0 0`,fontSize:`13px`,color:`#6B7280`},children:`Enter basic details — you'll configure competencies and structure in the next steps.`})]}),(0,D.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`,flexShrink:0},children:[(0,D.jsx)(`button`,{type:`button`,onClick:_,style:{padding:`10px 20px`,backgroundColor:`transparent`,color:`#374151`,border:`1.5px solid #E5E7EB`,borderRadius:`10px`,fontSize:`14px`,fontWeight:`600`,fontFamily:`Inter, sans-serif`,cursor:`pointer`},children:`Cancel`}),(0,D.jsx)(`button`,{type:`submit`,form:`create-curriculum-form`,disabled:n,style:{padding:`10px 24px`,backgroundColor:n?`#b8d9ee`:`#25476a`,color:`#ffffff`,border:`none`,borderRadius:`10px`,fontSize:`14px`,fontWeight:`600`,fontFamily:`Inter, sans-serif`,cursor:n?`not-allowed`:`pointer`,display:`flex`,alignItems:`center`,gap:`8px`,transition:`background-color 0.15s`},children:n?(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(w,{}),` Creating…`]}):`Next: Competencies →`})]})]}),(0,D.jsx)(C,{current:1}),(0,D.jsx)(f,{...a,children:(0,D.jsx)(`form`,{id:`create-curriculum-form`,onSubmit:o(p),noValidate:!0,children:(0,D.jsxs)(`div`,{className:`ccp-layout`,children:[(0,D.jsx)(`div`,{className:`ccp-form-col`,children:(0,D.jsx)(x,{})}),(0,D.jsx)(`div`,{className:`ccp-preview-col`,children:(0,D.jsx)(S,{})})]})})}),(0,D.jsx)(m,{isOpen:r,title:`Discard changes?`,message:`You have unsaved changes that will be lost if you leave this page.`,confirmLabel:`Leave`,cancelLabel:`Stay`,onConfirm:()=>e(g),onCancel:()=>i(!1)})]})}var E,D,O,k;t((()=>{E=e(r()),a(),o(),u(),d(),g(),_(),y(),b(),p(),D=n(),O=[{n:1,label:`Basic Info`},{n:2,label:`Competencies`},{n:3,label:`Structure`},{n:4,label:`Version Control`}],k={name:``,code:``,description:``,audience:`learners`,completionTeacherLevel:``}}))();export{T as default};