import{j as o}from"./query-BbvYY5Lh.js";import{e as t}from"./index-BdiUU7bC.js";const c=t(o.jsx("path",{d:"M5 13.18v4L12 21l7-3.82v-4L12 17zM12 3 1 9l11 6 9-4.91V17h2V9z"}),"School");export{c as S};
